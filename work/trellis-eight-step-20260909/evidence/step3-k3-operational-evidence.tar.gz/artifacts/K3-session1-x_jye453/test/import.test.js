'use strict';

// 导入行为：v2 导出的解析、撤销条目不入库、多行正文、id 仍由 store 分配。

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { parseExport, importClippings } = require('../src/import.js');
const { listEntries, searchEntries, appendEntry } = require('../src/store.js');

const SAMPLE_EXPORT = path.join(__dirname, '..', 'data', 'sample-export.txt');

function freshStore() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mozhai-import-'));
  return path.join(dir, 'entries.jsonl');
}

test('parses the shipped v2 export into notes and revoked items', () => {
  const { entries, revoked } = parseExport(fs.readFileSync(SAMPLE_EXPORT, 'utf8'));
  assert.equal(entries.length, 2);
  assert.deepEqual(entries[0], {
    book: '《夜晚的潜水艇》',
    author: '陈春成',
    time: '2026-08-01 23:42:05',
    text: '手边的书就是看不到尽头的河。',
  });
  assert.equal(revoked.length, 1);
  assert.equal(revoked[0].time, '2026-08-03 08:15:44');
});

test('a revoked note is never written to the store', () => {
  const store = freshStore();
  importClippings(store, SAMPLE_EXPORT);
  assert.equal(searchEntries(store, '撤销').length, 0);
  assert.equal(searchEntries(store, '已在设备上删除').length, 0);
});

test('a wrapped note keeps its own line break and stays searchable per line', () => {
  const { entries } = parseExport(fs.readFileSync(SAMPLE_EXPORT, 'utf8'));
  assert.equal(entries[1].text, '江水把岸边的灯影揉碎，\n又一片片拼回去。');

  const store = freshStore();
  importClippings(store, SAMPLE_EXPORT);
  assert.equal(searchEntries(store, '灯影揉碎').length, 1);
  assert.equal(searchEntries(store, '又一片片拼回去').length, 1);
});

test('imported notes get store-assigned ids that continue the existing store', () => {
  const store = freshStore();
  appendEntry(store, {
    book: '《俗世奇人》',
    author: '冯骥才',
    time: '2026-07-25 09:02:41',
    text: '刷子李的规矩比手艺还硬。',
  });
  const { imported } = importClippings(store, SAMPLE_EXPORT);
  assert.deepEqual(
    imported.map((record) => record.id),
    ['entry-0002', 'entry-0003'],
  );
  assert.equal(listEntries(store).length, 3);
});

test('import only appends: lines already in the store are untouched', () => {
  const store = freshStore();
  appendEntry(store, {
    book: '《俗世奇人》',
    author: '冯骥才',
    time: '2026-07-25 09:02:41',
    text: '刷子李的规矩比手艺还硬。',
  });
  const before = fs.readFileSync(store, 'utf8');
  importClippings(store, SAMPLE_EXPORT);
  assert.ok(fs.readFileSync(store, 'utf8').startsWith(before));
});

test('rejects a header it does not understand instead of guessing', () => {
  assert.throws(() => parseExport('夜晚的潜水艇|陈春成|2026-05-01 21:03:11|正文\n'), /导出文件头/);
  assert.throws(() => parseExport('墨记导出 v3\n==========\n'), /v3 未支持/);
});
