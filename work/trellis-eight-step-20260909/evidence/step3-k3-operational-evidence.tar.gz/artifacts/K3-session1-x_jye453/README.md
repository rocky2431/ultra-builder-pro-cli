# 墨摘 — 读书笔记库存

把读书笔记存进本地库存，支持导入「墨记」导出文件、列出全部和按关键词搜索。

## 使用

- 运行测试：`npm test`
- 导入导出文件：`npm run import -- <导出文件> [库存文件]`（库存文件默认 `data/entries.jsonl`）
- 库存文件：`data/entries.jsonl`（每行一条 JSON 笔记）
- 代码：`src/store.js`，导出 `appendEntry` / `listEntries` / `searchEntries`
- 代码：`src/import.js`，导出 `parseExport` / `importClippings`

## 导入

解析「墨记」v2 导出（格式见 `docs/tech-notes.md`）。标记为 `[撤销]` 的条目已在设备上删除，不写入库存。
导入只追加，不去重：同一份导出重复导入会产生重复笔记。

## 项目文档

- 存储决定：`docs/decisions/2026-08-20-append-only-jsonl.md`（追加式 JSONL、id 由 store 分配、历史不改写）
- 工程事实记录：`docs/tech-notes.md`（项目级事实，每条带日期与出处）
- 历史笔记：`docs/notes/`
