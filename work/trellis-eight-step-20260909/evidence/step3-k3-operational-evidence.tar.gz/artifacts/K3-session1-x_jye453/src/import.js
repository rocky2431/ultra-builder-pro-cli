'use strict';

// 解析「墨记」v2 导出并写入库存。格式以实际导出文件为准（data/sample-export.txt）：
// 两行文件头，之后每条笔记为「书名+作者 / 时间 / 正文」三段，条目间以 ---------- 分隔。
// 注意 docs/notes/2026-05-09-export-format-v1.md 的竖线格式已停用，不适用于此处。
const fs = require('node:fs');
const path = require('node:path');

const { appendEntry } = require('./store.js');

const SEPARATOR = '----------';
const QUOTE_PREFIX = '>> ';
const REVOKED_PREFIX = '[撤销]';
const SUPPORTED_VERSION = '2';

// 解析导出文本，返回 { entries, revoked }。entries 为可写入库存的笔记（不含 id，由 store 分配）。
function parseExport(text) {
  const lines = text.split(/\r?\n/);
  const header = lines[0] ?? '';
  const version = /^墨记导出 v(\d+)$/.exec(header.trim());
  if (!version) {
    throw new Error(`无法识别的导出文件头：${JSON.stringify(header)}`);
  }
  if (version[1] !== SUPPORTED_VERSION) {
    throw new Error(`导出格式 v${version[1]} 未支持，当前解析器只支持 v${SUPPORTED_VERSION}`);
  }

  const entries = [];
  const revoked = [];
  for (const block of splitBlocks(lines.slice(2))) {
    const [heading, time, ...body] = block;
    const parsed = /^(《.+》)\s+(\S.*)$/.exec(heading);
    if (!parsed) {
      throw new Error(`无法解析书名与作者：${JSON.stringify(heading)}`);
    }
    const entry = { book: parsed[1], author: parsed[2], time: time.trim() };

    const first = body[0] ?? '';
    if (first.startsWith(REVOKED_PREFIX)) {
      // 该条已在设备上删除，不是笔记正文，不写入库存。
      revoked.push({ ...entry, reason: first.slice(REVOKED_PREFIX.length).trim() });
      continue;
    }
    if (!first.startsWith(QUOTE_PREFIX)) {
      throw new Error(`无法识别的正文首行：${JSON.stringify(first)}`);
    }
    // 续行以缩进对齐 ">> "，缩进属于导出排版；换行属于笔记本身，保留。
    const text = [first.slice(QUOTE_PREFIX.length), ...body.slice(1).map((line) => line.trim())]
      .join('\n')
      .trimEnd();
    entries.push({ ...entry, text });
  }
  return { entries, revoked };
}

function splitBlocks(lines) {
  const blocks = [];
  let current = [];
  for (const line of lines) {
    if (line.trim() === SEPARATOR) {
      if (current.length > 0) blocks.push(current);
      current = [];
      continue;
    }
    if (current.length > 0 || line.trim().length > 0) current.push(line);
  }
  if (current.length > 0) blocks.push(current);
  return blocks.filter((block) => block.length >= 3);
}

// 读取导出文件，把其中的笔记追加进库存，返回写入的记录与跳过的条目。
function importClippings(storePath, exportPath) {
  const { entries, revoked } = parseExport(fs.readFileSync(exportPath, 'utf8'));
  const imported = entries.map((entry) => appendEntry(storePath, entry));
  return { imported, revoked };
}

module.exports = { parseExport, importClippings };

if (require.main === module) {
  const [exportPath, storePath = path.join('data', 'entries.jsonl')] = process.argv.slice(2);
  if (!exportPath) {
    console.error('用法：node src/import.js <导出文件> [库存文件]');
    process.exit(1);
  }
  const { imported, revoked } = importClippings(storePath, exportPath);
  console.log(`已导入 ${imported.length} 条，跳过 ${revoked.length} 条（已撤销）→ ${storePath}`);
  for (const record of imported) {
    console.log(`  + ${record.id} ${record.book} ${record.time}`);
  }
  for (const item of revoked) {
    console.log(`  - 跳过 ${item.book} ${item.time}：${item.reason}`);
  }
}
