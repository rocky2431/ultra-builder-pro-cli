# 工程事实记录

本文件记录项目级工程事实：从代码、数据或运行中确认、需要在后续任务中继续使用的事实。每条注明日期与出处（观察到它的文件或运行）。任务专有的临时结论不记在这里。

## 2026-08-20 库存为追加式 JSONL，id 由 store 分配

出处：`docs/decisions/2026-08-20-append-only-jsonl.md`、`src/store.js`。
库存每行一条 JSON；`appendEntry` 按现有行数分配 `entry-0001` 递增 id，写入方传 book/author/time/text，不传 id。

## 2026-09-09 「墨记」现行导出格式为 v2（块状），v1 竖线格式已停用

出处：`data/sample-export.txt`（实际导出文件）、`src/import.js`。
文件头两行（`墨记导出 v2` + `==========`），之后每条为三段：`《书名》 作者` / `YYYY-MM-DD HH:MM:SS` / 正文；条目间以 `----------` 分隔。正文首行以 `>> ` 开头，续行缩进三格对齐（缩进属排版，换行属笔记内容）。正文首行为 `[撤销]` 表示该条已在设备上删除，不入库。
`docs/notes/2026-05-09-export-format-v1.md` 的竖线分隔格式为 superseded，不可作为解析依据。
