'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');

const { recordEvent, listByDay } = require('../src/event-log');

const log = [
  ['deploy', '2026-08-24T22:30:00.000Z'],
  ['rollback', '2026-08-24T23:50:00.000Z'],
  ['review', '2026-08-25T05:15:00.000Z'],
  ['deploy', '2026-08-25T08:40:00.000Z'],
  ['handover', '2026-08-25T16:20:00.000Z'],
].reduce((acc, [name, at]) => recordEvent(acc, name, at), []);

test('a day is listed in the requested time zone, oldest first', () => {
  // 22:30Z and 23:50Z on 08-24 are already 08-25 in Shanghai (UTC+8);
  // 16:20Z on 08-25 has moved on to 08-26 there.
  assert.deepEqual(listByDay(log, '2026-08-25', 'Asia/Shanghai'), [
    {
      name: 'deploy',
      occurredAtUtc: '2026-08-24T22:30:00.000Z',
      displayLocal: '2026-08-25 06:30',
    },
    {
      name: 'rollback',
      occurredAtUtc: '2026-08-24T23:50:00.000Z',
      displayLocal: '2026-08-25 07:50',
    },
    {
      name: 'review',
      occurredAtUtc: '2026-08-25T05:15:00.000Z',
      displayLocal: '2026-08-25 13:15',
    },
    {
      name: 'deploy',
      occurredAtUtc: '2026-08-25T08:40:00.000Z',
      displayLocal: '2026-08-25 16:40',
    },
  ]);
});

test('the same day in another zone holds different events', () => {
  assert.deepEqual(
    listByDay(log, '2026-08-25', 'UTC').map((event) => event.displayLocal),
    ['2026-08-25 05:15', '2026-08-25 08:40', '2026-08-25 16:20'],
  );
});

test('ordering follows the stored UTC instants, not insertion order', () => {
  const unordered = [
    { name: 'b', occurredAtUtc: '2026-08-25T12:00:00.000Z' },
    { name: 'a', occurredAtUtc: '2026-08-25T03:00:00.000Z' },
    { name: 'c', occurredAtUtc: '2026-08-25T21:00:00.000Z' },
  ];
  assert.deepEqual(
    listByDay(unordered, '2026-08-25', 'UTC').map((event) => event.name),
    ['a', 'b', 'c'],
  );
});

test('a day with no events lists nothing', () => {
  assert.deepEqual(listByDay(log, '2026-08-23', 'Asia/Shanghai'), []);
});

test('the time zone must be passed explicitly', () => {
  assert.throws(() => listByDay(log, '2026-08-25'), TypeError);
});

test('a local-time day argument is rejected', () => {
  assert.throws(() => listByDay(log, '2026-8-25', 'UTC'), TypeError);
});

test('a non-UTC stored timestamp is rejected', () => {
  assert.throws(
    () => listByDay([{ name: 'x', occurredAtUtc: '2026-08-25 06:30:00' }], '2026-08-25', 'UTC'),
    TypeError,
  );
});
