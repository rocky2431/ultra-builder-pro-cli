'use strict';

// Every stored timestamp in this project is UTC ISO-8601 with a `Z` suffix.
// See docs/decisions/2026-08-30-utc-storage.md.
const UTC_ISO = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/;

function assertUtcIso(timestamp) {
  if (typeof timestamp !== 'string' || !UTC_ISO.test(timestamp)) {
    throw new TypeError(
      `timestamp must be UTC ISO-8601 ending in Z, received: ${timestamp}`,
    );
  }
  return timestamp;
}

function recordEvent(log, name, occurredAtUtc) {
  assertUtcIso(occurredAtUtc);
  return [...log, { name, occurredAtUtc }];
}

// Display boundary: the only place where a stored instant becomes local time.
function formatForDisplay(occurredAtUtc, timeZone) {
  assertUtcIso(occurredAtUtc);
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date(occurredAtUtc));
  const pick = (type) => parts.find((part) => part.type === type).value;
  return `${pick('year')}-${pick('month')}-${pick('day')} ${pick('hour')}:${pick('minute')}`;
}

// A calendar day only exists relative to a time zone, so this is a display
// boundary too: the caller passes the zone, we never read the machine default.
function dayKey(occurredAtUtc, timeZone) {
  assertUtcIso(occurredAtUtc);
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date(occurredAtUtc));
  const pick = (type) => parts.find((part) => part.type === type).value;
  return `${pick('year')}-${pick('month')}-${pick('day')}`;
}

// Counts events per calendar day in `timeZone`, oldest day first.
// Returns [{ day: 'YYYY-MM-DD', count }].
function countByDay(log, timeZone) {
  if (typeof timeZone !== 'string' || timeZone === '') {
    throw new TypeError('timeZone must be passed explicitly, e.g. "UTC"');
  }
  const counts = new Map();
  for (const event of log) {
    const day = dayKey(event.occurredAtUtc, timeZone);
    counts.set(day, (counts.get(day) ?? 0) + 1);
  }
  // Stored instants are UTC, and within one zone the day keys sort
  // chronologically as plain strings.
  return [...counts.entries()]
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
    .map(([day, count]) => ({ day, count }));
}

// Lists the events that fall on calendar day `day` ("YYYY-MM-DD") in
// `timeZone`, oldest first. `displayLocal` is that zone's wall clock, so the
// caller can eyeball the entries without converting anything themselves.
// Returns [{ name, occurredAtUtc, displayLocal }].
function listByDay(log, day, timeZone) {
  if (typeof day !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(day)) {
    throw new TypeError(`day must be "YYYY-MM-DD", received: ${day}`);
  }
  if (typeof timeZone !== 'string' || timeZone === '') {
    throw new TypeError('timeZone must be passed explicitly, e.g. "UTC"');
  }
  return log
    .filter((event) => dayKey(event.occurredAtUtc, timeZone) === day)
    // Ordering is decided on the stored UTC instants, never on local time.
    .sort((a, b) => Date.parse(a.occurredAtUtc) - Date.parse(b.occurredAtUtc))
    .map((event) => ({
      name: event.name,
      occurredAtUtc: event.occurredAtUtc,
      displayLocal: formatForDisplay(event.occurredAtUtc, timeZone),
    }));
}

module.exports = {
  assertUtcIso,
  recordEvent,
  formatForDisplay,
  countByDay,
  listByDay,
};
