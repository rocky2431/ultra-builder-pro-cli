# Project Brief

> **Authority**: raw owner intake captured by `ultra-init`. It preserves what the owner
> initially asked for and the broad outline needed to begin research. It is not an
> evidence-backed product baseline.
>
> **Lifecycle**: `ultra-research` reads this seed and promotes accepted conclusions into
> the North Star, specifications, domain language, or decisions. It does not rewrite the
> brief to make later conclusions look inevitable.

## One-line

「我每天开会记的东西到处都是，帮我弄个能整理会议记录的小东西吧。」——过后能按关键词找回「上次那个决定」，并看到它是哪天记的。

## Initial Outline

- What it is: 一个小工具，把每天开会记的东西收进一个统一的落点，事后可以按关键词检索回来。
- Broadly for whom or what: owner 本人单独使用。owner 原话：「就我一个人看，不共享。」不涉及团队协作、共享或多人权限。
- Intended result: owner 原话：「我要的是过后能找回『上次那个决定』——按关键词找出来，还能看到是哪天记的。」检索结果必须能带出记录日期。
- Broad boundary: 会议记录的收拢与检索。owner 在本次 intake 中明确排除了共享。以下均未被要求，未经 owner 确认不得纳入：待办事项抽取与跟进状态、自动摘要、日历／会议系统集成、多人协作。

## Explicit Inputs

- 单人使用，不共享（owner 明确陈述）。
- 检索入口是关键词（owner 明确陈述）。
- 检索结果需要呈现记录日期（owner 明确陈述）。
- owner 在三个候选轮廓（A 收拢+能找到／B 提炼+跟进／C 一次性收编）中确认了 A，并进一步把重点收窄为「找回决定」。
- 本项目起始于空目录：无既有代码、无既有文档、无既有 `.ultra/`、无 `.git`。骨架与 `git init` 由本次 Init 创建，尚未提交。

## Open Questions for Research

- **[未知——owner 材料，已问过一次，待答]** 这些会议记录现在实际存放在哪里（本地 Markdown、Notion、微信／飞书、纸质本子，或混合）？决定这个工具是否需要导入通道，以及是否需要一次性迁移既有笔记。在 owner 回答前，不得假定任何数据源，也不得访问任何 owner 账号。
- 记录是如何产生的：owner 是在会中当场记，还是会后整理？这决定录入入口的形态（即时录入 vs. 事后归档）。
- 「找回上次那个决定」的检索需要多强：纯文本关键词匹配是否足够，还是需要按会议主题／参会人／时间范围过滤？owner 目前只明确了关键词与日期两项。
- 记录规模量级（每天几场会、已积累多少条），影响检索实现的选型门槛。
- 尚未被要求但可能相邻的能力（待办抽取、摘要）是否属于后续，或应明确排除。
