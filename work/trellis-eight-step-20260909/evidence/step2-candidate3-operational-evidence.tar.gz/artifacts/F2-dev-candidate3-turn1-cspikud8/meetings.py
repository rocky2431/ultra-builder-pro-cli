#!/usr/bin/env python3
"""A tiny meeting-notes organizer: plain Markdown files, no dependencies.

Notes live in $MEETING_NOTES_DIR (default: ./notes) as notes/YYYY/YYYY-MM-DD-slug.md
with a small frontmatter block. Everything else is your own free-form Markdown.
"""

from __future__ import annotations

import argparse
import datetime as dt
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(os.environ.get("MEETING_NOTES_DIR") or Path(__file__).parent / "notes")

DATE_IN_NAME = re.compile(r"(20\d{2})[-_.]?(0[1-9]|1[0-2])[-_.]?(0[1-9]|[12]\d|3[01])")
DATE_ANYWHERE = re.compile(r"(20\d{2})[-/.年](\d{1,2})[-/.月](\d{1,2})[日号]?")
TODO_LINE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]\s*(.+?)\s*$")
MENTION = re.compile(r"@([^\s,，、;；]+)")
DUE = re.compile(r"[（(]?\s*(?:due|截止|deadline)\s*[:：]?\s*([0-9]{4}-[0-9]{2}-[0-9]{2})\s*[)）]?", re.I)

TEMPLATE = """---
title: {title}
date: {date}
attendees: [{attendees}]
tags: [{tags}]
---

# {title}

## 结论 / 决定
-

## 讨论
-

## 行动项
<!-- 格式：- [ ] @张三 做某事 (due: {due}) -->
"""


# --------------------------------------------------------------------------- model


@dataclass
class Note:
    path: Path
    meta: dict[str, object] = field(default_factory=dict)
    body: str = ""

    @property
    def title(self) -> str:
        return str(self.meta.get("title") or self.path.stem)

    @property
    def date(self) -> dt.date | None:
        raw = self.meta.get("date")
        try:
            return dt.date.fromisoformat(str(raw))
        except (TypeError, ValueError):
            return None

    def listval(self, key: str) -> list[str]:
        val = self.meta.get(key)
        return val if isinstance(val, list) else ([str(val)] if val else [])


def parse_note(path: Path) -> Note:
    text = path.read_text(encoding="utf-8", errors="replace")
    meta: dict[str, object] = {}
    body = text
    if text.startswith("---\n"):
        end = text.find("\n---", 4)
        if end != -1:
            for line in text[4:end].splitlines():
                if ":" not in line or line.lstrip().startswith("#"):
                    continue
                key, _, raw = line.partition(":")
                raw = raw.strip()
                if raw.startswith("[") and raw.endswith("]"):
                    meta[key.strip()] = [p.strip() for p in raw[1:-1].split(",") if p.strip()]
                else:
                    meta[key.strip()] = raw
            body = text[end + 4:].lstrip("\n")
    return Note(path=path, meta=meta, body=body)


def all_notes() -> list[Note]:
    notes = [parse_note(p) for p in sorted(ROOT.rglob("*.md"))]
    return sorted(notes, key=lambda n: (n.date or dt.date.min, n.path.name), reverse=True)


def slugify(title: str) -> str:
    """Keep CJK and word chars, collapse everything else into single dashes."""
    slug = re.sub(r"[^\w一-鿿]+", "-", title, flags=re.UNICODE).strip("-")
    return (slug or "meeting")[:40]


def target_path(date: dt.date, title: str) -> Path:
    path = ROOT / str(date.year) / f"{date.isoformat()}-{slugify(title)}.md"
    n = 2
    while path.exists():
        path = path.with_name(f"{date.isoformat()}-{slugify(title)}-{n}.md")
        n += 1
    return path


def rel(path: Path) -> str:
    try:
        return str(path.relative_to(Path.cwd()))
    except ValueError:
        return str(path)


# --------------------------------------------------------------------------- commands


def cmd_new(args: argparse.Namespace) -> int:
    date = dt.date.fromisoformat(args.date) if args.date else dt.date.today()
    title = args.title or f"{date.isoformat()} 会议"
    path = target_path(date, title)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        TEMPLATE.format(
            title=title,
            date=date.isoformat(),
            attendees=", ".join(args.attendee),
            tags=", ".join(args.tag),
            due=(date + dt.timedelta(days=7)).isoformat(),
        ),
        encoding="utf-8",
    )
    print(rel(path))
    if args.edit:
        editor = os.environ.get("EDITOR") or ("open" if sys.platform == "darwin" else "vi")
        subprocess.call([*editor.split(), str(path)])
    return 0


def guess_date(path: Path, text: str) -> dt.date:
    if m := DATE_IN_NAME.search(path.name):
        return dt.date(int(m[1]), int(m[2]), int(m[3]))
    for m in DATE_ANYWHERE.finditer(text[:2000]):
        try:
            return dt.date(int(m[1]), int(m[2]), int(m[3]))
        except ValueError:
            continue
    return dt.date.fromtimestamp(path.stat().st_mtime)


def strip_leading_date(title: str) -> str:
    """The date already lives in the filename; drop it from the title if repeated."""
    title = DATE_IN_NAME.sub("", title, count=1)
    title = DATE_ANYWHERE.sub("", title, count=1)
    return title.strip("-_.:：· ") or "会议"


def guess_title(path: Path, text: str) -> str:
    for line in text.splitlines()[:20]:
        if line.startswith("#"):
            if title := line.lstrip("#").strip():
                return strip_leading_date(title)
        elif line.strip() and not line.startswith("---"):
            return strip_leading_date(line.strip()[:60])
    return strip_leading_date(path.stem)


def cmd_import(args: argparse.Namespace) -> int:
    sources: list[Path] = []
    for raw in args.paths:
        p = Path(raw).expanduser()
        if p.is_dir():
            sources += [f for f in sorted(p.rglob("*")) if f.suffix.lower() in {".md", ".txt", ".markdown"}]
        elif p.is_file():
            sources.append(p)
        else:
            print(f"跳过（找不到）：{raw}", file=sys.stderr)

    already = {str(n.meta.get("source")) for n in all_notes() if n.meta.get("source")}
    imported = 0
    for src in sources:
        if ROOT in src.resolve().parents:
            continue  # already in the vault
        if str(src.resolve()) in already:
            print(f"已导入过，跳过：{rel(src)}")
            continue
        text = src.read_text(encoding="utf-8", errors="replace")
        date, title = guess_date(src, text), guess_title(src, text)
        dest = target_path(date, title)
        print(f"{rel(src)}  ->  {rel(dest)}   [{date} · {title}]")
        if args.dry_run:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        head = f"---\ntitle: {title}\ndate: {date.isoformat()}\nattendees: []\ntags: []\nsource: {src.resolve()}\n---\n\n"
        dest.write_text(head + text.lstrip(), encoding="utf-8")
        imported += 1

    if args.dry_run:
        print(f"\n共 {len(sources)} 个文件待导入（--dry-run，未写入）。去掉 --dry-run 即可执行。")
    else:
        print(f"\n已导入 {imported} 个文件，原文件保留未动。")
    return 0


def match_filters(note: Note, args: argparse.Namespace) -> bool:
    if args.since and (not note.date or note.date < dt.date.fromisoformat(args.since)):
        return False
    if args.until and (not note.date or note.date > dt.date.fromisoformat(args.until)):
        return False
    if args.person:
        haystack = " ".join(note.listval("attendees")) + " " + note.body
        if args.person not in haystack:
            return False
    if args.tag and args.tag not in note.listval("tags"):
        return False
    return True


def cmd_list(args: argparse.Namespace) -> int:
    notes = [n for n in all_notes() if match_filters(n, args)]
    for note in notes[: args.limit]:
        date = note.date.isoformat() if note.date else "????-??-??"
        who = "、".join(note.listval("attendees"))
        tags = " ".join(f"#{t}" for t in note.listval("tags"))
        open_todos = sum(1 for line in note.body.splitlines() if (m := TODO_LINE.match(line)) and m[1] == " ")
        extra = " ".join(x for x in (who, tags, f"[{open_todos} 项待办]" if open_todos else "") if x)
        print(f"{date}  {note.title}" + (f"   {extra}" if extra else ""))
    if not notes:
        print("没有匹配的会议记录。")
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    needle = args.query.lower()
    hits = 0
    for note in all_notes():
        if not match_filters(note, args):
            continue
        lines = [(i, l) for i, l in enumerate(note.body.splitlines(), 1) if needle in l.lower()]
        if not lines and needle not in note.title.lower():
            continue
        hits += 1
        print(f"\n{note.date or '????-??-??'}  {note.title}  ({rel(note.path)})")
        for lineno, line in lines[:5]:
            print(f"  {lineno}: {line.strip()}")
        if len(lines) > 5:
            print(f"  … 还有 {len(lines) - 5} 处匹配")
    print(f"\n共 {hits} 场会议命中。" if hits else "没有找到。")
    return 0


def cmd_todo(args: argparse.Namespace) -> int:
    rows = []
    for note in all_notes():
        if not match_filters(note, args):
            continue
        for line in note.body.splitlines():
            m = TODO_LINE.match(line)
            if not m or (m[1] != " " and not args.all):
                continue
            task = m[2]
            owner = MENTION.search(task)
            due = DUE.search(task)
            if args.person and args.person not in task:
                continue  # on todos, --person means "assigned to", not "attended"
            rows.append((
                due[1] if due else "",
                owner[1] if owner else "未指派",
                DUE.sub("", task).strip(),
                note.date.isoformat() if note.date else "????-??-??",
                note.title,
                m[1] != " ",
            ))

    if not rows:
        print("没有待办项。")
        return 0
    rows.sort(key=lambda r: (r[0] == "", r[0]))  # dated first, earliest first
    today = dt.date.today().isoformat()
    width = max(len(r[1]) for r in rows)
    for due, owner, task, date, title, done in rows:
        mark = "[x]" if done else "[ ]"
        flag = " ⚠️逾期" if due and due < today and not done else ""
        due_txt = f"  截止 {due}{flag}" if due else ""
        print(f"{mark} {owner:<{width}}  {task}{due_txt}")
        print(f"      ↳ {date} {title}")
    print(f"\n共 {len(rows)} 项。")
    return 0


# --------------------------------------------------------------------------- cli


def add_filters(p: argparse.ArgumentParser) -> None:
    p.add_argument("--since", metavar="YYYY-MM-DD", help="只看这天之后的")
    p.add_argument("--until", metavar="YYYY-MM-DD", help="只看这天之前的")
    p.add_argument("--person", help="按参与人 / @某人 过滤")
    p.add_argument("--tag", help="按标签过滤")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="meetings", description="会议记录整理小工具（纯 Markdown，无依赖）")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("new", help="新建一份会议记录")
    p.add_argument("title", nargs="?", help="会议标题")
    p.add_argument("--date", metavar="YYYY-MM-DD", help="默认今天")
    p.add_argument("--attendee", "-a", action="append", default=[], help="参与人，可重复")
    p.add_argument("--tag", "-t", action="append", default=[], help="标签，可重复")
    p.add_argument("--edit", "-e", action="store_true", help="创建后用 $EDITOR 打开")
    p.set_defaults(func=cmd_new)

    p = sub.add_parser("import", help="把散落各处的笔记归拢进来（复制，不动原文件）")
    p.add_argument("paths", nargs="+", help="文件或目录")
    p.add_argument("--dry-run", "-n", action="store_true", help="只看会怎么归类，不写入")
    p.set_defaults(func=cmd_import)

    p = sub.add_parser("list", help="列出会议记录")
    p.add_argument("--limit", "-l", type=int, default=30)
    add_filters(p)
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("search", help="全文搜索")
    p.add_argument("query")
    add_filters(p)
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("todo", help="汇总所有会议的行动项")
    p.add_argument("--all", action="store_true", help="连已完成的一起列出")
    add_filters(p)
    p.set_defaults(func=cmd_todo)

    args = parser.parse_args(argv)
    ROOT.mkdir(parents=True, exist_ok=True)
    try:
        return args.func(args)
    except ValueError as e:
        print(f"参数有误：{e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
