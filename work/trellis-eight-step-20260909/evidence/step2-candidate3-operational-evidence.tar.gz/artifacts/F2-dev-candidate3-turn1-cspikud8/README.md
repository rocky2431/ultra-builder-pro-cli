# 会议记录小工具

一个单文件命令行工具，把散落各处的会议记录收拢到一个文件夹里，并且能随时翻出来
"这事当时谁答应的、什么时候截止"。

- **纯 Markdown**：每场会议一个 `.md` 文件，用任何编辑器都能改。想换工具，把文件夹搬走即可。
- **零依赖**：只用 Python 3 标准库（本机 3.12.10 已验证）。不联网、不上传、不装东西。
- **不动你的原文件**：`import` 是复制，原件原地保留。

## 用起来

```bash
python3 meetings.py --help          # 或 chmod +x meetings.py 后直接 ./meetings.py
```

### 1. 先把散落的旧笔记收进来

```bash
python3 meetings.py import ~/Desktop ~/Downloads/会议 --dry-run   # 先看它怎么归类
python3 meetings.py import ~/Desktop ~/Downloads/会议            # 确认没问题再执行
```

会递归扫 `.md` / `.txt` / `.markdown`，日期取自**文件名 → 正文里的第一个日期 → 文件修改时间**
（顺序如此），标题取自第一个 `#` 标题或第一行。**建议先跑 `--dry-run` 看一眼猜得对不对。**
重复导入会自动跳过（靠 frontmatter 里的 `source:` 字段识别）。

### 2. 开会当天新建一份

```bash
python3 meetings.py new "产品周会" -a 张三 -a 李四 -t 周会 --edit
```

生成一份带模板的记录（结论 / 讨论 / 行动项），`--edit` 会用 `$EDITOR` 直接打开。

### 3. 事后翻账

```bash
python3 meetings.py list --since 2026-09-01        # 列会议，顺带显示各有几项待办
python3 meetings.py search 导出功能                 # 全文搜索，带行号
python3 meetings.py todo                           # 汇总所有未完成行动项，按截止日排序
python3 meetings.py todo --person 李四              # 只看指派给某人的
python3 meetings.py todo --all                     # 连已完成的一起看
```

`list` / `search` / `todo` 都支持 `--since` `--until` `--person` `--tag`。
逾期的行动项会标 ⚠️。

## 文件长这样

存放位置默认是本目录下的 `notes/`，可用环境变量 `MEETING_NOTES_DIR` 改
（比如指到你的 iCloud 或坚果云目录，就能多设备同步）。

```
notes/2026/2026-09-01-产品周会.md
```

```markdown
---
title: 产品周会
date: 2026-09-01
attendees: [张三, 李四]
tags: [周会, 产品]
---

# 产品周会

## 结论 / 决定
- Q4 优先做导出功能

## 行动项
- [ ] @李四 出一版导出的交互稿 (due: 2026-09-05)
- [x] @王五 发会议纪要
```

工具只认两个约定，其余随便写：

| 约定 | 作用 |
| --- | --- |
| `- [ ] ...` / `- [x] ...` | 识别为行动项（未完成 / 已完成） |
| `@某人`、`(due: 2026-09-05)` | 提取负责人和截止日期，`截止:` / `deadline:` 同样识别 |

frontmatter 里的 `attendees` / `tags` 可以不写，写了 `list` 才能按人和标签筛。
