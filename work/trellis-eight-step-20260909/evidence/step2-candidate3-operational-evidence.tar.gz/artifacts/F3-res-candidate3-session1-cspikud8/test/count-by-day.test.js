'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');

const { recordEvent, countByDay } = require('../src/event-log');

const log = [
  ['deploy', '2026-08-24T22:30:00.000Z'],
  ['rollback', '2026-08-24T23:50:00.000Z'],
  ['deploy', '2026-08-25T09:00:00.000Z'],
].reduce((acc, [name, at]) => recordEvent(acc, name, at), []);

test('counts per day are bucketed in the requested time zone', () => {
  assert.deepEqual(countByDay(log, 'UTC'), [
    { day: '2026-08-24', count: 2 },
    { day: '2026-08-25', count: 1 },
  ]);
});

test('a different time zone moves events across the day boundary', () => {
  // 22:30Z and 23:50Z are already 2026-08-25 in Shanghai (UTC+8).
  assert.deepEqual(countByDay(log, 'Asia/Shanghai'), [
    { day: '2026-08-25', count: 3 },
  ]);
});

test('days come back oldest first regardless of insertion order', () => {
  const unordered = [
    { name: 'b', occurredAtUtc: '2026-08-26T00:00:00.000Z' },
    { name: 'a', occurredAtUtc: '2026-08-24T00:00:00.000Z' },
    { name: 'c', occurredAtUtc: '2026-08-25T00:00:00.000Z' },
  ];
  assert.deepEqual(
    countByDay(unordered, 'UTC').map((entry) => entry.day),
    ['2026-08-24', '2026-08-25', '2026-08-26'],
  );
});

test('an empty log counts to no days', () => {
  assert.deepEqual(countByDay([], 'UTC'), []);
});

test('the time zone must be passed explicitly', () => {
  assert.throws(() => countByDay(log), TypeError);
});

test('a non-UTC stored timestamp is rejected', () => {
  assert.throws(
    () => countByDay([{ name: 'x', occurredAtUtc: '2026-08-25 06:30:00' }], 'UTC'),
    TypeError,
  );
});
