'use strict';

const { createHash } = require('node:crypto');

// A slug built only from [a-z0-9] is empty whenever the title has no ASCII
// alphanumerics, and every such note would then be stored under the same
// filename. Those titles fall back to a digest of the title instead.
//
// The fallback is prefixed with a doubled separator, which the ASCII pipeline
// below can never emit (it collapses each run of separators into one '-'), so
// a fallback slug can never collide with the slug of an ASCII title.
const FALLBACK_PREFIX = 'note--';

function fallbackSlug(title) {
  // Normalize first: macOS hands back decomposed (NFD) strings in places, and
  // the same title must always digest to the same slug.
  const digest = createHash('sha1').update(title.normalize('NFC'), 'utf8').digest('hex');
  return FALLBACK_PREFIX + digest.slice(0, 12);
}

// Build a filesystem- and URL-safe slug for a note title.
function slugify(title) {
  const text = String(title);
  const slug = text
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');

  return slug === '' ? fallbackSlug(text) : slug;
}

module.exports = { slugify };
