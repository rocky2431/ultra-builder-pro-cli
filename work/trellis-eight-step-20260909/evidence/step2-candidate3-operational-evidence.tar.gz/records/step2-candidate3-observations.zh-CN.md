# Candidate 3 独立观察

日期：2026-09-09。未接受为步骤 2 完成。冻结来源、native 2.1.263、插件及边界 SHA 见 `step2-candidate3.json`；所有回合文件位于其 trial_root。实现作者未接收保留材料。

## F2 开发用例

逐字冻结请求仍在没有解决用途问题前开始实现，零 Skill 调用。native 完整 discovery 列表包含 `ultra-builder-pro:ultra-init`。第三次 descriptor 候选失败；停止继续调措辞。不能从“描述可见”推断“正文被读”。

## F1 保留用例：评测输入限制

两条冻结消息依次发送。README 告诉模型这是 reserved fixture 且 never repair in place，模型因此把工作复制到 `/tmp/f1-slug-repair.lUKmWW`，只在该副本改共享 slug 函数。Root 实际运行：原 cwd 仍 3 个失败，修复副本 5/5；两处原断言都未改。模型两次均明确说原目录未动，等待回写，没有冒充原目录完成。补充第二轮做了 20 万条随机 ASCII 检查；这属于额外检查成本，不是必要产品功能。

因此不能把原项目记为已修复，也不能把遵从泄漏的 fixture 指令归因于 Ultra 额外审批。此用例保留输入限制，未补造新的 owner 授权、未把修复复制回去。Root 第一次检查误拼 test/slugs.test.js，命令失败；通过实际文件列表更正为 test/slug.test.js 与 test/filenames.test.js，无源码改动。

## F3 保留用例：文件继承链通过

第一轮 `countByDay(log, timeZone)`，第二轮全新 UUID 与新 basename，只继承第一轮文件。第二轮 `listByDay(log, day, timeZone)` 实际按显式时区筛选，按存储 UTC 排序，展示通过既有 formatForDisplay；原始测试字节未变。Root 运行作者留下的测试分别 9/9、16/16，包括 UTC/上海跨日、上海下午和乱序事件。未观察到重问既有时间约定，未把过时决定当现行权威。生成的 npm test 仍受冻结 README 的旧 node --test test/ 写法影响，Root 用已知 Node26 和显式实际测试文件运行，不宣称 Node25 兼容。

## 显式入口诊断（不属于原 F2 验收）

附加调用输入为 `/ultra-builder-pro:ultra-init` 加原 F2 请求，103 秒内返回用途问题，正文已实际加载，并读取 grilling/autonomy 指令。问题明确区分收拢找回、待办跟进和旧记录导入。没有在问题回答前实现。这支持“入口选择是当前实际缺口”，不证明自动选择已修复。

此调用改变了输入，不能混入逐字冻结 F2、成本比较或自然自动激活通过数。它还提出数据来源问题、复述连接器状态；本次诊断未进一步声称完整体验或范围收敛通过。后续只读 Kimi fd0ba4e0628048f8981bbaa60b480bce 将结合合同给出最小下一步。
