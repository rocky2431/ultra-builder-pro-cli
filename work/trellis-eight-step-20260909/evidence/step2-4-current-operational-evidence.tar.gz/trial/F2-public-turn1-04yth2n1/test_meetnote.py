#!/usr/bin/env python3
"""Tests for meetnote. Run: python3 -m unittest -v test_meetnote"""

import io
import os
import tempfile
import unittest
from contextlib import redirect_stdout
from datetime import date, timedelta
from pathlib import Path
from unittest import mock

import meetnote as mn

SCATTERED_NOTE = """2026-09-07 周会

参会: 张三 李四

## 决定
- 登录改造放到下个迭代
- 决定：先上灰度

待办: @张三 出一份灰度方案 due 2026-09-12
- [ ] @李四 盘一下埋点
- [x] 拉群
"""


class ParsingTest(unittest.TestCase):
    def test_front_matter_splits_meta_and_body(self):
        meta, body = mn.parse_front_matter("---\ntitle: 周会\ndate: 2026-09-09\n---\n\n正文\n")
        self.assertEqual(meta, {"title": "周会", "date": "2026-09-09"})
        self.assertEqual(body.strip(), "正文")

    def test_front_matter_absent_returns_text_untouched(self):
        meta, body = mn.parse_front_matter("正文\n")
        self.assertEqual(meta, {})
        self.assertEqual(body, "正文\n")

    def test_normalize_date_accepts_handwritten_shapes(self):
        for raw in ("2026-09-09", "2026/9/9", "2026.09.09", "2026年9月9日", "20260909"):
            self.assertEqual(mn.normalize_date(raw), date(2026, 9, 9), raw)

    def test_normalize_date_rejects_impossible_date(self):
        self.assertIsNone(mn.normalize_date("2026-13-40"))
        self.assertIsNone(mn.normalize_date("随手记"))

    def test_guess_title_drops_leading_date(self):
        self.assertEqual(mn.guess_title(Path("x.txt"), "2026-09-07 周会\n\n正文"), "周会")

    def test_guess_title_prefers_heading(self):
        self.assertEqual(mn.guess_title(Path("x.md"), "# 需求评审\n\n正文"), "需求评审")

    def test_slugify_keeps_cjk_and_collapses_punctuation(self):
        self.assertEqual(mn.slugify("周会 / 登录改造!!"), "周会-登录改造")
        self.assertEqual(mn.slugify("!!!"), "note")

    def test_parse_since_relative_and_absolute(self):
        self.assertEqual(mn.parse_since("7d"), date.today() - timedelta(days=7))
        self.assertEqual(mn.parse_since("2w"), date.today() - timedelta(days=14))
        self.assertEqual(mn.parse_since("2026-09-01"), date(2026, 9, 1))
        self.assertIsNone(mn.parse_since(None))
        with self.assertRaises(ValueError):
            mn.parse_since("上周")


class NoteTest(unittest.TestCase):
    def note(self, body: str, meta: dict | None = None) -> mn.Note:
        return mn.Note(path=Path("2026-09-09-x.md"), meta=meta or {}, body=body)

    def test_todos_capture_owner_and_due(self):
        todos = self.note("- [ ] @张三 出方案 due 2026-09-12\n").todos()
        self.assertEqual(len(todos), 1)
        self.assertEqual(todos[0].owner, "张三")
        self.assertEqual(todos[0].due, date(2026, 9, 12))
        self.assertFalse(todos[0].done)

    def test_todos_read_done_marker_and_chinese_prefix(self):
        todos = self.note("- [x] 拉群\n待办: 补文档\n").todos()
        self.assertEqual([todo.done for todo in todos], [True, False])
        self.assertEqual(todos[1].text, "补文档")

    def test_todos_ignore_empty_checkbox_placeholder(self):
        self.assertEqual(self.note("- [ ] @ \n- [ ]  due 2026-09-12\n").todos(), [])

    def test_overdue_only_for_open_past_items(self):
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        todos = self.note(f"- [ ] a due {yesterday}\n- [x] b due {yesterday}\n").todos()
        self.assertEqual([todo.overdue for todo in todos], [True, False])

    def test_decisions_from_heading_section_and_inline(self):
        decisions = self.note(SCATTERED_NOTE).decisions()
        self.assertIn("登录改造放到下个迭代", decisions)
        self.assertIn("先上灰度", decisions)

    def test_decision_section_ends_at_next_heading(self):
        decisions = self.note("## 决定\n- 甲\n\n## 其他\n- 乙\n").decisions()
        self.assertEqual(decisions, ["甲"])

    def test_attendees_split_on_mixed_separators(self):
        note = self.note("", {"attendees": "张三, 李四、王五"})
        self.assertEqual(note.attendees, ["张三", "李四", "王五"])

    def test_attendees_fall_back_to_a_line_in_the_body(self):
        self.assertEqual(self.note(SCATTERED_NOTE).attendees, ["张三", "李四"])

    def test_split_list_keeps_multi_word_latin_names_intact(self):
        self.assertEqual(mn.split_list("John Smith, 张三 李四"), ["John Smith", "张三", "李四"])


class ArchiveTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.home = self.root / "archive"
        self.source_dir = self.root / "scattered"
        self.source_dir.mkdir()
        (self.source_dir / "0907周会.txt").write_text(SCATTERED_NOTE, encoding="utf-8")
        (self.source_dir / "2026-09-08-评审.md").write_text(
            "# 需求评审\n\n- [ ] @王五 补 PRD\n", encoding="utf-8"
        )
        self.addCleanup(self.tmp.cleanup)

    def run_cli(self, *argv: str) -> str:
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            code = mn.main(["--home", str(self.home), *argv])
        self.assertEqual(code, 0, buffer.getvalue())
        return buffer.getvalue()

    def test_free_path_never_returns_existing_file(self):
        archive = mn.Archive(self.home)
        first = archive.write(archive.free_path(date(2026, 9, 9), "周会"), "a")
        second = archive.write(archive.free_path(date(2026, 9, 9), "周会"), "b")
        self.assertNotEqual(first, second)
        self.assertEqual(first.read_text(encoding="utf-8"), "a")
        self.assertTrue(second.name.endswith("-2.md"))

    def test_write_refuses_to_overwrite(self):
        archive = mn.Archive(self.home)
        path = archive.write(archive.free_path(date(2026, 9, 9), "周会"), "a")
        with self.assertRaises(FileExistsError):
            archive.write(path, "b")

    def test_collect_input_files_excludes_the_archive_itself(self):
        archive = mn.Archive(self.home)
        archive.write(archive.free_path(date(2026, 9, 9), "周会"), "a")
        found = mn.collect_input_files([self.root], self.home)
        self.assertEqual(
            sorted(path.name for path in found), ["0907周会.txt", "2026-09-08-评审.md"]
        )

    def test_import_leaves_every_original_byte_identical(self):
        before = {
            path: (path.read_bytes(), path.stat().st_mtime)
            for path in sorted(self.source_dir.iterdir())
        }
        self.run_cli("import", str(self.source_dir))
        after = {
            path: (path.read_bytes(), path.stat().st_mtime)
            for path in sorted(self.source_dir.iterdir())
        }
        self.assertEqual(before, after)

    def test_import_derives_date_from_filename_and_body(self):
        self.run_cli("import", str(self.source_dir))
        names = sorted(path.name for path in self.home.rglob("*.md"))
        self.assertEqual(names, ["2026-09-07-周会.md", "2026-09-08-需求评审.md"])

    def test_import_records_source_and_skips_on_rerun(self):
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("import", str(self.source_dir))
        self.assertIn("跳过（已导入）", output)
        self.assertIn("导入 0 篇，跳过 2 篇", output)
        self.assertEqual(len(list(self.home.rglob("*.md"))), 2)

    def test_import_skips_empty_file(self):
        (self.source_dir / "empty.md").write_text("\n\n", encoding="utf-8")
        output = self.run_cli("import", str(self.source_dir))
        self.assertIn("跳过（空文件）", output)

    def test_import_reads_gb18030_source(self):
        (self.source_dir / "gbk.txt").write_bytes("2026-09-06 立项会\n- [ ] 排期\n".encode("gb18030"))
        self.run_cli("import", str(self.source_dir))
        note = mn.Note.load(self.home / "2026" / "2026-09-06-立项会.md")
        self.assertEqual(note.title, "立项会")

    def test_import_missing_path_reports_error(self):
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            code = mn.main(["--home", str(self.home), "import", str(self.root / "nope")])
        self.assertEqual(code, 1)

    def test_list_shows_open_todo_count(self):
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("list", "--since", "2026-09-01")
        self.assertIn("2026-09-08", output)
        self.assertIn("需求评审", output)
        self.assertIn("共 2 篇", output)

    def test_list_on_empty_archive_points_at_import(self):
        self.assertIn("还没有记录", self.run_cli("list"))

    def test_search_is_and_across_words(self):
        self.run_cli("import", str(self.source_dir))
        self.assertIn("命中 1 篇", self.run_cli("search", "灰度", "方案"))
        self.assertIn("没有命中", self.run_cli("search", "灰度", "PRD"))

    def test_todos_aggregates_open_items_across_notes(self):
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("todos")
        self.assertIn("出一份灰度方案", output)
        self.assertIn("补 PRD", output)
        self.assertNotIn("拉群", output)  # done items hidden by default
        self.assertIn("共 3 条", output)

    def test_todos_filter_by_owner(self):
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("todos", "--owner", "@王五")
        self.assertIn("补 PRD", output)
        self.assertNotIn("灰度方案", output)

    def test_todos_all_includes_done(self):
        self.run_cli("import", str(self.source_dir))
        self.assertIn("[x]", self.run_cli("todos", "--all"))

    def test_import_writes_body_attendees_into_front_matter(self):
        self.run_cli("import", str(self.source_dir))
        note = mn.Note.load(self.home / "2026" / "2026-09-07-周会.md")
        self.assertEqual(note.meta["attendees"], "张三, 李四")

    def test_digest_lists_meetings_decisions_and_open_todos(self):
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("digest", "--since", "2026-09-01")
        self.assertIn("## 会议（2）", output)
        self.assertIn("先上灰度", output)
        self.assertIn("补 PRD", output)

    def test_digest_does_not_repeat_the_inline_due_date(self):
        (self.source_dir / "due.md").write_text(
            "# 排期会\n\n- [ ] 交方案 due 2026-09-12\n", encoding="utf-8"
        )
        self.run_cli("import", str(self.source_dir))
        output = self.run_cli("digest", "--since", "2026-09-01")
        self.assertIn("- [ ] 交方案 due 2026-09-12 — ", output)
        self.assertNotIn("(截止 2026-09-12)", output)

    def test_digest_output_refuses_to_overwrite(self):
        target = self.root / "digest.md"
        target.write_text("已有内容", encoding="utf-8")
        buffer = io.StringIO()
        with redirect_stdout(buffer):
            code = mn.main(["--home", str(self.home), "digest", "-o", str(target)])
        self.assertEqual(code, 1)
        self.assertEqual(target.read_text(encoding="utf-8"), "已有内容")

    def test_new_captures_stdin_into_the_note(self):
        with mock.patch("sys.stdin", io.StringIO("随手记的原文\n")):
            self.run_cli("new", "周会", "--date", "2026-09-09", "--attendees", "张三,李四")
        note = mn.Note.load(self.home / "2026" / "2026-09-09-周会.md")
        self.assertEqual(note.attendees, ["张三", "李四"])
        self.assertIn("随手记的原文", note.body)
        self.assertEqual(note.todos(), [])  # empty template checkbox is not a task

    def test_home_falls_back_to_env_then_default(self):
        with mock.patch.dict(os.environ, {"MEETNOTE_HOME": str(self.home)}):
            self.assertEqual(mn.resolve_home(None), self.home)
        with mock.patch.dict(os.environ, {}, clear=True):
            self.assertEqual(mn.resolve_home(None), Path(mn.DEFAULT_HOME).expanduser())


if __name__ == "__main__":
    unittest.main()
