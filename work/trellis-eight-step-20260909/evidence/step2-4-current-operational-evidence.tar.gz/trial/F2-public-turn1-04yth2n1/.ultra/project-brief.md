# Project Brief

> **Authority**: raw owner intake captured by `ultra-init`. It preserves what the owner
> initially asked for and the broad outline needed to begin research. It is not an
> evidence-backed product baseline.
>
> **Lifecycle**: `ultra-research` reads this seed and promotes accepted conclusions into
> the North Star, specifications, domain language, or decisions. It does not rewrite the
> brief to make later conclusions look inevitable.

## One-line

owner 原话：「我每天开会记的东西到处都是，帮我弄个能整理会议记录的小东西吧。」

## Initial Outline

- What it is: 一个本地命令行小工具（`meetnote`），把散落各处的会议记录收进一个统一的
  markdown 归档，并把里面的待办、决定、关键词捞出来。
- Broadly for whom or what: owner 自己（rocky@paimon.finance），每天开会、随手记、
  记完就找不到的个人使用场景。
- Intended result: 记录只有一个落地的地方；「上周那个会到底决定了什么」和
  「我身上还有哪些没做的事」可以在几秒内查到，而不用翻各个 App。
- Broad boundary: 本地文件、纯 markdown、零依赖；只读取 owner 指给它的路径。
  不做录音转写、不做团队协作/服务端、不自动往任何外部服务写东西。

## Explicit Inputs

- owner 说记录「到处都是」——分散是这个工具要解决的核心现象（原话，未追问细节）。
- 「小东西」——owner 明确要的是小工具，不是平台；实现按最小可用范围做。
- 归档格式选纯 markdown 文件（模型决定，属自主边界内）：owner 随时能自己看、
  自己 grep、自己搬走，不被工具锁住。
- 导入一律**只复制不删除、不覆盖**（模型决定）：原始记录不能因为整理而丢。

## Open Questions for Research

- owner 的会议记录现在**实际存在哪些地方**（本地文件夹 / Notion / Apple 备忘录 /
  飞书或微信聊天 / 纸质）？这是 init 无法从仓库或环境观测到的 owner 自有材料，
  已在第一轮向 owner 提问；答案只影响 import 的接入方式，不影响归档与查询内核。
- 「整理」对 owner 的优先级排序：是更看重**事后能查到决定**，还是更看重
  **每天盯自己的待办**？v1 两者都做了最小实现，实际用过之后再决定往哪边加深。
- 是否需要接入 Notion（本机已配置 Notion connector，但属项目外写入，
  未获授权、v1 未实现）。
