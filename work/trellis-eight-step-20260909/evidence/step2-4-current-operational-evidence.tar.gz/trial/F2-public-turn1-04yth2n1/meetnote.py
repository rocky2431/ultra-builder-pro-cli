#!/usr/bin/env python3
"""meetnote - collect scattered meeting notes into one markdown archive.

Storage is plain markdown files under a single home directory (default
~/meeting-notes, override with MEETNOTE_HOME or --home):

    <home>/<YYYY>/<YYYY-MM-DD>-<slug>.md

Import only ever copies: originals are never moved, rewritten or deleted, and an
existing archive file is never overwritten.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
import unicodedata
from dataclasses import dataclass, field
from datetime import date, timedelta
from pathlib import Path

DEFAULT_HOME = "~/meeting-notes"
NOTE_SUFFIXES = (".md", ".markdown", ".txt")
MAX_SLUG = 40

FRONT_MATTER_RE = re.compile(r"\A---\r?\n(.*?)\r?\n---[ \t]*\r?\n?", re.DOTALL)
CHECKBOX_RE = re.compile(r"^\s*[-*+]\s*\[([ xX])\]\s*(.+?)\s*$")
LOOSE_TODO_RE = re.compile(r"^\s*(?:[-*+]\s*)?(?:TODO|todo|待办|action)\s*[:：]\s*(.+?)\s*$")
OWNER_RE = re.compile(r"@([A-Za-z0-9_.\-一-鿿]+)")
DUE_RE = re.compile(
    r"(?:due|deadline|截止|ddl)\s*[:：]?\s*"
    r"(\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{4}年\d{1,2}月\d{1,2}日)",
    re.IGNORECASE,
)
HEADING_RE = re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$")
ATTENDEE_RE = re.compile(
    r"^\s*(?:[-*+]\s*)?(?:参会人?员?|参与人|参加人|出席|与会|attendees?|participants?)"
    r"\s*[:：]\s*(.+?)\s*$",
    re.IGNORECASE,
)
DECISION_HEADING_RE = re.compile(r"决定|决议|结论|共识|decision", re.IGNORECASE)
DECISION_INLINE_RE = re.compile(r"^\s*(?:[-*+]\s*)?(?:决定|决议|结论)\s*[:：]\s*(.+?)\s*$")
LIST_ITEM_RE = re.compile(r"^\s*[-*+]\s+(.+?)\s*$")
DATE_PATTERNS = (
    re.compile(r"(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})"),
    re.compile(r"(\d{4})年(\d{1,2})月(\d{1,2})日"),
    re.compile(r"(?<!\d)(\d{4})(\d{2})(\d{2})(?!\d)"),
)
SINCE_RE = re.compile(r"^(\d+)([dwm])$")

NOTE_TEMPLATE = """## 议题

-

## 决定

-

## 待办

- [ ]

## 原始记录

{raw}
"""


# --------------------------------------------------------------------------- #
# parsing


def parse_front_matter(text: str) -> tuple[dict[str, str], str]:
    """Split a leading `---` block into flat key/value pairs plus the body.

    Deliberately not YAML: notes only carry `key: value` lines, so a real
    parser would be a dependency for no gain. Unknown shapes fall through as
    body text instead of raising.
    """
    match = FRONT_MATTER_RE.match(text)
    if not match:
        return {}, text
    meta: dict[str, str] = {}
    for line in match.group(1).splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, sep, value = line.partition(":")
        if not sep:
            continue
        meta[key.strip().lower()] = value.strip().strip("'\"")
    return meta, text[match.end():]


def render_front_matter(meta: dict[str, str]) -> str:
    lines = [f"{key}: {value}" for key, value in meta.items() if value not in (None, "")]
    return "---\n" + "\n".join(lines) + "\n---\n"


def normalize_date(raw: str) -> date | None:
    """Accept the date shapes that turn up in hand-written notes."""
    if not raw:
        return None
    raw = raw.strip()
    for pattern in DATE_PATTERNS:
        match = pattern.search(raw)
        if not match:
            continue
        year, month, day = (int(part) for part in match.groups())
        try:
            return date(year, month, day)
        except ValueError:
            continue
    return None


def guess_date(path: Path, text: str, meta: dict[str, str] | None = None) -> date:
    """Front matter wins, then the filename, then the first lines, then mtime."""
    meta = meta or {}
    for candidate in (meta.get("date", ""), path.name):
        found = normalize_date(candidate)
        if found:
            return found
    head = "\n".join(text.splitlines()[:20])
    found = normalize_date(head)
    if found:
        return found
    return date.fromtimestamp(path.stat().st_mtime)


def guess_title(path: Path, text: str, meta: dict[str, str] | None = None) -> str:
    meta = meta or {}
    if meta.get("title"):
        return meta["title"]
    for line in text.splitlines():
        heading = HEADING_RE.match(line)
        if heading:
            return heading.group(1).strip()
        stripped = line.strip()
        if stripped and not stripped.startswith("---"):
            # Drop a leading date so "2026-09-09 周会" titles as "周会".
            for pattern in DATE_PATTERNS:
                stripped = pattern.sub("", stripped, count=1).strip(" -–—:：")
            if stripped:
                return stripped[:60]
    return path.stem


def slugify(title: str) -> str:
    """Keep CJK readable in filenames; collapse everything else to dashes."""
    text = unicodedata.normalize("NFKC", title).strip().lower()
    text = re.sub(r"[^\w一-鿿]+", "-", text, flags=re.UNICODE)
    text = re.sub(r"-{2,}", "-", text).strip("-_")
    return text[:MAX_SLUG].strip("-_") or "note"


@dataclass
class Todo:
    text: str
    done: bool
    owner: str | None
    due: date | None
    note: "Note"
    line_no: int

    @property
    def overdue(self) -> bool:
        return bool(self.due and not self.done and self.due < date.today())


@dataclass
class Note:
    path: Path
    meta: dict[str, str] = field(default_factory=dict)
    body: str = ""

    @classmethod
    def load(cls, path: Path) -> "Note":
        text = read_text(path)
        meta, body = parse_front_matter(text)
        return cls(path=path, meta=meta, body=body)

    @property
    def title(self) -> str:
        return self.meta.get("title") or guess_title(self.path, self.body, self.meta)

    @property
    def date(self) -> date:
        return normalize_date(self.meta.get("date", "")) or guess_date(
            self.path, self.body, self.meta
        )

    @property
    def attendees(self) -> list[str]:
        return split_list(self.meta.get("attendees") or find_attendees(self.body))

    @property
    def tags(self) -> list[str]:
        return split_list(self.meta.get("tags", ""))

    def todos(self) -> list[Todo]:
        found: list[Todo] = []
        for line_no, line in enumerate(self.body.splitlines(), start=1):
            checkbox = CHECKBOX_RE.match(line)
            loose = None if checkbox else LOOSE_TODO_RE.match(line)
            if checkbox:
                done = checkbox.group(1).lower() == "x"
                text = checkbox.group(2)
            elif loose:
                done, text = False, loose.group(1)
            else:
                continue
            if not strip_markers(text):
                continue  # an empty "- [ ]" placeholder is not a task
            owner_match = OWNER_RE.search(text)
            due_match = DUE_RE.search(text)
            found.append(
                Todo(
                    text=text,
                    done=done,
                    owner=owner_match.group(1) if owner_match else None,
                    due=normalize_date(due_match.group(1)) if due_match else None,
                    note=self,
                    line_no=line_no,
                )
            )
        return found

    def decisions(self) -> list[str]:
        """List items under a decision heading, plus inline `决定：...` lines."""
        found: list[str] = []
        in_section = False
        for line in self.body.splitlines():
            heading = HEADING_RE.match(line)
            if heading:
                in_section = bool(DECISION_HEADING_RE.search(heading.group(1)))
                continue
            inline = DECISION_INLINE_RE.match(line)
            if inline:
                if strip_markers(inline.group(1)):
                    found.append(inline.group(1).strip())
                continue
            if not in_section:
                continue
            item = LIST_ITEM_RE.match(line)
            if item and not CHECKBOX_RE.match(line) and strip_markers(item.group(1)):
                found.append(item.group(1).strip())
        return found


def find_attendees(body: str) -> str:
    """A hand-written `参会: 张三 李四` line is as good as front matter."""
    for line in body.splitlines()[:15]:
        match = ATTENDEE_RE.match(line)
        if match:
            return match.group(1)
    return ""


def split_list(value: str) -> list[str]:
    parts = re.split(r"[,，;；、/]\s*|\s{2,}", value.strip())
    names: list[str] = []
    for part in (part.strip() for part in parts):
        if not part:
            continue
        # "张三 李四 我" is three people; "John Smith" is one.
        if " " in part and not re.search(r"[A-Za-z]", part):
            names.extend(word for word in part.split() if word)
        else:
            names.append(part)
    return names


def strip_markers(text: str) -> str:
    """Text left once owner/due markers and punctuation are removed."""
    text = OWNER_RE.sub("", DUE_RE.sub("", text))
    return re.sub(r"[\s@\-–—:：()（）\[\]]+", "", text)


def read_text(path: Path) -> str:
    raw = path.read_bytes()
    for encoding in ("utf-8", "gb18030"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


# --------------------------------------------------------------------------- #
# archive


class Archive:
    def __init__(self, home: Path) -> None:
        self.home = home

    def notes(self) -> list[Note]:
        if not self.home.exists():
            return []
        paths = [
            path
            for path in sorted(self.home.rglob("*"))
            if path.is_file() and path.suffix.lower() in NOTE_SUFFIXES
        ]
        notes = [Note.load(path) for path in paths]
        notes.sort(key=lambda note: (note.date, note.path.name), reverse=True)
        return notes

    def imported_sources(self) -> dict[str, Path]:
        sources: dict[str, Path] = {}
        for note in self.notes():
            source = note.meta.get("source")
            if source:
                sources.setdefault(source, note.path)
        return sources

    def free_path(self, when: date, title: str) -> Path:
        """A path that does not exist yet - never a collision to overwrite."""
        directory = self.home / f"{when.year:04d}"
        stem = f"{when.isoformat()}-{slugify(title)}"
        candidate = directory / f"{stem}.md"
        counter = 2
        while candidate.exists():
            candidate = directory / f"{stem}-{counter}.md"
            counter += 1
        return candidate

    def write(self, path: Path, text: str) -> Path:
        if path.exists():
            raise FileExistsError(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # "x" so a race cannot silently clobber an existing note.
        with open(path, "x", encoding="utf-8") as handle:
            handle.write(text)
        return path


def collect_input_files(inputs: list[Path], home: Path) -> list[Path]:
    files: list[Path] = []
    for entry in inputs:
        if entry.is_dir():
            for path in sorted(entry.rglob("*")):
                if not path.is_file() or path.suffix.lower() not in NOTE_SUFFIXES:
                    continue
                if any(part.startswith(".") for part in path.parts):
                    continue
                files.append(path)
        elif entry.is_file():
            files.append(entry)
        else:
            raise FileNotFoundError(entry)
    resolved_home = home.resolve()
    unique: list[Path] = []
    seen: set[Path] = set()
    for path in files:
        real = path.resolve()
        if real in seen or resolved_home in real.parents or real == resolved_home:
            continue
        seen.add(real)
        unique.append(path)
    return unique


def body_digest(body: str) -> str:
    return hashlib.sha256(body.strip().encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- #
# display


def width(text: str) -> int:
    return sum(2 if unicodedata.east_asian_width(char) in "WF" else 1 for char in text)


def pad(text: str, target: int) -> str:
    return text + " " * max(0, target - width(text))


def clip(text: str, target: int) -> str:
    if width(text) <= target:
        return text
    out = ""
    for char in text:
        if width(out) + width(char) > target - 1:
            return out + "…"
        out += char
    return out


def parse_since(value: str | None) -> date | None:
    if not value:
        return None
    match = SINCE_RE.match(value.strip())
    if match:
        amount, unit = int(match.group(1)), match.group(2)
        days = {"d": 1, "w": 7, "m": 30}[unit] * amount
        return date.today() - timedelta(days=days)
    found = normalize_date(value)
    if not found:
        raise ValueError(f"看不懂的时间范围: {value}（用 7d / 2w / 3m 或 2026-09-01）")
    return found


def relative_path(path: Path, home: Path) -> str:
    try:
        return str(path.relative_to(home))
    except ValueError:
        return str(path)


# --------------------------------------------------------------------------- #
# commands


def cmd_new(args: argparse.Namespace, archive: Archive) -> int:
    when = normalize_date(args.date) if args.date else date.today()
    if args.date and not when:
        print(f"看不懂的日期: {args.date}", file=sys.stderr)
        return 1
    raw = "" if sys.stdin.isatty() else sys.stdin.read().strip()
    title = args.title or (guess_title(Path("stdin.md"), raw) if raw else "会议记录")
    meta = {
        "title": title,
        "date": when.isoformat(),
        "attendees": ", ".join(split_list(args.attendees or "")),
        "tags": ", ".join(split_list(args.tags or "")),
    }
    body = NOTE_TEMPLATE.format(raw=raw or "（这里贴你随手记的原文）")
    path = archive.write(archive.free_path(when, title), render_front_matter(meta) + "\n" + body)
    print(f"新建: {path}")
    return 0


def cmd_import(args: argparse.Namespace, archive: Archive) -> int:
    try:
        files = collect_input_files([Path(p).expanduser() for p in args.paths], archive.home)
    except FileNotFoundError as exc:
        print(f"找不到路径: {exc}", file=sys.stderr)
        return 1
    if not files:
        print("没有可导入的 .md/.markdown/.txt 文件")
        return 0

    known = archive.imported_sources()
    imported = skipped = 0
    for source in files:
        text = read_text(source)
        meta, body = parse_front_matter(text)
        if not body.strip():
            print(f"跳过（空文件）: {source}")
            skipped += 1
            continue
        key = str(source.resolve())
        if key in known:
            print(f"跳过（已导入）: {source} -> {relative_path(known[key], archive.home)}")
            skipped += 1
            continue
        when = guess_date(source, body, meta)
        title = guess_title(source, body, meta)
        new_meta = {
            "title": title,
            "date": when.isoformat(),
            "attendees": ", ".join(split_list(meta.get("attendees") or find_attendees(body))),
            "tags": meta.get("tags", ""),
            "source": key,
            "imported": date.today().isoformat(),
            "digest": body_digest(body),
        }
        target = archive.write(
            archive.free_path(when, title), render_front_matter(new_meta) + "\n" + body.lstrip("\n")
        )
        known[key] = target
        imported += 1
        if args.verbose:
            print(f"导入: {source} -> {relative_path(target, archive.home)}")
    print(f"\n导入 {imported} 篇，跳过 {skipped} 篇。归档目录: {archive.home}")
    print("原文件没有被移动或修改。")
    return 0


def cmd_list(args: argparse.Namespace, archive: Archive) -> int:
    try:
        since = parse_since(args.since)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    notes = [note for note in archive.notes() if not since or note.date >= since]
    if args.tag:
        notes = [note for note in notes if args.tag in note.tags]
    if not notes:
        print(f"归档里还没有记录。先跑一次 import 或 new（归档目录: {archive.home}）")
        return 0
    shown = notes[: args.limit] if args.limit else notes
    print(f"{pad('日期', 12)}{pad('待办', 6)}{pad('标题', 40)}参会")
    for note in shown:
        open_todos = sum(1 for todo in note.todos() if not todo.done)
        print(
            pad(note.date.isoformat(), 12)
            + pad(str(open_todos) if open_todos else "-", 6)
            + pad(clip(note.title, 38), 40)
            + (f"{len(note.attendees)} 人" if note.attendees else "-")
        )
    print(f"\n共 {len(notes)} 篇，显示 {len(shown)} 篇。")
    return 0


def cmd_search(args: argparse.Namespace, archive: Archive) -> int:
    needles = [word.lower() for word in args.words]
    hits = 0
    for note in archive.notes():
        haystack = (note.title + "\n" + note.body + "\n" + " ".join(note.attendees)).lower()
        if not all(needle in haystack for needle in needles):
            continue
        hits += 1
        print(f"\n{note.date.isoformat()}  {note.title}")
        print(f"  {relative_path(note.path, archive.home)}")
        matched = 0
        for line_no, line in enumerate(note.body.splitlines(), start=1):
            if any(needle in line.lower() for needle in needles) and line.strip():
                print(f"  {line_no:>4}: {clip(line.strip(), 100)}")
                matched += 1
                if matched >= args.context:
                    break
    print(f"\n命中 {hits} 篇。" if hits else "没有命中。")
    return 0


def cmd_todos(args: argparse.Namespace, archive: Archive) -> int:
    try:
        since = parse_since(args.since)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    todos: list[Todo] = []
    for note in archive.notes():
        if since and note.date < since:
            continue
        for todo in note.todos():
            if not args.all and todo.done:
                continue
            if args.owner and (todo.owner or "").lower() != args.owner.lower().lstrip("@"):
                continue
            todos.append(todo)
    if not todos:
        print("没有符合条件的待办。")
        return 0
    far = date.max
    todos.sort(key=lambda todo: (todo.done, todo.due or far, -todo.note.date.toordinal()))
    for todo in todos:
        mark = "x" if todo.done else " "
        flag = "  ⚠ 已过期" if todo.overdue else ""
        print(
            f"[{mark}] {clip(todo.text, 76)}{flag}\n"
            f"      来源: {todo.note.date.isoformat()} {clip(todo.note.title, 30)}"
            f" ({relative_path(todo.note.path, archive.home)}:{todo.line_no})"
        )
    overdue = sum(1 for todo in todos if todo.overdue)
    print(f"\n共 {len(todos)} 条" + (f"，其中 {overdue} 条已过期。" if overdue else "。"))
    return 0


def cmd_digest(args: argparse.Namespace, archive: Archive) -> int:
    try:
        since = parse_since(args.since) or date.today() - timedelta(days=7)
    except ValueError as exc:
        print(exc, file=sys.stderr)
        return 1
    notes = [note for note in archive.notes() if note.date >= since]
    lines = [f"# 会议摘要 {since.isoformat()} → {date.today().isoformat()}", ""]
    lines.append(f"## 会议（{len(notes)}）")
    lines.append("")
    for note in notes:
        who = f"（{', '.join(note.attendees)}）" if note.attendees else ""
        lines.append(f"- {note.date.isoformat()} **{note.title}**{who}")
    decisions = [(note, text) for note in notes for text in note.decisions()]
    lines += ["", f"## 决定（{len(decisions)}）", ""]
    for note, text in decisions:
        lines.append(f"- {text} — {note.date.isoformat()} {note.title}")
    open_todos = [todo for note in notes for todo in note.todos() if not todo.done]
    lines += ["", f"## 未完成待办（{len(open_todos)}）", ""]
    open_todos.sort(key=lambda todo: (todo.due or date.max, -todo.note.date.toordinal()))
    for todo in open_todos:
        flag = "  ⚠ 已过期" if todo.overdue else ""
        lines.append(
            f"- [ ] {todo.text} — {todo.note.date.isoformat()} {todo.note.title}{flag}"
        )
    text = "\n".join(lines) + "\n"
    if args.output:
        target = Path(args.output).expanduser()
        if target.exists():
            print(f"已存在，不覆盖: {target}", file=sys.stderr)
            return 1
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, "x", encoding="utf-8") as handle:
            handle.write(text)
        print(f"已写入: {target}")
    else:
        print(text, end="")
    return 0


# --------------------------------------------------------------------------- #
# cli


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="meetnote",
        description="把散落的会议记录收进一个 markdown 归档，并捞出待办和决定。",
    )
    parser.add_argument("--home", help=f"归档目录（默认 $MEETNOTE_HOME 或 {DEFAULT_HOME}）")
    subparsers = parser.add_subparsers(dest="command", required=True)

    new = subparsers.add_parser("new", help="新建一篇会议记录（可从 stdin 收原文）")
    new.add_argument("title", nargs="?", help="标题；省略则用 stdin 首行或“会议记录”")
    new.add_argument("--date", help="会议日期，默认今天")
    new.add_argument("--attendees", help="参会人，逗号分隔")
    new.add_argument("--tags", help="标签，逗号分隔")
    new.set_defaults(func=cmd_new)

    imp = subparsers.add_parser("import", help="把文件或目录里的记录复制进归档")
    imp.add_argument("paths", nargs="+", help="文件或目录")
    imp.add_argument("-v", "--verbose", action="store_true", help="逐条打印导入结果")
    imp.set_defaults(func=cmd_import)

    listing = subparsers.add_parser("list", help="按时间列出归档里的记录")
    listing.add_argument("--since", help="时间范围：7d / 2w / 3m / 2026-09-01")
    listing.add_argument("--tag", help="只看某个标签")
    listing.add_argument("--limit", type=int, default=20, help="最多显示几篇（0 = 全部）")
    listing.set_defaults(func=cmd_list)

    search = subparsers.add_parser("search", help="全文搜索（多个词是 AND）")
    search.add_argument("words", nargs="+")
    search.add_argument("--context", type=int, default=3, help="每篇最多显示几行命中")
    search.set_defaults(func=cmd_search)

    todos = subparsers.add_parser("todos", help="汇总所有会议里的待办")
    todos.add_argument("--all", action="store_true", help="连已完成的一起显示")
    todos.add_argument("--owner", help="只看某个人（@名字）")
    todos.add_argument("--since", help="时间范围：7d / 2w / 2026-09-01")
    todos.set_defaults(func=cmd_todos)

    digest = subparsers.add_parser("digest", help="生成一段时间的会议摘要")
    digest.add_argument("--since", help="时间范围，默认 7d")
    digest.add_argument("-o", "--output", help="写入文件（已存在则报错，不覆盖）")
    digest.set_defaults(func=cmd_digest)
    return parser


def resolve_home(cli_home: str | None) -> Path:
    return Path(cli_home or os.environ.get("MEETNOTE_HOME") or DEFAULT_HOME).expanduser()


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    archive = Archive(resolve_home(args.home))
    try:
        return args.func(args, archive)
    except FileExistsError as exc:
        print(f"目标已存在，没有覆盖: {exc}", file=sys.stderr)
        return 1
    except BrokenPipeError:  # `meetnote search ... | head`
        return 0


if __name__ == "__main__":
    sys.exit(main())
