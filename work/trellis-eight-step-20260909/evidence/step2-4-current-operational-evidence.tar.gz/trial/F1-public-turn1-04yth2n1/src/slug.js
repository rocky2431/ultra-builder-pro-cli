'use strict';

const { createHash } = require('node:crypto');

// Build a filesystem- and URL-safe slug for a note title.
// Letters and digits of any script are kept, so a title written entirely in
// non-ASCII characters keeps its own characters instead of collapsing to an
// empty string. Everything else is still a separator, so an ASCII-only title
// produces exactly the slug it always did.
function slugify(title) {
  // Normalize first: macOS hands the same title back in NFD, and an
  // unnormalized title would otherwise slug differently from its NFC twin.
  const text = String(title).normalize('NFC');
  const slug = text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '');
  // Frozen: an ASCII-only title returns byte-for-byte what it always did,
  // including the empty slug, because notes already on disk are addressed by
  // it. The Unicode-aware pass above keeps exactly the characters the old
  // ASCII pass kept, so this is the old result, not an approximation of it.
  if (!/[^\x00-\x7F]/.test(text)) return slug;
  // A non-ASCII title with no letters or digits at all (emoji, symbols) still
  // has nothing to slug, and the sibling consumer would store every such note
  // under one filename. Fall back to a deterministic digest of the title.
  return slug === '' ? createHash('sha256').update(text).digest('hex').slice(0, 12) : slug;
}

module.exports = { slugify };
