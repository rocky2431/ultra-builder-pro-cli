# 工程事实记录

本文件记录项目级工程事实：从代码、数据或运行中确认、需要在后续任务中继续使用的事实。每条注明日期与出处（观察到它的文件或运行）。任务专有的临时结论不记在这里。

## 2026-08-20 库存为追加式 JSONL，id 由 store 分配

出处：`docs/decisions/2026-08-20-append-only-jsonl.md`、`src/store.js`。
库存每行一条 JSON；`appendEntry` 按现有行数分配 `entry-0001` 递增 id，写入方传 book/author/time/text，不传 id。

## 2026-09-09 「墨记」现行导出为 v2 分块文本，含撤销墓碑

出处：`data/sample-export.txt`、`src/import.js`、`test/import.test.js`。
首行 `墨记导出 v2`，次行 `==========`；此后每条记录三段——`《书名》 作者` / `YYYY-MM-DD HH:MM:SS` / 正文，记录间以 `----------` 分隔。
正文以 `>> ` 开头，续行缩进三格，缩进不是内容（导入时去掉），换行是内容（导入时保留）。
正文形如 `[撤销] …` 的记录是设备端删除墓碑，不是笔记，导入时跳过并单独记账。
`docs/notes/2026-05-09-export-format-v1.md` 的竖线格式已停用，与现行导出无关。
