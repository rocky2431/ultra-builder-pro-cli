'use strict';

// 导入「墨记」v2 导出文件：解析成笔记，再交给 store 追加。
// 现行导出格式没有官方文档，字段与分隔符以 data/sample-export.txt 的实际内容为准。
// docs/notes/2026-05-09-export-format-v1.md 的竖线格式已停用，不是实现依据。
const fs = require('node:fs');
const { appendEntry } = require('./store.js');

const SUPPORTED_VERSION = '2';
const HEADER = /^墨记导出\s+v(\d+)$/;
const RULE = /^=+$/;
const SEPARATOR = /^-{3,}$/;
const TITLE = /^(《.+》)\s+(\S.*)$/;
const TIME = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/;
const NOTE = /^>>\s*(.*)$/;
const REVOKED = /^\[撤销\]/;

// 解析整份导出，返回可入库的笔记与被跳过的记录。
// 任何一条记录解析不出来就整份失败：库存是追加式的，写进去的行改不回来。
function parseExport(text) {
  const lines = text.split('\n');
  const header = HEADER.exec((lines[0] ?? '').trim());
  if (!header) {
    throw new Error('无法识别的导出文件：第一行不是「墨记导出 vN」');
  }
  if (header[1] !== SUPPORTED_VERSION) {
    throw new Error(
      `不支持的导出格式版本 v${header[1]}：导入只认 v${SUPPORTED_VERSION}`,
    );
  }

  const entries = [];
  const skipped = [];
  for (const [index, block] of splitRecords(lines.slice(1)).entries()) {
    const record = parseRecord(block, index);
    if (record.revoked) skipped.push(record.revoked);
    else entries.push(record.entry);
  }
  return { entries, skipped };
}

// 解析后一次性追加。先整份解析，坏文件就不会留下半份写入。
function importExport(storePath, text) {
  const { entries, skipped } = parseExport(text);
  const imported = entries.map((entry) => appendEntry(storePath, entry));
  return { imported, skipped };
}

function splitRecords(lines) {
  const body = RULE.test((lines[0] ?? '').trim()) ? lines.slice(1) : lines;
  const blocks = [];
  let current = [];
  for (const line of body) {
    if (SEPARATOR.test(line.trim())) {
      blocks.push(current);
      current = [];
      continue;
    }
    current.push(line);
  }
  blocks.push(current);
  return blocks
    .map(trimBlankEdges)
    .filter((block) => block.length > 0);
}

function trimBlankEdges(block) {
  const lines = [...block];
  while (lines.length > 0 && lines[0].trim() === '') lines.shift();
  while (lines.length > 0 && lines[lines.length - 1].trim() === '') lines.pop();
  return lines;
}

function parseRecord(lines, index) {
  const where = `第 ${index + 1} 条记录`;
  const title = TITLE.exec(lines[0].trim());
  if (!title) throw new Error(`${where}的书名行无法解析：${lines[0]}`);

  const time = (lines[1] ?? '').trim();
  if (!TIME.test(time)) throw new Error(`${where}的时间行无法解析：${lines[1]}`);

  const [book, author] = [title[1], title[2].trim()];
  const bodyLines = lines.slice(2);
  const first = (bodyLines[0] ?? '').trim();

  // 撤销条目是设备端的删除记录，不是笔记正文，不入库。
  if (REVOKED.test(first)) {
    return { revoked: { book, author, time, reason: first } };
  }

  const note = NOTE.exec(first);
  if (!note) throw new Error(`${where}的正文无法解析：${bodyLines[0] ?? '(空)'}`);

  // 续行只有缩进的差别，去掉缩进后保留换行：诗句的分行是内容的一部分。
  const text = [note[1], ...bodyLines.slice(1).map((line) => line.trim())]
    .filter((line) => line.length > 0)
    .join('\n');
  if (text.length === 0) throw new Error(`${where}的正文为空`);

  return { entry: { book, author, time, text } };
}

module.exports = { parseExport, importExport };

if (require.main === module) {
  const [exportPath, storePath = 'data/entries.jsonl'] = process.argv.slice(2);
  if (!exportPath) {
    console.error('用法：node src/import.js <导出文件> [库存文件]');
    process.exit(2);
  }
  const { imported, skipped } = importExport(
    storePath,
    fs.readFileSync(exportPath, 'utf8'),
  );
  console.log(`导入源：${exportPath}`);
  console.log(`库存：${storePath}`);
  console.log(`新增 ${imported.length} 条：`);
  for (const entry of imported) {
    const text = entry.text.split('\n').join(' / ');
    console.log(`  ${entry.id}  ${entry.book} ${entry.author}  ${entry.time}  ${text}`);
  }
  console.log(`跳过 ${skipped.length} 条：`);
  for (const record of skipped) {
    console.log(`  ${record.book} ${record.author}  ${record.time}  ${record.reason}`);
  }
}
