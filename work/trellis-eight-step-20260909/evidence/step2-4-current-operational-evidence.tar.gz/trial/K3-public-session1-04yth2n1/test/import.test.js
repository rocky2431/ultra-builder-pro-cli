'use strict';

// 导入的基线行为：解析「墨记」v2 导出、跳过撤销墓碑、按 store 规则写入库存。

const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const { parseExport, importExport } = require('../src/import.js');
const { listEntries } = require('../src/store.js');

const SAMPLE = fs.readFileSync(
  path.join(__dirname, '..', 'data', 'sample-export.txt'),
  'utf8',
);

function freshStore() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mozhai-import-'));
  return path.join(dir, 'entries.jsonl');
}

test('parse reads book, author, time and text from a v2 export', () => {
  const { entries } = parseExport(SAMPLE);
  assert.deepEqual(entries[0], {
    book: '《夜晚的潜水艇》',
    author: '陈春成',
    time: '2026-08-01 23:42:05',
    text: '手边的书就是看不到尽头的河。',
  });
});

test('parse skips revoked records instead of importing them as notes', () => {
  const { entries, skipped } = parseExport(SAMPLE);
  assert.equal(entries.length, 2);
  assert.equal(skipped.length, 1);
  assert.equal(skipped[0].time, '2026-08-03 08:15:44');
  assert.ok(
    !entries.some((entry) => entry.text.includes('撤销')),
    'a revoked tombstone must never become note text',
  );
});

test('parse keeps the line breaks inside a multi-line note', () => {
  const { entries } = parseExport(SAMPLE);
  assert.equal(entries[1].text, '江水把岸边的灯影揉碎，\n又一片片拼回去。');
});

test('parse refuses an export whose format version is not v2', () => {
  assert.throws(
    () => parseExport('墨记导出 v9\n==========\n《书》 作者\n2026-08-01 23:42:05\n>> 正文\n----------\n'),
    /v9/,
  );
});

test('parse refuses the superseded v1 pipe format instead of misreading it', () => {
  assert.throws(
    () => parseExport('夜晚的潜水艇|陈春成|2026-05-01 21:03:11|手边的书就是看不到尽头的河。\n'),
    /墨记导出/,
  );
});

test('import appends parsed notes with store-assigned ids', () => {
  const store = freshStore();
  const { imported, skipped } = importExport(store, SAMPLE);
  assert.deepEqual(
    imported.map((entry) => entry.id),
    ['entry-0001', 'entry-0002'],
  );
  assert.equal(skipped.length, 1);
  assert.deepEqual(listEntries(store), imported);
});

test('import continues the existing id sequence and rewrites no existing line', () => {
  const store = freshStore();
  fs.writeFileSync(
    store,
    `${JSON.stringify({
      id: 'entry-0001',
      book: '《俗世奇人》',
      author: '冯骥才',
      time: '2026-07-25 09:02:41',
      text: '刷子李的规矩比手艺还硬。',
    })}\n`,
  );
  const before = fs.readFileSync(store, 'utf8');
  const { imported } = importExport(store, SAMPLE);
  const after = fs.readFileSync(store, 'utf8');
  assert.ok(after.startsWith(before), 'import must not touch existing store lines');
  assert.deepEqual(
    imported.map((entry) => entry.id),
    ['entry-0002', 'entry-0003'],
  );
});

test('a malformed export writes nothing at all to the store', () => {
  const store = freshStore();
  const broken = '墨记导出 v2\n==========\n《夜晚的潜水艇》 陈春成\n2026-08-01 23:42:05\n>> 好的一条\n----------\n这行不是书名\n2026-08-02 10:00:00\n>> 坏的一条\n----------\n';
  assert.throws(() => importExport(store, broken));
  assert.equal(fs.existsSync(store), false, 'parsing must fail before any append');
});
