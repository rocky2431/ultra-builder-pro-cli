import json,os,sys,time,subprocess,datetime
from pathlib import Path
f=Path(sys.argv[1]);r=json.loads(f.read_text());p=f.parent;label=r['label'];env=dict(os.environ,**r['environment_overrides']);a=r['argv']
dry=subprocess.run(a[:3]+['--dry-run','--json']+a[3:],cwd=r['cwd'],env=env,capture_output=True,text=True);assert dry.returncode==0,dry.stderr
r['native_launch']=json.loads(dry.stdout)
with (p/(label+'.stdout.jsonl')).open('w') as out,(p/(label+'.stderr.log')).open('w') as err:
 start=time.monotonic();r['started_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 proc=subprocess.Popen(a,cwd=r['cwd'],env=env,stdout=out,stderr=err,start_new_session=True);r['pid']=proc.pid;r['status']='running';f.write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps({'label':label,'pid':proc.pid}),flush=True);code=proc.wait()
result=dict(exit_code=code,duration_seconds=time.monotonic()-start,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());(p/(label+'-process-result.json')).write_text(json.dumps(result,indent=2));print(json.dumps(result))
