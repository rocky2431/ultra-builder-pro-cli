import os,json,pathlib,uuid,subprocess
p=pathlib.Path(__file__).parent
r=json.loads((p/'F2-public-turn1-request.json').read_text())
d=p/'F2-res-public-candidate5-04yth2n1';d.mkdir()
r['owner_message']='我手机里和邮箱里的收据、账单一堆，帮我弄个能管起来的小东西吧。'
a=r['argv'];a[1]='/var/folders/cm/zpwxmr512rq1qz4_0_ryz8t80000gn/T/ubp-final-entry5-08rm2b0_/source/bin/install.js';i=a.index('--host-arg=--output-format');a=a[:i]+['--',r['owner_message']]
sid=str(uuid.uuid4());a[a.index('--host-arg=--session-id')+1]='--host-arg='+sid
env=dict(os.environ,**r['environment_overrides'])
dry=subprocess.run(a[:3]+['--dry-run','--json']+a[3:],cwd=d,env=env,capture_output=True,text=True);assert dry.returncode==0,dry.stderr
r.update(argv=a,cwd=str(d),session_id=sid,native_launch=json.loads(dry.stdout),mode='interactive PTY, no print; same source and operator boundary',status='starting')
(p/'F2-res-public-candidate5-request.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));os.chdir(d);os.execvpe(a[0],a,env)
