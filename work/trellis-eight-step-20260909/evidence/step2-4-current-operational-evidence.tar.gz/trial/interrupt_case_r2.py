import os,json,time,subprocess,datetime,signal,hashlib
from pathlib import Path
p=Path(__file__).parent;f=p/'D4-interrupt-r2-request.json';r=json.loads(f.read_text());a=r['argv'];env=dict(os.environ,**r['environment_overrides']);d=Path(r['cwd']);label=r['label'];log=p/(label+'.stdout.jsonl')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def processes():
 result=[]
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,state='],text=True).splitlines():
  parts=line.split()
  if len(parts)==4:result.append(dict(pid=int(parts[0]),ppid=int(parts[1]),pgid=int(parts[2]),state=parts[3]))
 return result

def hashes():return {str(v.relative_to(d)):hashlib.sha256(v.read_bytes()).hexdigest() for v in d.rglob('*') if v.is_file() and '.git' not in v.parts}
dry=subprocess.run(a[:3]+['--dry-run','--json']+a[3:],cwd=d,env=env,capture_output=True,text=True);assert dry.returncode==0,dry.stderr;r['native_launch']=json.loads(dry.stdout)
with log.open('w') as out,(p/(label+'.stderr.log')).open('w') as err:
 start=time.monotonic();r['started_at']=now();proc=subprocess.Popen(a,cwd=d,env=env,stdout=out,stderr=err,start_new_session=True);r.update(pid=proc.pid,status='running');f.write_text(json.dumps(r,ensure_ascii=False,indent=2));print('started '+str(proc.pid),flush=True)
 first=None;observed=None
 while proc.poll() is None and first is None:
  for line in log.read_text().splitlines():
   try:event=json.loads(line)
   except ValueError:continue
   if event.get('type')=='user' and any(b.get('type')=='tool_result' and not b.get('is_error',False) for b in event.get('message',{}).get('content',[]) if isinstance(b,dict)):
    first=time.monotonic();observed=event;break
  if first is None:time.sleep(.2)
 observation={'owner_stop':'停一下，我现在有别的事。','p1_event':observed,'observed_at':now(),'terminal':'No PTY in this run; pipe process return is observable, not an interactive prompt.'}
 if first is not None:
  time.sleep(10)
  observation['dwell_seconds']=time.monotonic()-first
 if first is not None and proc.poll() is None:
  before=processes();group=[x for x in before if x['pgid']==proc.pid];observation.update(status='interrupted',before_process_group=group,signal_at=now(),signal='SIGINT once to public command process group');os.killpg(proc.pid,signal.SIGINT)
  try:code=proc.wait(timeout=30)
  except subprocess.TimeoutExpired:code=None;observation['status']='stop-not-terminal-after30s'
  after=processes();observation.update(exit_code=code,finished_at=now(),residual_process_group=[x for x in after if x['pgid']==proc.pid],stopped_project_manifest=hashes())
 else:observation.update(status='interruption_unobserved',exit_code=proc.wait(),reason='Turn finished before P1 plus dwell')
 observation['duration_seconds']=time.monotonic()-start
 lines=log.read_text().splitlines();observation['last_transcript_record']=json.loads(lines[-1]) if lines else None
 (p/(label+'-observation.json')).write_text(json.dumps(observation,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in observation.items() if k in ['status','exit_code','residual_process_group','duration_seconds']}),flush=True)
