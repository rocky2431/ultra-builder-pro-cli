# Reframing: recovering the role from the form

An owner fluent in their own domain still describes a **form** when what they
want is a **role**. They are not being vague; they are naming the nearest thing
they can picture. Taken at face value, that name can produce a specification
that is internally consistent and builds the wrong product — but most asks do
not need a reframe to avoid that, and an unrequested one costs trust. The
evidence in front of you decides.

## When to reframe

Reframe only when the evidence shows the named form and the intended outcome can
come apart. Any one of these is enough:

- two readings of the request would lead to materially different builds;
- the request names a solution whose problem has not been stated, and the build
  would change with the problem;
- the request is impossible as worded, or would be satisfied by something far
  smaller than it asks for;
- the request describes what a competitor or another team has, rather than what
  the owner needs.

## When not to reframe

Most asks do not need one. Do not reframe when:

- the request names a concrete, bounded deliverable whose success is checkable
  as worded — a simple deliverable stays simple, and is never broadened into a
  grander product by default;
- the owner has already rejected a reframing of this request — their original
  frame is now a recorded constraint, not an opening bid;
- the open point is a detail inside a workable frame; that is a detail
  question, not a frame challenge;
- the only thing your reinterpretation would change is how easy the work is to
  build. A reframe is a hypothesis about their intent, never about your
  convenience.

When you are unsure whether a trigger is met, ask the detail question first; a
frame challenge built on a misread costs more trust than one deferred question.

## How to put it

State what you believe they want, name the gap against the words they used, and
end on a question:

> You asked for a daily 9 a.m. email digest of deploy health. Everything you
> described reacting to arrived in channels you already watch hourly. What you
> described looks like an alert when health changes, not a scheduled digest.
> Have I got that right?

Rules that keep this honest:

- **One reframe at a time.** Two competing reinterpretations in one turn is a
  quiz, and the owner will pick the one that sounds more flattering.
- **Offer it, never assert it.** A reframe is a hypothesis about their intent,
  and they are the only authority on it.
- **Name the size and direction of the change.** If your reading enlarges the
  work, say so; if it shrinks the work, say that too. The owner weighs either
  trade-off — but only when it is said out loud.
- **A correction is the better outcome.** "No, it really is just the digest" is
  a constraint you did not have a minute ago. Record it as a decision.
- **Never reframe toward what is easier to build.** If your reinterpretation
  happens to shrink the work, say that out loud and let the owner weigh it.
- **Stop when the owner rejects the proposed role and confirms their original frame.**
  Do not keep producing cosmetic reinterpretations. If a materially different reading
  later becomes evidenced, present that new distinction rather than counting prior
  attempts.

## Framing questions

These refuse the owner's framing on purpose, which is how they surface what the
request left out. Ask them only while the frame itself is genuinely open, select
only the prompts that can distinguish a materially different build, and stop
when the owner confirms the frame or the remaining prompts cannot change it.

| Question | What it recovers |
|---|---|
| What do you do today, without this? | The real job, with the proposed form stripped off |
| What would make you say this was a waste of effort? | Success via its negative — people picture failure far more concretely than they picture success |
| What must never happen, even if it would work better? | The hard constraints they were never going to volunteer |
| If it could only do one thing and you would still use it, which? | Core against periphery, before scope has a chance to spread |
| Whose situation gets worse when this exists? | Stakeholders, and the constraints attached to them |

Two of these are worth their place for a specific reason. Asking for success
directly gets an aspiration; asking what would make it a waste gets a threshold.
Asking who is made worse off surfaces the constraints an owner never thinks to
state, because to them they are simply how the world is.

## What counts as an answer

An answer counts once it is specific enough to **rule something out**.

| Not yet an answer | An answer |
|---|---|
| "It should be fast" | "The list renders before they finish typing" |
| "It should be secure" | "A support agent must never see a full card number" |
| "Keep costs reasonable" | "Under fifty dollars a month in API spend" |

When an answer rules nothing out, do not re-ask the same question louder. Ask
what would have to be true for the owner to **reject** a candidate solution — the
rejection criterion is the constraint, stated from the other side.
