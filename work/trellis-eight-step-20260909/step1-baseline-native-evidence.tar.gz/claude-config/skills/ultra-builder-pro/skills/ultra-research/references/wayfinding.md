# Research wayfinding

Use this method when Research spans several lenses or the path itself is unclear. Skip
it for one bounded evidence question whose destination is already known.

## Objective

Turn fog into a small question map without turning the map into workflow authority.
Select the smallest sufficient coverage that can establish the current baseline or
unlock the active Change.

## Inspect first

Read the Project Brief, accepted authority, unresolved specification sections, current
repository evidence, active Change, and owner statements already present. Do not ask a
question whose answer is reachable in those sources.

## Write the run brief

Write `.ultra/research/<run-id>/brief.md` with:

- entry question and planning boundary;
- known facts already on record, with their sources, so answered content is reused
  rather than re-asked;
- unknowns, each with the decision it can change, split into blocking decisions and
  safely deferrable unknowns;
- selected lenses, semantic dependencies, and explicit omissions;
- likely evidence sources and current freshness limits;
- owner decisions that block the exit, and the checkpoint that owns each one —
  keeping an owner-stated fact, which is reusable input, distinct from acceptance
  of a candidate this run composes, which stays open until the owner accepts the
  displayed candidate;
- a stop condition stated as an observable artifact or resolved decision;
- the useful exit — the caller action unlocked the moment the stop condition is met.

## North Star Working Candidate

In the same brief, keep the current candidate outcome, `FP-*` propositions, causal chain,
evidence, counter-evidence, and the accepted `.ultra/north-star.md` revision and digest it
began from. Update
this section as lenses refine or contradict it. It is derived navigation and not semantic
authority; only accepted synthesis can replace the canonical North Star.

The brief is derived navigation, not semantic authority. Specifications, the North Star,
`CONTEXT.md`, and accepted decisions remain canonical. Rebuild or discard the map when
evidence changes; never add a completion flag merely to route another Skill.

## Keep the frontier small

Prefer one load-bearing question over a speculative tree. Add a branch only when a
viable answer would change selected evidence, product direction, scope, or architecture.
Questions that cannot change the current boundary belong in explicit deferred work, not
the active map.

Wayfinding chooses where to investigate. Each evidence lens defines what to establish;
Grilling defines how to ask the owner; Think resolves one consequential decision.
