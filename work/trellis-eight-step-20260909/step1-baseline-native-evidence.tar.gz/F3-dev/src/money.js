'use strict';

// Every monetary amount in this project is an integer number of minor units
// (cents). See docs/decisions/2026-08-24-integer-minor-units.md.
function assertMinorUnits(amount) {
  if (!Number.isInteger(amount)) {
    throw new TypeError(
      `amount must be an integer number of minor units, received: ${amount}`,
    );
  }
  return amount;
}

function addAmounts(amounts) {
  return amounts.reduce((total, amount) => total + assertMinorUnits(amount), 0);
}

// Split one expense evenly between `count` people. The remainder is never
// dropped: the first `amount % count` shares carry one extra minor unit, so
// the shares always add back up to `amount` exactly.
function splitEvenly(amount, count) {
  assertMinorUnits(amount);
  if (!Number.isInteger(count) || count < 1) {
    throw new RangeError(
      `count must be a positive integer number of people, received: ${count}`,
    );
  }
  const base = Math.floor(amount / count);
  const remainder = amount - base * count;
  return Array.from({ length: count }, (_, i) =>
    i < remainder ? base + 1 : base,
  );
}

// Display boundary: the only place where an amount becomes a decimal string.
function formatAmount(amount) {
  assertMinorUnits(amount);
  const sign = amount < 0 ? '-' : '';
  const abs = Math.abs(amount);
  return `${sign}${Math.trunc(abs / 100)}.${String(abs % 100).padStart(2, '0')}`;
}

// Display boundary: one pasteable line for a chat group, e.g.
// "总计 10.00，3 人平摊：3.34 / 3.33 / 3.33". Every share is listed, so the
// line adds back up to the total exactly like `splitEvenly` does.
function summarizeSplit(amount, count) {
  const shares = splitEvenly(amount, count);
  const listed = shares.map(formatAmount).join(' / ');
  return `总计 ${formatAmount(amount)}，${count} 人平摊：${listed}`;
}

module.exports = {
  addAmounts,
  splitEvenly,
  formatAmount,
  summarizeSplit,
  assertMinorUnits,
};
