'use strict';

const { test } = require('node:test');
const assert = require('node:assert/strict');

const {
  addAmounts,
  splitEvenly,
  formatAmount,
  summarizeSplit,
} = require('../src/money');

test('an evenly divisible expense splits into equal shares', () => {
  assert.deepEqual(splitEvenly(1200, 3), [400, 400, 400]);
  assert.deepEqual(splitEvenly(0, 4), [0, 0, 0, 0]);
  assert.deepEqual(splitEvenly(1234, 1), [1234]);
});

test('the remainder is distributed instead of dropped', () => {
  assert.deepEqual(splitEvenly(1000, 3), [334, 333, 333]);
  assert.deepEqual(splitEvenly(1, 3), [1, 0, 0]);
  assert.deepEqual(splitEvenly(-1000, 3), [-333, -333, -334]);
});

test('shares always add back up to the original amount', () => {
  for (const amount of [0, 1, 5, 999, 1000, 1234, 100003, -7, -1234]) {
    for (let count = 1; count <= 7; count += 1) {
      assert.equal(
        addAmounts(splitEvenly(amount, count)),
        amount,
        `${amount} split ${count} ways must be conserved`,
      );
    }
  }
});

test('a share differs from any other by at most one minor unit', () => {
  const shares = splitEvenly(1000, 3);
  assert.equal(Math.max(...shares) - Math.min(...shares), 1);
});

test('invalid input is rejected instead of silently rounded', () => {
  assert.throws(() => splitEvenly(12.34, 2), TypeError);
  assert.throws(() => splitEvenly('1234', 2), TypeError);
  assert.throws(() => splitEvenly(1000, 0), RangeError);
  assert.throws(() => splitEvenly(1000, -1), RangeError);
  assert.throws(() => splitEvenly(1000, 2.5), RangeError);
});

test('shares become decimal strings only at the display boundary', () => {
  assert.deepEqual(splitEvenly(1000, 3).map(formatAmount), [
    '3.34',
    '3.33',
    '3.33',
  ]);
});

test('a split exports as a single pasteable summary line', () => {
  assert.equal(summarizeSplit(1200, 3), '总计 12.00，3 人平摊：4.00 / 4.00 / 4.00');
  assert.equal(summarizeSplit(1000, 3), '总计 10.00，3 人平摊：3.34 / 3.33 / 3.33');
  assert.equal(summarizeSplit(1234, 1), '总计 12.34，1 人平摊：12.34');
  assert.equal(summarizeSplit(-1000, 3), '总计 -10.00，3 人平摊：-3.33 / -3.33 / -3.34');
});

test('the summary line stays one line and lists every share', () => {
  const line = summarizeSplit(100003, 7);
  assert.ok(!line.includes('\n'), 'the summary must be a single line');
  const shares = line.split('：')[1].split(' / ');
  assert.equal(shares.length, 7);
  assert.equal(addAmounts(splitEvenly(100003, 7)), 100003);
});

test('the summary rejects the same invalid input the split rejects', () => {
  assert.throws(() => summarizeSplit(12.34, 2), TypeError);
  assert.throws(() => summarizeSplit(1000, 0), RangeError);
});
