#!/usr/bin/env python3
"""mn - a small meeting-notes organizer.

Storage layout under $MN_HOME (default ~/meeting-notes):

    inbox/2026-09-09.md          scratch dump for the day
    inbox/_archived/             inbox files already tidied
    notes/2026/2026-09-09-*.md   structured notes
    INDEX.md                     generated index

Notes are plain Markdown with a small front-matter block, so they stay
readable and greppable without this tool.
"""

import argparse
import json
import os
import re
import sys
from datetime import date, datetime
from pathlib import Path

HOME = Path(os.environ.get("MN_HOME", Path.home() / "meeting-notes")).expanduser()
NOTES = HOME / "notes"
INBOX = HOME / "inbox"
ARCHIVE = INBOX / "_archived"
CACHE = HOME / ".todo-cache.json"

TODAY = date.today()

# --------------------------------------------------------------------------
# patterns
# --------------------------------------------------------------------------

FRONT_MATTER = re.compile(r"\A---\n(.*?)\n---\n?", re.S)
HEADING = re.compile(r"^\s{0,3}(#{1,6})\s+(.*\S)\s*$")
CHECKBOX = re.compile(r"^\s*[-*+]?\s*\[([ xX])\]\s*(.+?)\s*$")
BULLET = re.compile(r"^\s*[-*+]\s+(.+?)\s*$")
TIME_HEADING = re.compile(r"^\d{1,2}[:：]\d{2}\s*$")
MENTION = re.compile(r"@([A-Za-z0-9_.一-鿿]{1,16})")

ATTENDEES = re.compile(
    r"(?:参会人?|与会人?|出席|参与人|人员|attendees?|participants?)\s*[:：]\s*(.+)$",
    re.I,
)
SPLIT_NAMES = re.compile(r"[,，、;；/\s]+")

# Leading label words that add nothing once the line is filed under a heading.
LEAD_LABEL = re.compile(
    r"^\s*(?:待办|todo|action\s*item|决定|决议|结论|跟进)(?:\s*[:：]\s*|\s+)", re.I
)


def strip_label(text):
    stripped = LEAD_LABEL.sub("", text, count=1).strip()
    return stripped or text.strip()


# A date at the front of a title is redundant: the filename already carries it.
LEADING_DATE = re.compile(
    r"^\s*(?:20\d{2}\s*[-/年.]\s*)?\d{1,2}\s*[-/月.]\s*\d{1,2}\s*日?\s*"
)


def clean_title(text):
    cleaned = LEADING_DATE.sub("", text).strip(" -—–:：\t")
    return cleaned or text.strip()

DATE_FULL = re.compile(r"(20\d{2})\s*[-/年.]\s*(\d{1,2})\s*[-/月.]\s*(\d{1,2})")
DATE_SHORT = re.compile(r"(?<![\d:：])(\d{1,2})\s*[-/月]\s*(\d{1,2})\s*日?(?![\d:：])")

TODO_HINT = re.compile(
    r"(待办|todo|action\s*item|ai\b|跟进|要做|负责|认领|下周前|之前完成|排期)", re.I
)
DECISION_HINT = re.compile(r"(决定|决议|结论|拍板|一致同意|确认采用|敲定)")

BUCKET_BY_HEADING = [
    (re.compile(r"(待办|行动|action|todo|next\s*step|follow[\s-]?up)", re.I), "todo"),
    (re.compile(r"(决议|决定|结论|decision|outcome)", re.I), "decision"),
]

DUE_EXPLICIT = re.compile(r"due\s*[:：]?\s*(\d{4}-\d{2}-\d{2}|\d{1,2}[-/]\d{1,2})", re.I)
DUE_CN = re.compile(r"(?:截止|deadline|最晚)\s*[:：]?\s*(\d{1,2}\s*[-/月]\s*\d{1,2}\s*日?)")

TEMPLATE_BODY = """
## 背景 / 议题

-

## 讨论

-

## 决议

-

## 待办

- [ ] @谁 做什么 (due: {due})
"""


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------


def die(msg):
    print(f"mn: {msg}", file=sys.stderr)
    raise SystemExit(1)


def ensure_dirs():
    NOTES.mkdir(parents=True, exist_ok=True)
    INBOX.mkdir(parents=True, exist_ok=True)


def slugify(text):
    text = re.sub(r"[\s/\\:*?\"<>|]+", "-", text.strip())
    text = re.sub(r"-{2,}", "-", text).strip("-.")
    return text[:60] or "会议"


def parse_date(text, default=None):
    """Return a date parsed from `text`, or `default`."""
    if not text:
        return default
    text = text.strip()
    if text in ("今天", "today"):
        return TODAY
    m = DATE_FULL.search(text)
    if m:
        y, mo, d = (int(x) for x in m.groups())
    else:
        m = DATE_SHORT.search(text)
        if not m:
            return default
        y = TODAY.year
        mo, d = (int(x) for x in m.groups())
    try:
        return date(y, mo, d)
    except ValueError:
        return default


def read_note(path):
    """Split a note file into (meta dict, body text, all lines)."""
    text = path.read_text(encoding="utf-8")
    meta, body = {}, text
    m = FRONT_MATTER.match(text)
    if m:
        body = text[m.end():]
        for line in m.group(1).splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            key, value = key.strip(), value.strip()
            if value.startswith("[") and value.endswith("]"):
                value = [v.strip() for v in value[1:-1].split(",") if v.strip()]
            meta[key] = value
    return meta, body, text.splitlines()


def render_front_matter(meta):
    lines = ["---"]
    for key, value in meta.items():
        if isinstance(value, (list, tuple)):
            value = "[" + ", ".join(value) + "]"
        lines.append(f"{key}: {value}")
    lines.append("---")
    return "\n".join(lines)


def note_path(day, title):
    return NOTES / str(day.year) / f"{day.isoformat()}-{slugify(title)}.md"


def all_notes():
    if not NOTES.exists():
        return []
    return sorted(NOTES.rglob("*.md"))


def rel(path):
    try:
        return str(path.relative_to(HOME))
    except ValueError:
        return str(path)


def todo_owner_due(text):
    owner = None
    m = MENTION.search(text)
    if m:
        owner = m.group(1)
    due = None
    m = DUE_EXPLICIT.search(text) or DUE_CN.search(text)
    if m:
        due = re.sub(r"\s+", "", m.group(1))
    return owner, due


# --------------------------------------------------------------------------
# extraction — turns messy text into buckets
# --------------------------------------------------------------------------


def extract(text, fallback_day):
    """Classify raw meeting scribbles into title/attendees/decisions/todos/notes."""
    title = None
    attendees = []
    decisions = []
    todos = []
    notes = []
    day = None
    bucket = "note"

    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip():
            continue

        heading = HEADING.match(line)
        if heading:
            name = heading.group(2).strip()
            if TIME_HEADING.match(name):
                bucket = "note"
                continue
            bucket = "note"
            for pattern, target in BUCKET_BY_HEADING:
                if pattern.search(name):
                    bucket = target
                    break
            if bucket == "note" and title is None:
                title = name
                day = day or parse_date(name)
            continue

        m = ATTENDEES.search(line)
        if m:
            attendees += [n for n in SPLIT_NAMES.split(m.group(1)) if n]
            # Anything before the "参会:" label on the same line is a title candidate.
            head = line[: m.start()].strip(" -*#\t，,。")
            if head and title is None:
                title = head[:40]
                day = day or parse_date(head)
            continue

        check = CHECKBOX.match(line)
        if check:
            done = check.group(1).lower() == "x"
            todos.append((done, check.group(2)))
            continue

        bullet = BULLET.match(line)
        content = bullet.group(1) if bullet else line.strip()

        if bucket == "todo":
            todos.append((False, strip_label(content)))
        elif bucket == "decision":
            decisions.append(strip_label(content))
        elif DECISION_HINT.search(content):
            decisions.append(strip_label(content))
        elif TODO_HINT.search(content):
            todos.append((False, strip_label(content)))
        else:
            if title is None and not bullet:
                title = content[:40]
                day = day or parse_date(content)
                continue
            notes.append(content)

    attendees += [m for m in MENTION.findall(text) if m not in attendees]
    # de-duplicate while keeping order
    attendees = list(dict.fromkeys(attendees))

    return {
        "title": clean_title(title) if title else "会议记录",
        "date": day or fallback_day,
        "attendees": attendees,
        "decisions": decisions,
        "todos": todos,
        "notes": notes,
    }


def render_note(data):
    meta = {
        "date": data["date"].isoformat(),
        "title": data["title"],
        "attendees": data["attendees"],
    }
    out = [render_front_matter(meta), "", f"# {data['title']}", ""]

    if data["notes"]:
        out += ["## 记录", ""]
        out += [f"- {n}" for n in data["notes"]]
        out.append("")
    if data["decisions"]:
        out += ["## 决议", ""]
        out += [f"- {d}" for d in data["decisions"]]
        out.append("")
    out += ["## 待办", ""]
    if data["todos"]:
        out += [f"- [{'x' if done else ' '}] {t}" for done, t in data["todos"]]
    else:
        out.append("- [ ] （无）")
    out.append("")
    return "\n".join(out)


# --------------------------------------------------------------------------
# commands
# --------------------------------------------------------------------------


def cmd_new(args):
    ensure_dirs()
    day = parse_date(args.date, TODAY) if args.date else TODAY
    title = args.title or f"{day.isoformat()} 会议"
    path = note_path(day, title)
    if path.exists() and not args.force:
        die(f"已存在: {rel(path)}（用 --force 覆盖）")
    meta = {
        "date": day.isoformat(),
        "title": title,
        "attendees": args.attendee or [],
    }
    if args.tag:
        meta["tags"] = args.tag
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        render_front_matter(meta) + "\n\n" + f"# {title}\n"
        + TEMPLATE_BODY.format(due=day.isoformat()),
        encoding="utf-8",
    )
    print(rel(path))


def cmd_capture(args):
    ensure_dirs()
    text = " ".join(args.message) if args.message else sys.stdin.read()
    text = text.strip()
    if not text:
        die("没有内容可记录")
    path = INBOX / f"{TODAY.isoformat()}.md"
    stamp = datetime.now().strftime("%H:%M")
    with path.open("a", encoding="utf-8") as fh:
        fh.write(f"\n## {stamp}\n\n{text}\n")
    print(f"已记入 {rel(path)} ({stamp})")


def resolve_source(value):
    """Return (text, inbox_path_or_None, fallback_date)."""
    if value == "-":
        return sys.stdin.read(), None, TODAY
    if value is None:
        path = INBOX / f"{TODAY.isoformat()}.md"
        if not path.exists():
            die(f"今天的 inbox 是空的（{rel(path)}），先用 `mn capture` 记点东西")
        return path.read_text(encoding="utf-8"), path, TODAY
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        path = INBOX / f"{value}.md"
        if not path.exists():
            die(f"找不到 {rel(path)}")
        return path.read_text(encoding="utf-8"), path, date.fromisoformat(value)
    path = Path(value).expanduser()
    if not path.exists():
        die(f"找不到文件: {value}")
    stamp = date.fromtimestamp(path.stat().st_mtime)
    return path.read_text(encoding="utf-8"), None, stamp


def cmd_tidy(args):
    ensure_dirs()
    text, inbox_file, fallback = resolve_source(args.source)
    data = extract(text, fallback)
    if args.title:
        data["title"] = args.title
    if args.date:
        data["date"] = parse_date(args.date, data["date"])

    rendered = render_note(data)
    if args.dry_run:
        print(rendered)
        return

    path = note_path(data["date"], data["title"])
    if path.exists() and not args.force:
        die(f"已存在: {rel(path)}（用 --force 覆盖，或用 --title 换个标题）")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(rendered, encoding="utf-8")

    if inbox_file and not args.keep:
        ARCHIVE.mkdir(parents=True, exist_ok=True)
        inbox_file.rename(ARCHIVE / inbox_file.name)

    open_todos = sum(1 for done, _ in data["todos"] if not done)
    print(
        f"{rel(path)}\n"
        f"  参会 {len(data['attendees'])} 人 · 决议 {len(data['decisions'])} 条 · "
        f"待办 {open_todos} 条"
    )


def collect_todos(include_done=False):
    items = []
    for path in all_notes():
        _, _, lines = read_note(path)
        for lineno, line in enumerate(lines, 1):
            m = CHECKBOX.match(line)
            if not m:
                continue
            done = m.group(1).lower() == "x"
            text = m.group(2)
            if text.strip() in ("（无）", "(无)"):
                continue
            if done and not include_done:
                continue
            items.append(
                {
                    "path": str(path),
                    "line": lineno,
                    "raw": line,
                    "text": text,
                    "done": done,
                    "note": path.stem,
                }
            )
    return items


def cmd_todo(args):
    items = collect_todos(include_done=args.all or args.done)
    if args.done:
        items = [i for i in items if i["done"]]
    if args.owner:
        items = [i for i in items if todo_owner_due(i["text"])[0] == args.owner]
    if not items:
        print("没有待办。")
        return

    CACHE.parent.mkdir(parents=True, exist_ok=True)
    CACHE.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")

    for idx, item in enumerate(items, 1):
        owner, due = todo_owner_due(item["text"])
        mark = "x" if item["done"] else " "
        tail = []
        if owner:
            tail.append(f"@{owner}")
        if due:
            tail.append(f"due {due}")
        tail.append(item["note"])
        print(f"{idx:>3}. [{mark}] {item['text']}")
        print(f"      {' · '.join(tail)}")


def cmd_done(args):
    if not CACHE.exists():
        die("先运行 `mn todo` 列出待办，再用编号标记完成")
    items = json.loads(CACHE.read_text(encoding="utf-8"))
    for num in args.ids:
        if num < 1 or num > len(items):
            die(f"编号 {num} 超出范围（1-{len(items)}）")
        item = items[num - 1]
        path = Path(item["path"])
        lines = path.read_text(encoding="utf-8").splitlines()
        idx = item["line"] - 1
        if idx >= len(lines) or lines[idx] != item["raw"]:
            die(f"{rel(path)} 已变化，请重新运行 `mn todo`")
        lines[idx] = re.sub(r"\[ \]", "[x]", item["raw"], count=1) + \
            f" (done: {TODAY.isoformat()})"
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"✓ {item['text']}")
    CACHE.unlink()


def cmd_list(args):
    notes = all_notes()
    if args.since:
        floor = parse_date(args.since)
        if not floor:
            die(f"看不懂日期: {args.since}")
        notes = [p for p in notes if (parse_date(p.stem) or TODAY) >= floor]
    if not notes:
        print("还没有会议记录。")
        return
    for path in reversed(notes):
        meta, _, lines = read_note(path)
        open_n = sum(
            1
            for line in lines
            if (m := CHECKBOX.match(line))
            and m.group(1) == " "
            and m.group(2).strip() not in ("（无）", "(无)")
        )
        day = meta.get("date", "?")
        title = meta.get("title", path.stem)
        suffix = f"  ({open_n} 待办)" if open_n else ""
        print(f"{day}  {title}{suffix}")
        if args.paths:
            print(f"            {rel(path)}")


def cmd_find(args):
    needle = args.keyword.lower()
    hits = 0
    for path in all_notes():
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if needle in line.lower():
                hits += 1
                print(f"{rel(path)}:{lineno}: {line.strip()}")
    if not hits:
        print(f"没找到「{args.keyword}」。")


def cmd_index(args):
    notes = all_notes()
    by_month = {}
    for path in notes:
        meta, _, _ = read_note(path)
        day = meta.get("date", path.stem[:10])
        by_month.setdefault(day[:7], []).append((day, meta.get("title", path.stem), path))

    open_todos = collect_todos()
    out = ["# 会议记录索引", "", f"共 {len(notes)} 篇 · {len(open_todos)} 条待办", ""]
    for month in sorted(by_month, reverse=True):
        out += [f"## {month}", ""]
        for day, title, path in sorted(by_month[month], reverse=True):
            out.append(f"- {day} [{title}]({rel(path)})")
        out.append("")

    if open_todos:
        out += ["## 未完成待办", ""]
        for item in open_todos:
            out.append(f"- [ ] {item['text']}  <sub>{item['note']}</sub>")
        out.append("")

    target = HOME / "INDEX.md"
    target.write_text("\n".join(out), encoding="utf-8")
    print(rel(target))


# --------------------------------------------------------------------------
# cli
# --------------------------------------------------------------------------


def build_parser():
    p = argparse.ArgumentParser(prog="mn", description="会议记录整理小工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("capture", aliases=["c"], help="把零散片段丢进今天的 inbox")
    s.add_argument("message", nargs="*", help="内容；留空则从 stdin 读")
    s.set_defaults(func=cmd_capture)

    s = sub.add_parser("tidy", aliases=["t"], help="把零散内容整理成结构化会议记录")
    s.add_argument("source", nargs="?", help="日期 / 文件路径 / '-' 读 stdin；默认今天的 inbox")
    s.add_argument("--title", help="指定标题")
    s.add_argument("--date", help="指定日期")
    s.add_argument("--dry-run", action="store_true", help="只打印，不落盘")
    s.add_argument("--keep", action="store_true", help="保留 inbox 原文件")
    s.add_argument("--force", action="store_true", help="覆盖同名记录")
    s.set_defaults(func=cmd_tidy)

    s = sub.add_parser("new", aliases=["n"], help="按模板新建一篇会议记录")
    s.add_argument("title", nargs="?")
    s.add_argument("-d", "--date")
    s.add_argument("-p", "--attendee", action="append")
    s.add_argument("--tag", action="append")
    s.add_argument("--force", action="store_true")
    s.set_defaults(func=cmd_new)

    s = sub.add_parser("todo", help="汇总所有会议里的待办")
    s.add_argument("--all", action="store_true", help="含已完成")
    s.add_argument("--done", action="store_true", help="只看已完成")
    s.add_argument("--owner", help="只看某人的（@名字里的名字）")
    s.set_defaults(func=cmd_todo)

    s = sub.add_parser("done", help="按 `mn todo` 的编号标记完成")
    s.add_argument("ids", nargs="+", type=int)
    s.set_defaults(func=cmd_done)

    s = sub.add_parser("list", aliases=["ls"], help="列出会议记录")
    s.add_argument("--since", help="只看该日期之后的")
    s.add_argument("--paths", action="store_true", help="同时显示文件路径")
    s.set_defaults(func=cmd_list)

    s = sub.add_parser("find", aliases=["f"], help="全文搜索")
    s.add_argument("keyword")
    s.set_defaults(func=cmd_find)

    s = sub.add_parser("index", help="重新生成 INDEX.md")
    s.set_defaults(func=cmd_index)

    return p


def main():
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
