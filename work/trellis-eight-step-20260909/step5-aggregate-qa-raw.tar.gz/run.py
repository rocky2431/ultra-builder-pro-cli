import pathlib, subprocess, concurrent.futures, datetime, json, os, signal, hashlib
root=pathlib.Path.cwd(); d=root/'.ultra/.runtime/trellis-eight-step-20260909/aggregate'; r=root/'.ultra/reviews/vnext-d1-aggregate-stage-b-delta-20260909'
mission=(root/'work/trellis-eight-step-20260909/step5-aggregate-qa-mission.md').read_text()
def run(lens):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat(); out=d/(lens+'.events.jsonl');err=d/(lens+'.stderr.log');sd=d/(lens+'-sessions');sd.mkdir()
 prompt=mission+'\nAssigned lens: review-'+lens+'. Launch instant: '+start+'\n'
 args=['pi','--print','--mode','json','--offline','--no-extensions','--no-skills','--no-prompt-templates','--no-context-files','--tools','read,grep,find,ls','--session-dir',str(sd),'--',prompt]
 with out.open('w') as o,err.open('w') as e:
  proc=subprocess.Popen(args,stdout=o,stderr=e,start_new_session=True)
  try: code=proc.wait(timeout=420)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGTERM);code=proc.wait(timeout=15)
 events=[json.loads(x) for x in out.read_text().splitlines() if x.strip()];ends=[x for x in events if x.get('type')=='agent_end']; messages=[x['message'] for x in events if x.get('type')=='message_end' and x.get('message',{}).get('role')=='assistant'];final=messages[-1] if messages else {}
 meta={'lens':lens,'started_at':start,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code,'stop_reason':final.get('stopReason'),'agent_end':bool(ends),'events_sha256':hashlib.sha256(out.read_bytes()).hexdigest()}
 if code==0 and ends and final.get('stopReason')=='stop':
  text=''.join(c.get('text','') for c in final.get('content',[]) if c.get('type')=='text').strip()
  if text.startswith('```'):text=text.split('\n',1)[1].rsplit('```',1)[0].strip()
  json.loads(text);target=r/('review-'+lens+'.json');target.write_text(text+'\n');meta['artifact_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
 (d/(lens+'.result.json')).write_text(json.dumps(meta,indent=2)+'\n');return meta
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
 for result in ex.map(run,['spec','tests','errors']):print(json.dumps(result),flush=True)
