# Architecture Specification

## Scope

- Repository: this isolated local sample at the canonical closeout revision.
- Contract: `.ultra/specs/product.md` and fixed `GOAL.md`.
- Runtime: Node.js CommonJS, standard library only.

## Building Blocks and Runtime Paths

| Building block | Responsibility | Dependencies | Consumer |
|---|---|---|---|
| `src/csv/index.cjs` | strict CSV decoding | none | `cli.cjs` |
| `src/money.cjs` | exact safe cents conversion | BigInt | `src/domain/index.cjs` |
| `src/domain/index.cjs` | row/ledger validation and reporting | money seam | `cli.cjs` |
| `cli.cjs` | command dispatch, duplicate reconciliation, atomic persistence | all modules, Node fs/path/crypto | operator |

## Data and State Authority

| State | Authoritative owner | Writers | Readers | Rule |
|---|---|---|---|---|
| ledger JSON array | named local ledger file | `cli.cjs import` | import/report | validate fully before unique same-directory temp and rename |

## Quality Scenarios and Risks

| Trigger | Expected response | Verification | Residual |
|---|---|---|---|
| malformed CSV or ledger | explanatory nonzero exit and unchanged destination | acceptance and supplement | malformed UTF-8 replacement not specified |
| unsafe amount or total | reject without precision loss | focused checks | none inside safe-integer contract |
| concurrent imports | unspecified | omitted | possible lost update |

## Product Traceability

| Requirement | Architecture path | Public seam | Evidence |
|---|---|---|---|
| Import | parser → validation → persistence | `cli.cjs import` | `acceptance.cjs` |
| Report | validation → BigInt aggregation | `cli.cjs report` | acceptance and focused checks |
