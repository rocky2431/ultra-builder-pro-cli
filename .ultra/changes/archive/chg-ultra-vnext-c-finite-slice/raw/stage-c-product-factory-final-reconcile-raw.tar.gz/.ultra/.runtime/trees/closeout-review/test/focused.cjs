'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { cents } = require('../src/money.cjs');
const { parseCsv } = require('../src/csv/index.cjs');
const { validateLedger, report } = require('../src/domain/index.cjs');

assert.equal(cents('+0.00'), 0);
assert.equal(Object.is(cents('-0.00'), -0), false);
assert.equal(cents('90071992547409.91'), Number.MAX_SAFE_INTEGER);
assert.throws(() => cents('90071992547409.92'), /safe integer/);
assert.throws(() => cents('1.00\n'), /decimal/);
assert.deepEqual(parseCsv('a\n\n'), [['a'], ['']]);
assert.throws(() => parseCsv('a,"b"x\n'), /closing quote/);
assert.throws(() => validateLedger([{ id: 'x', date: '2026-01-01', amount_cents: 1, currency: 'USD', category: 'A', note: '', extra: true }]), /exactly/);
assert.throws(() => validateLedger([{ id: 'x', date: ['2026-01-01'], amount_cents: 1, currency: 'USD', category: 'A', note: '' }]), /date/);
assert.throws(() => validateLedger([{ id: 'x', date: '2026-01-01\n', amount_cents: 1, currency: 'USD', category: 'A', note: '' }]), /date/);
assert.throws(() => validateLedger([{ id: 'x', date: '2026-01-01', amount_cents: 1, currency: 'USD\n', category: 'A', note: '' }]), /currency/);
assert.throws(() => validateLedger([
  { id: 'x', date: '2026-01-01', amount_cents: 1, currency: 'USD', category: 'A', note: '' },
  { id: 'x', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'A', note: '' },
]), /duplicate/);
assert.throws(() => report([], '2026-01\n'), /month/);
assert.throws(() => report([
  { id: 'x', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'A', note: '' },
  { id: 'y', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'A', note: '' },
], '2026-01'), /safe integer/);
assert.equal(report([
  { id: 'x', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'A', note: '' },
  { id: 'y', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'A', note: '' },
  { id: 'z', date: '2026-01-03', amount_cents: -1, currency: 'USD', category: 'A', note: '' },
], '2026-01')[0].total_cents, Number.MAX_SAFE_INTEGER);

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-focused-'));
try {
  const ledger = path.join(dir, 'ledger.json');
  const csv = path.join(dir, 'input.csv');
  fs.writeFileSync(ledger, '[{"id":"x","date":"2026-01-01","amount_cents":1,"currency":"USD","category":"A","note":""}]\n');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,2026-01-01,0.01,USD,A,\n');
  const before = fs.readFileSync(ledger);
  const result = spawnSync(process.execPath, ['cli.cjs', 'import', csv, ledger], { cwd: path.join(__dirname, '..'), encoding: 'utf8' });
  assert.equal(result.status, 0, result.stderr);
  assert.deepEqual(JSON.parse(result.stdout), { added: 0, skipped: 1 });
  assert.deepEqual(fs.readFileSync(ledger), before);
} finally {
  fs.rmSync(dir, { recursive: true, force: true });
}
console.log(JSON.stringify({ passed: true, checks: 16 }));
