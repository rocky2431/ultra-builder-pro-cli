# Product Specification

## Scope

- Product boundary: dependency-free local Node CLI defined by `GOAL.md`.
- Intended outcome: safely import exact bank CSV records and print exact monthly grouped totals.
- Explicit non-goals: network, accounts, database, UI, concurrency guarantees, production data, and publication.

## Behavioral Requirements and Acceptance

### Requirement: local ledger import
- Source: `GOAL.md#local-expense-ledger`
- Preconditions: exact CSV header and local destination path.
- Action: `node cli.cjs import <csv-file> <ledger-file>`.
- Observable result: JSON added/skipped counts and canonical records; identical IDs skip.
- Error behavior: malformed/conflicting data exits nonzero and preserves existing bytes.
- Verification: unchanged `acceptance.cjs` and supplementary checker.

### Requirement: monthly report
- Source: `GOAL.md#local-expense-ledger`
- Action: `node cli.cjs report <ledger-file> <YYYY-MM>`.
- Observable result: exact safe totals grouped and sorted by currency then category.
- Error behavior: malformed ledger or month exits nonzero with stderr.
- Verification: unchanged `acceptance.cjs` plus focused checks.

## Documentation Impact

`README.md` documents both runnable commands and the accepted local boundary.

## Architecture Traceability

| Requirement | Public seam | Architecture path | Verification evidence |
|---|---|---|---|
| Import | `cli.cjs import` | CSV parser → domain validation → transactional JSON persistence | `acceptance.cjs` |
| Report | `cli.cjs report` | ledger validation → exact grouped report | `acceptance.cjs`; `test/focused.cjs` |
