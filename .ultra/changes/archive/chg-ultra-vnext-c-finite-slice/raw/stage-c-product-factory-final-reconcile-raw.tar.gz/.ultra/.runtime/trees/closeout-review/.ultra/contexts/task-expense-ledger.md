# Task expense-ledger: Implement and close local expense ledger

## Change Acceptance IDs
- AC-01, AC-02, AC-03, AC-04

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| A-01 | Unchanged owner acceptance passes on the final subject. | command | Raw stdout/stderr and exit from `node acceptance.cjs`. |
| A-02 | Unchanged supplementary checker passes on the final subject. | command | Raw stdout/stderr and exit from the supplied checker. |
| A-03 | Dependency-free CLI behavior and two README examples match the fixed goal. | inspection | `cli.cjs`, `src/**`, and `README.md` at final revision. |
| A-04 | Owner-designated read-only Pi independently approves the exact completion subject. | external-observation | Valid external-manual receipt and retained Pi result. |

## Confirmed Seams
- `cli.cjs` is the public command seam.
- `src/csv/index.cjs`, `src/domain/index.cjs`, and `src/money.cjs` are internal module seams.
- Local JSON ledger bytes are the persistence seam.

## Layers Touched
- CLI dispatch, CSV parsing, validation, exact money/reporting, persistence, tests, and documentation.

## Target Files
- `cli.cjs`, `src/**`, `test/focused.cjs`, `README.md`.

## Implementation
- Historical implementation is preserved in Git revisions through `2c34394c894d7f8b71a33eccd9534113f18b5086`.
- Canonical adoption occurred afterward during this closeout.
- One requested Solo repair adds an explicit inner date-string guard and regression; no Factory repair budget is reopened.

## Verification Commands
- `node acceptance.cjs`
- `node test/focused.cjs`
- `node /Users/rocky243/Context Engineering/ultra-builder-pro-cli/work/trellis-eight-step-20260909/stage-c-product-supplement.cjs "$PWD"`

## Hard Constraints
- HC-1: no dependencies, network, publication, version bump, owner-fixture edits, or Ultra/tool changes.

## Trace
- FP-1: validation and atomic persistence preserve trustworthy records.
- FP-2: exact cents and per-currency aggregation prevent monetary corruption.
- NS-1: the local CLI realizes reliable import/report behavior.
- HC-1: implementation stays an isolated dependency-free sample.

## Definition of Drift
- Any source change, acceptance-section change, failed command, receipt mismatch, or product-worktree digest change requires fresh evidence.

## Change Log
- 2026-09-09: Adopted the already-built treatment into canonical records after implementation; no status was backdated.
- 2026-09-09: Added requested explicit date type guard and array-date focused regression as Solo repair iteration 1.

## Completion
- Pending fresh exact-subject tests and external Pi review before evidence publication.

## Task Review
- Pending owner-designated external-manual Pi receipt; earlier Factory reviewer findings and failed reviewer-1 remain historical evidence.

## Resume Note
Canonical adoption and the narrow date guard are prepared. Task remains in progress until final commands, exact-subject external receipt, and v2 evidence validate.
