# Project Brief

> **Authority**: raw owner intake captured during brownfield adoption after the initial product treatment. It does not backdate implementation authority or evidence.

## One-line

Build the fixed `GOAL.md` local expense ledger CLI and complete canonical closeout without rewriting the initial treatment.

## Initial Outline

- What it is: a dependency-free Node CLI importing bank CSV into a local JSON ledger and reporting monthly totals.
- Broadly for whom or what: a small team using synthetic local data.
- Intended result: exact, transactional import and currency-separated monthly reporting.
- Broad boundary: local files only; no network, accounts, database, UI, publication, or version bump.

## Explicit Inputs

- `GOAL.md` is the fixed accepted experiment intent.
- `acceptance.cjs` and the external supplementary checker are read-only.
- Prior source, Git history, evidence, and runtime receipts remain historical facts.
- Canonical adoption occurs now, after the initial product treatment.

## Open Questions for Research

- None for this bounded closeout; the owner supplied the product boundary and acceptance sources.
