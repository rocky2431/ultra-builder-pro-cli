# Change expense-ledger: Local expense ledger

> **Status**: accepted
> **Profile**: standard
> **Profile rationale**: One bounded CLI with transactional persistence and exact-money integration risk.
> **Risk flags**: local data integrity and numeric correctness

## Outcome
A dependency-free local Node CLI imports valid bank CSV without corrupting existing ledger bytes and prints exact currency-separated monthly totals.

## Acceptance
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| AC-01 | Fixed `GOAL.md` behavior passes unchanged owner acceptance. | command | Exit 0 and retained output from `node acceptance.cjs`. |
| AC-02 | Supplementary malformed-date-type, quoted EOF, and invalid-quote cases pass without editing the checker. | command | Exit 0 and retained output from the owner-supplied supplementary checker. |
| AC-03 | Final repairs have current independent read-only Pi disposition. | external-observation | Qualified Pi receipt bound to final HEAD and worktree digest. |
| AC-04 | CLI remains dependency-free and README has two runnable examples. | inspection | Source and README inspection at final revision. |

## Non-goals
- Network, accounts, database, UI, concurrent-writer locking, version bump, package publication, or production use.

## Public Seams
- `node cli.cjs import <csv-file> <ledger-file>`
- `node cli.cjs report <ledger-file> <YYYY-MM>`

## Reconciliation
### Promised and Missing
- The prior initial claim lacked canonical task, Review, Test, and Deliver records; this closeout creates them now without backdating.

### Built and Unpromised
- Focused checks cover strict anchors, safe aggregate cancellation, and byte-preserving no-op import; these support GOAL.md rather than expand it.

### Contradictory
- The operator described a Solo date-array defect, while this Factory checkout and frozen supplementary result already reject that case through outer validation. The requested inner type guard and regression are still added and accounted as the one Solo repair, without rewriting the prior result.

## Research Disposition
- Disposition: none
- Question: none
- Selected lenses: none
- Existing evidence: `GOAL.md`, `acceptance.cjs`, `probe/baseline.json`, `probe/supplement.json`, source and Git history.
- Required exit evidence: none beyond accepted brownfield adoption records.
- Rationale: The owner fixed the goal and explicitly stated no missing business choice or exploratory interview exists.

## North Star Trace
- First principles: FP-1 safe preservation; FP-2 exact currency-separated money.
- Serves: NS-1 reliable local expense ledger.
- Touches: HC-1 isolated dependency-free sample.
- Evidence: `GOAL.md`, `.ultra/specs/product.md`, and `.ultra/specs/architecture.md` establish the causal boundary.
- North Star revision: expense-ledger-r1
- North Star digest: ba6099d9d017099fb3e3a131a8dc5cea00d0446a
- Contradictions or refinements: none requiring owner disposition.

## Execution Grant

- Grant: `session-local`
- Allowed workflows: plan, dev, test, deliver-reconcile
- Agent topology: Primary is sole semantic/task writer; qualified Pi is read-only external QA.
- Allowed local effects: canonical sample records, the one Solo type-check repair, tests, evidence, local commits, and archive.
- Budgets and expiry: this explicit continuation, 20 minutes; one Factory delta review; one previously unused Solo repair; no Factory source repairs.
- Mandatory reviews: external Pi current-subject QA, canonical task evidence, aggregate Review, Test, and Deliver finalization.
- Stop conditions: remaining independent P0/P1, stale binding, failed required command, or budget expiry.
- Invalidation: source/evidence drift after final snapshot or any scope expansion.
- Never granted: network, version bump, publication, push, tag, deployment, Ultra/tool/qualification/HOME/credential changes.
- Activation: current explicit operator instruction selecting canonical closeout and local Deliver finalization.

## Planning Posture
SELECTIVE: adopt one existing tracer task because this is one already-built public CLI; the owner requested minimal canonical records.

## Recovery
Use Git revert of the closeout commits; failed imports preserve destination bytes and canonical history retains all pre-adoption evidence.

## Unresolved Decisions
- None.
