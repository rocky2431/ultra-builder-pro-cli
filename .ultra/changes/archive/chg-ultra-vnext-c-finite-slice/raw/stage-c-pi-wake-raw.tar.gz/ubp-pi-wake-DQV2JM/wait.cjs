const fs = require('node:fs');
module.exports = (pi) => { pi.registerTool({
  name: 'receive_attention', label: 'Receive Attention',
  description: 'Block mechanically for one finite completion; return its bounded attention.',
  parameters: {type:'object',properties:{},additionalProperties:false},
  async execute() {
    const before = Date.now();
    await new Promise(resolve => setTimeout(resolve, 3000));
    const attention = {run_id:'wake-spike',slice_id:'w1',event_id:'wave-1',reason:'wave_terminal',counts:{finished:2},result_refs:['left.json','right.json']};
    fs.writeFileSync('wait-observation.json',JSON.stringify({before,after:Date.now(),attention})+'\n');
    return {content:[{type:'text',text:JSON.stringify(attention)}],details:{}};
  }
});
pi.on('session_start', () => {
  pi.setActiveTools(['read','write','receive_attention']);
  fs.writeFileSync('active-tools.json',JSON.stringify(pi.getActiveTools())+'\n');
});
};
