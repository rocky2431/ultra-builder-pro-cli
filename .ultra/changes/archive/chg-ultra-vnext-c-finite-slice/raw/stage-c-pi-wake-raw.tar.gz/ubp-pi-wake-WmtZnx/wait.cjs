const fs = require('node:fs');
module.exports = (pi) => { pi.registerTool({
  name: 'receive_attention', label: 'Receive Attention',
  description: 'Block mechanically for one finite completion; return its bounded attention.',
  parameters: {type:'object',properties:{},additionalProperties:false},
  async execute() {
    const before = Date.now();
    await new Promise(resolve => setTimeout(resolve, 3000));
    const attention = {run_id:'wake-spike',slice_id:'w1',event_id:'wave-1',reason:'wave_terminal',counts:{finished:2},result_refs:['left.json','right.json']};
    fs.writeFileSync('wait-observation.json',JSON.stringify({before,after:Date.now(),attention})+'\n');
    return {content:[{type:'text',text:JSON.stringify(attention)}],details:{}};
  }
});
pi.on('session_start', () => {
  pi.setActiveTools(['read','write','receive_attention','queue_attention']);
  fs.writeFileSync('active-tools.json',JSON.stringify(pi.getActiveTools())+'\n');
});
let armed = false, seen = false;
const message = 'ULTRA_ATTENTION wake-spike/w2/wave-2: two workers finished; result refs left.json and right.json. Read both, decide whether their total is ten, and write decision.json with event_key:"wake-spike/w2/wave-2", combined_total and boolean matches_target. No other effects.';
pi.registerTool({name:'queue_attention',label:'Queue Attention',description:'Start one finite background completion after this turn settles.',parameters:{type:'object',properties:{},additionalProperties:false},async execute(){armed=true;return {content:[{type:'text',text:'started; end this turn without polling'}],details:{}};}});
pi.on('agent_settled', () => { if(armed){armed=false;setTimeout(()=>pi.sendUserMessage(message,{deliverAs:'followUp'}),3000);} });
pi.on('input', (event) => {
  if(event.source==='extension' && event.text===message){
    fs.appendFileSync('delivery-events.jsonl',JSON.stringify({at:Date.now(),status:seen?'duplicate_suppressed':'input_observed'})+'\n');
    if(seen)return {action:'handled'};
    seen=true;
  }
  return {action:'continue'};
});
pi.registerCommand('repeat_attention',{description:'Replay the same finite wake input',handler:async()=>{pi.sendUserMessage(message,{deliverAs:'followUp'});}});
};
