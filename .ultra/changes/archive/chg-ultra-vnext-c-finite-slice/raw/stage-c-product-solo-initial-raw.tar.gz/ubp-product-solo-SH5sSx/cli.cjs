#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { cents } = require('./src/money.cjs');

const HEADER = ['id', 'date', 'amount', 'currency', 'category', 'note'];
const LEDGER_KEYS = ['id', 'date', 'amount_cents', 'currency', 'category', 'note'];

function fail(message) {
  throw new Error(message);
}

function parseCsv(text) {
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1);
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  let closed = false;

  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          quoted = false;
          closed = true;
        }
      } else {
        field += ch;
      }
      continue;
    }
    if (closed && ch !== ',' && ch !== '\n' && ch !== '\r') fail('malformed CSV: text after closing quote');
    if (ch === '"') {
      if (field !== '' || closed) fail('malformed CSV: unexpected quote');
      quoted = true;
    } else if (ch === ',') {
      row.push(field);
      field = '';
      closed = false;
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r') {
        if (text[i + 1] !== '\n') fail('malformed CSV: bare carriage return');
        i += 1;
      }
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
      closed = false;
    } else {
      field += ch;
    }
  }
  if (quoted) fail('malformed CSV: unclosed quoted field');
  if (row.length || field !== '' || closed || (text.length && !/[\r\n]$/.test(text))) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

function validDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return month >= 1 && month <= 12 && day >= 1 && day <= days[month - 1];
}

function validateRecord(record, where) {
  if (!record || typeof record !== 'object' || Array.isArray(record)) fail(`${where}: record must be an object`);
  const keys = Object.keys(record);
  if (keys.length !== LEDGER_KEYS.length || !LEDGER_KEYS.every((key) => keys.includes(key))) fail(`${where}: record has invalid fields`);
  if (typeof record.id !== 'string' || record.id.length === 0) fail(`${where}: id must be nonempty`);
  if (!validDate(record.date)) fail(`${where}: invalid date`);
  if (!Number.isSafeInteger(record.amount_cents)) fail(`${where}: amount_cents must be a safe integer`);
  if (typeof record.currency !== 'string' || !/^[A-Z]{3}$/.test(record.currency)) fail(`${where}: invalid currency`);
  if (typeof record.category !== 'string' || record.category.length === 0) fail(`${where}: category must be nonempty`);
  if (typeof record.note !== 'string') fail(`${where}: note must be text`);
  return record;
}

function recordsEqual(a, b) {
  return LEDGER_KEYS.every((key) => a[key] === b[key]);
}

function readLedger(file, allowMissing) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    if (allowMissing && error.code === 'ENOENT') return [];
    fail(`cannot read ledger: ${error.message}`);
  }
  let ledger;
  try {
    ledger = JSON.parse(text);
  } catch (error) {
    fail(`malformed ledger JSON: ${error.message}`);
  }
  if (!Array.isArray(ledger)) fail('malformed ledger: expected a JSON array');
  const seen = new Map();
  ledger.forEach((record, index) => {
    validateRecord(record, `ledger record ${index + 1}`);
    if (seen.has(record.id) && !recordsEqual(seen.get(record.id), record)) fail(`malformed ledger: conflicting id ${JSON.stringify(record.id)}`);
    seen.set(record.id, record);
  });
  return ledger;
}

function csvRecords(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    fail(`cannot read CSV: ${error.message}`);
  }
  const rows = parseCsv(text);
  if (!rows.length || rows[0].length !== HEADER.length || !HEADER.every((value, i) => rows[0][i] === value)) fail(`CSV header must be exactly ${HEADER.join(',')}`);
  return rows.slice(1).map((row, index) => {
    if (row.length !== HEADER.length) fail(`CSV row ${index + 2}: expected 6 columns, found ${row.length}`);
    const [id, date, amount, currency, category, note] = row;
    if (!/^-?\d+\.\d{2}$/.test(amount)) fail(`CSV row ${index + 2}: invalid amount`);
    let amountCents;
    try {
      amountCents = cents(amount);
    } catch (error) {
      fail(`CSV row ${index + 2}: ${error.message}`);
    }
    return validateRecord({ id, date, amount_cents: amountCents, currency, category, note }, `CSV row ${index + 2}`);
  });
}

function persist(file, ledger) {
  const dir = path.dirname(path.resolve(file));
  const base = path.basename(file);
  const temporary = path.join(dir, `.${base}.${process.pid}.${Date.now()}.tmp`);
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(ledger, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporary, file);
  } catch (error) {
    try { fs.unlinkSync(temporary); } catch (_) { /* nothing to clean up */ }
    fail(`cannot persist ledger: ${error.message}`);
  }
}

function importCsv(csvFile, ledgerFile) {
  const ledger = readLedger(ledgerFile, true);
  const incoming = csvRecords(csvFile);
  const byId = new Map();
  for (const record of ledger) if (!byId.has(record.id)) byId.set(record.id, record);
  let added = 0;
  let skipped = 0;
  const additions = [];
  for (const record of incoming) {
    const prior = byId.get(record.id);
    if (prior) {
      if (!recordsEqual(prior, record)) fail(`conflicting repeated id ${JSON.stringify(record.id)}`);
      skipped += 1;
    } else {
      byId.set(record.id, record);
      additions.push(record);
      added += 1;
    }
  }
  persist(ledgerFile, ledger.concat(additions));
  return { added, skipped };
}

function report(ledgerFile, month) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) fail('month must be YYYY-MM');
  const ledger = readLedger(ledgerFile, false);
  const groups = new Map();
  for (const record of ledger) {
    if (!record.date.startsWith(`${month}-`)) continue;
    const key = `${record.currency}\0${record.category}`;
    const current = groups.get(key) || { currency: record.currency, category: record.category, total_cents: 0, count: 0 };
    const total = current.total_cents + record.amount_cents;
    if (!Number.isSafeInteger(total)) fail(`unsafe report total for ${record.currency}/${record.category}`);
    current.total_cents = total;
    current.count += 1;
    groups.set(key, current);
  }
  return [...groups.values()].sort((a, b) => {
    if (a.currency !== b.currency) return a.currency < b.currency ? -1 : 1;
    if (a.category === b.category) return 0;
    return a.category < b.category ? -1 : 1;
  });
}

function main(args) {
  if (args[0] === 'import' && args.length === 3) return importCsv(args[1], args[2]);
  if (args[0] === 'report' && args.length === 3) return report(args[1], args[2]);
  fail('usage: node cli.cjs import <csv-file> <ledger-file>\n       node cli.cjs report <ledger-file> <YYYY-MM>');
}

try {
  process.stdout.write(`${JSON.stringify(main(process.argv.slice(2)))}\n`);
} catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
