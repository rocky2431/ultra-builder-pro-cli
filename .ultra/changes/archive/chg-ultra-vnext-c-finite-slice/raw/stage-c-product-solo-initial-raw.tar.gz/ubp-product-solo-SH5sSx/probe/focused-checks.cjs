'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-focused-'));
const invoke = (...args) => spawnSync(process.execPath, ['cli.cjs', ...args], { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' });
const checks = [];
function check(name, fn) { try { fn(); checks.push({ name, passed: true }); } catch (error) { checks.push({ name, passed: false, error: error.message }); } }
check('batch-conflict-does-not-create-ledger', () => {
  const csv = path.join(root, 'conflict.csv'); const ledger = path.join(root, 'absent.json');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,2024-01-01,1.00,USD,A,one\nx,2024-01-01,2.00,USD,A,two\n');
  const result = invoke('import', csv, ledger); assert.notEqual(result.status, 0); assert.match(result.stderr, /conflicting repeated id/); assert.equal(fs.existsSync(ledger), false);
});
check('safe-boundary-is-accepted', () => {
  const csv = path.join(root, 'safe.csv'); const ledger = path.join(root, 'safe.json');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,2024-01-01,90071992547409.91,USD,A,max\n');
  assert.equal(invoke('import', csv, ledger).status, 0); assert.equal(JSON.parse(fs.readFileSync(ledger))[0].amount_cents, Number.MAX_SAFE_INTEGER);
});
check('unsafe-aggregate-is-rejected', () => {
  const ledger = path.join(root, 'total.json');
  fs.writeFileSync(ledger, JSON.stringify([
    { id: 'x', date: '2024-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'A', note: '' },
    { id: 'y', date: '2024-01-02', amount_cents: 1, currency: 'USD', category: 'A', note: '' }
  ]));
  const result = invoke('report', ledger, '2024-01'); assert.notEqual(result.status, 0); assert.match(result.stderr, /unsafe report total/);
});
check('invalid-ledger-schema-is-rejected', () => {
  const ledger = path.join(root, 'schema.json'); fs.writeFileSync(ledger, '[{"id":"x"}]');
  const result = invoke('report', ledger, '2024-01'); assert.notEqual(result.status, 0); assert.match(result.stderr, /invalid fields/);
});
fs.rmSync(root, { recursive: true, force: true });
console.log(JSON.stringify({ checks, passed: checks.filter((item) => item.passed).length, total: checks.length }, null, 2));
process.exitCode = checks.every((item) => item.passed) ? 0 : 1;
