# Local expense ledger

A dependency-free Node.js CLI that imports bank CSV exports into a local JSON ledger and reports monthly totals. Data stays in local files.

Requires Node.js 18 or newer.

## CSV format

The header must be exactly:

```csv
id,date,amount,currency,category,note
```

Dates use `YYYY-MM-DD`, amounts have exactly two decimal places, and currencies are three uppercase ASCII letters. Standard CSV quoted fields support commas, line breaks, and doubled quotes.

## Commands

Import records (creating `ledger.json` when absent):

```sh
node cli.cjs import expenses.csv ledger.json
```

Print totals for September 2026, grouped and sorted by currency then category:

```sh
node cli.cjs report ledger.json 2026-09
```

Both commands print JSON to stdout. Errors are written to stderr and return a nonzero status. Imports are atomic: validation and ID-conflict checks complete before a same-directory temporary file is renamed over the ledger.

## Verification

```sh
node acceptance.cjs
```
