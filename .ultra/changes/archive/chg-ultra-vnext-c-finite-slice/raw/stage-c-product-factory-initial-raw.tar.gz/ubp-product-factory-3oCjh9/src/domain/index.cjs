'use strict';

const { cents } = require('../money.cjs');

const HEADER = Object.freeze(['id', 'date', 'amount', 'currency', 'category', 'note']);
const RECORD_KEYS = ['id', 'date', 'amount_cents', 'currency', 'category', 'note'];
const MONEY = /^[+-]?\d+\.\d{2}(?![\s\S])/;
const CURRENCY = /^[A-Z]{3}(?![\s\S])/;
const DATE = /^(\d{4})-(\d{2})-(\d{2})(?![\s\S])/;
const MONTH = /^(\d{4})-(\d{2})(?![\s\S])/;

function fail(message) {
  throw new Error(message);
}

function validDate(value) {
  const match = DATE.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (year < 1 || year > 9999 || month < 1 || month > 12 || day < 1) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day <= days[month - 1];
}

function validMonth(value) {
  const match = MONTH.exec(value);
  return Boolean(match) && Number(match[1]) >= 1 && Number(match[1]) <= 9999 &&
    Number(match[2]) >= 1 && Number(match[2]) <= 12;
}

function decimalCents(value) {
  if (typeof value !== 'string' || !MONEY.test(value)) {
    fail('amount must be a signed decimal with exactly two fractional digits');
  }
  const negative = value[0] === '-';
  const unsigned = value[0] === '+' || negative ? value.slice(1) : value;
  const magnitude = BigInt(unsigned.slice(0, -3)) * 100n + BigInt(unsigned.slice(-2));
  const exact = negative ? -magnitude : magnitude;
  if (exact > BigInt(Number.MAX_SAFE_INTEGER) || exact < BigInt(Number.MIN_SAFE_INTEGER)) {
    fail('amount cents must be a safe integer');
  }

  const converted = cents(value);
  if (!Number.isSafeInteger(converted) || converted !== Number(exact)) {
    fail('amount cents must be converted exactly as a safe integer');
  }
  return converted === 0 ? 0 : converted;
}

function validateFields(id, date, amountCents, currency, category, note) {
  if (typeof id !== 'string' || id.length === 0) fail('record id must be a nonempty string');
  if (typeof date !== 'string' || !validDate(date)) fail('record date must be a real YYYY-MM-DD date');
  if (!Number.isSafeInteger(amountCents)) fail('record amount_cents must be a safe integer');
  if (typeof currency !== 'string' || !CURRENCY.test(currency)) fail('record currency must be three uppercase ASCII letters');
  if (typeof category !== 'string' || category.length === 0) fail('record category must be a nonempty string');
  if (typeof note !== 'string') fail('record note must be a string');
}

function normalizeRows(rows) {
  if (!Array.isArray(rows) || rows.length === 0) fail('CSV must contain the required header');
  const header = rows[0];
  if (!Array.isArray(header) || header.length !== HEADER.length ||
      header.some((field, index) => field !== HEADER[index])) {
    fail('CSV header must be exactly id,date,amount,currency,category,note');
  }

  return rows.slice(1).map((row, index) => {
    if (!Array.isArray(row) || row.length !== HEADER.length || row.some(field => typeof field !== 'string')) {
      fail(`CSV row ${index + 2} must have exactly six string columns`);
    }
    const [id, date, amount, currency, category, note] = row;
    const amount_cents = decimalCents(amount);
    validateFields(id, date, amount_cents, currency, category, note);
    return { id, date, amount_cents, currency, category, note };
  });
}

function validateLedger(value) {
  if (!Array.isArray(value)) fail('ledger must be a JSON array');
  const ids = new Set();
  return value.map((record, index) => {
    if (record === null || typeof record !== 'object' || Array.isArray(record)) {
      fail(`ledger record ${index + 1} must be an object`);
    }
    const keys = Object.keys(record);
    if (keys.length !== RECORD_KEYS.length || RECORD_KEYS.some(key => !Object.prototype.hasOwnProperty.call(record, key))) {
      fail(`ledger record ${index + 1} must contain exactly the required fields`);
    }
    const { id, date, amount_cents, currency, category, note } = record;
    validateFields(id, date, amount_cents, currency, category, note);
    if (ids.has(id)) fail(`ledger contains duplicate id: ${id}`);
    ids.add(id);
    return { id, date, amount_cents, currency, category, note };
  });
}

function report(records, month) {
  if (typeof month !== 'string' || !validMonth(month)) fail('report month must be YYYY-MM');
  const totals = new Map();
  for (const record of validateLedger(records)) {
    if (!record.date.startsWith(`${month}-`)) continue;
    const key = `${record.currency}\u0000${record.category}`;
    const previous = totals.get(key) || { currency: record.currency, category: record.category, total: 0n, count: 0 };
    previous.total += BigInt(record.amount_cents);
    previous.count += 1;
    totals.set(key, previous);
  }
  const results = [...totals.values()].map(({ currency, category, total, count }) => {
    if (total > BigInt(Number.MAX_SAFE_INTEGER) || total < BigInt(Number.MIN_SAFE_INTEGER)) {
      fail('report total cents must be a safe integer');
    }
    return { currency, category, total_cents: Number(total), count };
  });
  return results.sort((left, right) => {
    if (left.currency < right.currency) return -1;
    if (left.currency > right.currency) return 1;
    if (left.category < right.category) return -1;
    if (left.category > right.category) return 1;
    return 0;
  });
}

module.exports = { HEADER, normalizeRows, validateLedger, report };
