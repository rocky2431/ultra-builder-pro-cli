'use strict';

const DECIMAL = /^[+-]?\d+\.\d{2}(?![\s\S])/;

exports.cents = function cents(value) {
  if (typeof value !== 'string' || !DECIMAL.test(value)) {
    throw new Error('amount must be a decimal with exactly two fractional digits');
  }
  const negative = value[0] === '-';
  const unsigned = value[0] === '+' || negative ? value.slice(1) : value;
  const exact = BigInt(unsigned.slice(0, -3)) * 100n + BigInt(unsigned.slice(-2));
  const signed = negative ? -exact : exact;
  if (signed > BigInt(Number.MAX_SAFE_INTEGER) || signed < BigInt(Number.MIN_SAFE_INTEGER)) {
    throw new Error('amount cents must be a safe integer');
  }
  const result = Number(signed);
  return result === 0 ? 0 : result;
};
