# Expense ledger worker interface

Planning base decomposition (chosen by the Primary):

- **worker-left / CSV seam** owns only `src/csv/`. Implement `src/csv/index.cjs` exporting `parseCsv(text)`. It returns an array of rows, each row an array of decoded string fields. It must accept UTF-8 BOM, LF/CRLF, quoted commas/newlines, and doubled quotes; reject malformed quoting and inconsistent line endings only where CSV syntax is invalid. It does not validate the application header or fields.
- **worker-right / domain seam** owns only `src/domain/`. Implement `src/domain/index.cjs` exporting `HEADER`, `normalizeRows(rows)`, `validateLedger(value)`, and `report(records, month)`. `normalizeRows` requires the exact six-column header, validates each row and returns ledger records. Money conversion is delegated to `require('../money.cjs').cents`; the Primary owns repair of that seeded module. `validateLedger` returns validated normalized ledger records or throws. `report` validates `YYYY-MM`, groups without mixing currencies, and sorts by currency then category.
- **Primary seam** owns `src/money.cjs`, `cli.cjs`, persistence, integration, README, evidence, and commits. The CLI parses CSV with the left module, normalizes and reports with the right module, applies ID duplicate/conflict rules before any write, and persists by same-directory temporary file plus rename.

Shared data contracts (revised after read-only challenge):

- Parser output preserves every decoded field character as a JavaScript string. Only a BOM at offset zero is removed. LF and CRLF delimit records and may be mixed; CRLF inside quotes is preserved; bare CR is rejected. One terminal delimiter creates no blank row, while additional blank records are returned for domain rejection.
- CSV quotes open only at field start, doubled quotes decode only inside quotes, and only comma, delimiter, or EOF may follow a closing quote.
- `HEADER` is a frozen array exactly `['id','date','amount','currency','category','note']`. `normalizeRows` consumes it, rejects an empty file, accepts header-only input as no records, never trims, preserves data-row order, and leaves duplicate resolution to the Primary.
- Ledger record shape is exactly `{id,date,amount_cents,currency,category,note}` in that key order. Dates and report months use years 0001–9999. Decimal money permits an optional `+` or `-`, has exactly two fractional digits, canonicalizes negative zero to `0`, and must fit safe integer cents.
- All validation failures throw `Error` with an explanatory message; no worker module writes files, exits the process, or uses network/dependencies.
- Existing ledger validation requires a JSON array, reconstructs canonical records, rejects extra/missing keys, invalid types/fields, unsafe cents, and every duplicate ID. Record equality is field-by-field across all six normalized fields.
- `report` validates its month and records, compares sorting keys by JavaScript ordinal `<`/`>`, and rejects any aggregate outside safe integer range.
- Primary integration fully parses and validates both inputs and resolves all conflicts before writing. Only `ENOENT` means absence. Persistence uses a unique exclusive same-directory temporary file, cleanup on error, and rename; an absent header-only import creates `[]`, while an existing no-addition import preserves bytes.
