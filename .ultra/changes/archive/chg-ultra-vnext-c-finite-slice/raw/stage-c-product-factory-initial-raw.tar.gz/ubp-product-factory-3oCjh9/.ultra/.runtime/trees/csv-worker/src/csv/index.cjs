'use strict';

/**
 * Parse CSV without coercing or trimming any field values.
 * @param {string} text
 * @returns {string[][]}
 */
function parseCsv(text) {
  if (typeof text !== 'string') throw new Error('CSV input must be a string');
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);

  const rows = [];
  let row = [];
  let field = '';
  let state = 'field'; // field, quoted, or afterQuote
  let fieldQuoted = false;
  let lastRecordWasBlank = false;
  let lastWasDelimiter = false;

  const finishRecord = () => {
    row.push(field);
    lastRecordWasBlank = row.length === 1 && field === '' && !fieldQuoted;
    rows.push(row);
    row = [];
    field = '';
    state = 'field';
    fieldQuoted = false;
    lastWasDelimiter = true;
  };

  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];

    if (state === 'quoted') {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 1;
        } else {
          state = 'afterQuote';
        }
      } else if (ch === '\r') {
        if (text[i + 1] !== '\n') throw new Error('CSV contains a bare carriage return');
        field += '\r\n';
        i += 1;
      } else {
        field += ch;
      }
      lastWasDelimiter = false;
      continue;
    }

    if (state === 'afterQuote') {
      if (ch === ',') {
        row.push(field);
        field = '';
        fieldQuoted = false;
        state = 'field';
        lastWasDelimiter = false;
      } else if (ch === '\n') {
        finishRecord();
      } else if (ch === '\r' && text[i + 1] === '\n') {
        i += 1;
        finishRecord();
      } else {
        throw new Error('CSV has characters after a closing quote');
      }
      continue;
    }

    // Unquoted field (including a newly started field).
    if (ch === '"') {
      if (field !== '') throw new Error('CSV quote must begin at the start of a field');
      fieldQuoted = true;
      state = 'quoted';
      lastWasDelimiter = false;
    } else if (ch === ',') {
      row.push(field);
      field = '';
      fieldQuoted = false;
      lastWasDelimiter = false;
    } else if (ch === '\n') {
      finishRecord();
    } else if (ch === '\r') {
      if (text[i + 1] !== '\n') throw new Error('CSV contains a bare carriage return');
      i += 1;
      finishRecord();
    } else {
      field += ch;
      lastWasDelimiter = false;
    }
  }

  if (state === 'quoted') throw new Error('CSV has an unclosed quoted field');
  if (state === 'afterQuote') {
    row.push(field);
    lastRecordWasBlank = false;
    rows.push(row);
  } else if (row.length > 0 || field !== '') {
    row.push(field);
    lastRecordWasBlank = false;
    rows.push(row);
  }

  // A single terminal record delimiter does not itself introduce a blank row.
  if (lastWasDelimiter && lastRecordWasBlank) rows.pop();
  return rows;
}

module.exports = { parseCsv };
