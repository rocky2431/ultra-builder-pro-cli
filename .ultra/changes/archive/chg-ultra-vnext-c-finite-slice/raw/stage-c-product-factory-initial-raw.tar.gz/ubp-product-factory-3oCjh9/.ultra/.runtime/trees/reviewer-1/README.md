# Local expense ledger

A dependency-free Node.js CLI that imports bank CSV exports into a local JSON ledger and reports monthly totals. Data stays in local files.

## Requirements

Node.js 18 or newer. The CSV header must be exactly:

```text
id,date,amount,currency,category,note
```

Amounts have exactly two decimal places, dates use `YYYY-MM-DD`, and currencies use three uppercase ASCII letters. CSV quoting supports commas, doubled quotes, and multiline notes.

## Examples

Import records (creating `ledger.json` when absent):

```sh
node cli.cjs import expenses.csv ledger.json
```

Print September 2026 totals, grouped and sorted by currency and category:

```sh
node cli.cjs report ledger.json 2026-09
```

Both commands print JSON to stdout. Invalid input or usage prints an explanation to stderr and exits nonzero. Imports are transactional: conflicts or malformed input leave an existing ledger unchanged.
