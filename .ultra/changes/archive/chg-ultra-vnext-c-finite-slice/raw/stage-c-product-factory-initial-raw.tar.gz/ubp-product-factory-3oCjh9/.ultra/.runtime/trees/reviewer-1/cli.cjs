#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseCsv } = require('./src/csv/index.cjs');
const { normalizeRows, validateLedger, report } = require('./src/domain/index.cjs');

function usage() {
  throw new Error('usage: node cli.cjs import <csv-file> <ledger-file> | node cli.cjs report <ledger-file> <YYYY-MM>');
}

function loadLedger(file, allowAbsent) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    if (allowAbsent && error && error.code === 'ENOENT') return { records: [], absent: true };
    throw new Error(`cannot read ledger: ${error.message}`);
  }
  try {
    return { records: validateLedger(JSON.parse(text)), absent: false };
  } catch (error) {
    throw new Error(`invalid ledger: ${error.message}`);
  }
}

function sameRecord(left, right) {
  return left.id === right.id && left.date === right.date &&
    left.amount_cents === right.amount_cents && left.currency === right.currency &&
    left.category === right.category && left.note === right.note;
}

function persist(file, records) {
  const directory = path.dirname(path.resolve(file));
  const name = path.basename(file);
  let temporary;
  let descriptor;
  for (let attempt = 0; attempt < 10; attempt += 1) {
    temporary = path.join(directory, `.${name}.${process.pid}.${crypto.randomBytes(8).toString('hex')}.tmp`);
    try {
      descriptor = fs.openSync(temporary, 'wx', 0o600);
      break;
    } catch (error) {
      if (!error || error.code !== 'EEXIST' || attempt === 9) throw error;
    }
  }
  try {
    fs.writeFileSync(descriptor, `${JSON.stringify(records, null, 2)}\n`, 'utf8');
    fs.fsyncSync(descriptor);
    fs.closeSync(descriptor);
    descriptor = undefined;
    fs.renameSync(temporary, file);
  } catch (error) {
    if (descriptor !== undefined) {
      try { fs.closeSync(descriptor); } catch {}
    }
    try { fs.unlinkSync(temporary); } catch {}
    throw new Error(`cannot persist ledger: ${error.message}`);
  }
}

function importCsv(csvFile, ledgerFile) {
  let rows;
  try {
    rows = parseCsv(fs.readFileSync(csvFile, 'utf8'));
  } catch (error) {
    throw new Error(`invalid CSV: ${error.message}`);
  }
  let incoming;
  try {
    incoming = normalizeRows(rows);
  } catch (error) {
    throw new Error(`invalid CSV: ${error.message}`);
  }

  const existing = loadLedger(ledgerFile, true);
  const records = existing.records.slice();
  const byId = new Map(records.map(record => [record.id, record]));
  let added = 0;
  let skipped = 0;
  for (const record of incoming) {
    const previous = byId.get(record.id);
    if (previous) {
      if (!sameRecord(previous, record)) throw new Error(`conflicting record id: ${record.id}`);
      skipped += 1;
    } else {
      byId.set(record.id, record);
      records.push(record);
      added += 1;
    }
  }
  if (existing.absent || added > 0) persist(ledgerFile, records);
  return { added, skipped };
}

function main(args) {
  if (args[0] === 'import' && args.length === 3) {
    return importCsv(args[1], args[2]);
  }
  if (args[0] === 'report' && args.length === 3) {
    return report(loadLedger(args[1], false).records, args[2]);
  }
  return usage();
}

try {
  const output = main(process.argv.slice(2));
  process.stdout.write(`${JSON.stringify(output)}\n`);
} catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
