# Expense ledger worker interface

Planning base decomposition (chosen by the Primary):

- **worker-left / CSV seam** owns only `src/csv/`. Implement `src/csv/index.cjs` exporting `parseCsv(text)`. It returns an array of rows, each row an array of decoded string fields. It must accept UTF-8 BOM, LF/CRLF, quoted commas/newlines, and doubled quotes; reject malformed quoting and inconsistent line endings only where CSV syntax is invalid. It does not validate the application header or fields.
- **worker-right / domain seam** owns only `src/domain/`. Implement `src/domain/index.cjs` exporting `HEADER`, `normalizeRows(rows)`, `validateLedger(value)`, and `report(records, month)`. `normalizeRows` requires the exact six-column header, validates each row and returns ledger records. Money conversion is delegated to `require('../money.cjs').cents`; the Primary owns repair of that seeded module. `validateLedger` returns validated normalized ledger records or throws. `report` validates `YYYY-MM`, groups without mixing currencies, and sorts by currency then category.
- **Primary seam** owns `src/money.cjs`, `cli.cjs`, persistence, integration, README, evidence, and commits. The CLI parses CSV with the left module, normalizes and reports with the right module, applies ID duplicate/conflict rules before any write, and persists by same-directory temporary file plus rename.

Shared data contracts:

- Parser output preserves every decoded field byte-for-character as a JavaScript string (apart from BOM removal and CSV quote decoding).
- Ledger record shape is exactly `{id,date,amount_cents,currency,category,note}`.
- All validation failures throw `Error` with an explanatory message; no worker module writes files, exits the process, or uses network/dependencies.
- `normalizeRows` preserves row order and does not resolve duplicate IDs; the Primary does so transactionally.
- Existing ledger validation requires a JSON array and exactly the normalized record keys/types/constraints, including safe integer cents and real dates.
