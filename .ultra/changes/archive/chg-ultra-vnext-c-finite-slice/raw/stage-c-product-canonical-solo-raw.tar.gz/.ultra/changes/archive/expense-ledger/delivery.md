# Delivery: expense-ledger

## Outcome Reconciliation
The accepted local-only importer and monthly reporter are implemented at `GOAL.md#local-expense-ledger` through the two public seams in `.ultra/changes/active/expense-ledger/intent.md#public-seams`. Exact money, strict CSV/ledger validation, duplicate conflict handling, byte-preserving failures, atomic same-directory rename, currency-separated totals, CLI errors, and runnable documentation are observed in `.ultra/test-report.json#verified_seams` and `.ultra/evidence/expense-ledger/acceptance-after.txt`.

## Specification and Documentation Updates
`.ultra/specs/architecture.md#architecture` records the implemented CLI, ledger, money, and persistence boundaries. `README.md#local-expense-ledger` documents two runnable commands and check commands. The behavioral specification remains unchanged because implementation realizes, rather than reduces, `GOAL.md#local-expense-ledger`. Version impact is none: this synthetic repository has no package manifest, version, or release package, and the owner prohibited a version bump.

## Verification
| Command | Exit | Evidence | Freshness |
|---|---:|---|---|
| `node acceptance.cjs` | 0 | `.ultra/evidence/expense-ledger/aggregate-acceptance.txt` | HEAD `34aff0fe4fa8835b3b41e22bd174e9adc6b9a416`, product digest `27b755554ee3a48846a644c01c8fdea8c7f5dc533485a9fb2a75b1b47793144f` |
| `node test/focused.cjs` | 0 | `.ultra/evidence/expense-ledger/aggregate-focused.txt` | same aggregate snapshot |
| Node syntax checks | 0 | `.ultra/evidence/expense-ledger/syntax-check.txt` | same aggregate snapshot |
| 1000-row local import probe | 0 | `.ultra/evidence/expense-ledger/performance-check.txt` | same aggregate snapshot |
| Task Evidence, strict Review transport, subject and hash consumers | 0 | `.ultra/evidence/expense-ledger/deliver-validation.txt` | pre-finalization snapshot |

## Review
Independent task Review is the reviewer-originated `.ultra/evidence/expense-ledger/external-review.json`, verdict `approve`, with no P0/P1 and one P2. Aggregate Review is `.ultra/reviews/aggregate-expense-01a085a2/SUMMARY.json`, packet digest `72eea6983dcd12e572578da4762e6bd2c185111c57b488f07b5c379e289368b3`, verdict `APPROVE`, execution mode `sequential-shared-context`. Its unresolved non-blocker is `review-tests-001`; findings are preserved unchanged in `.ultra/test-report.json#findings`.

## Technical Debt
- P2 `review-tests-001`: the focused malformed-currency assertion is preempted by invalid CSV, reducing regression localization. Owner: future owner-selected test Change. Upgrade path: restore valid CSV before the malformed-ledger import and observe the assertion red/green against the validation branch.
- `parseCsv` is exported but has no non-test consumer. Owner: future owner-selected cleanup. Upgrade path: remove the unnecessary export or explicitly establish a supported caller, followed by fresh review/Test. This prevents release-package creation; no package is authorized or created here.

## Residual Risks and Omissions
Independent QA was source-only because its read-only envelope denied command effects. The Primary's unchanged acceptance and focused checks are retained separately. No dependency audit applies because there is no package manifest or third-party dependency. The original seeded failure, denied first review attempt, receipt-incomplete second attempt, focused capture race, and initial strict transport copy mismatch remain visible under `.ultra/evidence/expense-ledger/`; none is rewritten as passing evidence. No owner risk-acceptance decision was invented for the P2 or orphan candidate.

## Recovery
Use ordinary Git history to revert the local completion and implementation commits, then rerun `node acceptance.cjs` to verify restoration. Existing user ledger files are outside this repository and are not modified by rollback. Import-time failures preserve ledger bytes by the validated-before-rename path in `src/ledger.cjs#L117-L136`.

## External Effects
Local implementation commits `9ac697494e791221386a325821fc3466844b4df6` and `34aff0fe4fa8835b3b41e22bd174e9adc6b9a416` were authorized and observed. One final local completion commit is authorized and is intentionally performed only after this delivery metadata is archived and the precommit snapshot is retained. Push, tag, package creation/publication, deployment, network access, and version bump were not authorized and were not attempted.
