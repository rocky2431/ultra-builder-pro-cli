# Task expense-ledger: Implement and deliver the expense ledger

## Context
GOAL.md is the accepted scope. The native Primary chooses architecture and, when selected, disjoint Worker responsibilities. Preserve fixed inputs and provenance.

## Change Acceptance IDs
AC-01, AC-02, AC-03, AC-04.

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| T-01 | Fixed goal behavior passes unchanged acceptance on integrated source. | command | Current CLI output, exit status and raw evidence. |
| T-02 | Final source has independent read-only Pi disposition with no unresolved blockers. | external-observation | Actual native reviewer and exact reviewer-originated receipt. |
| T-03 | Dependency-free source, error paths and runnable documentation realize the goal. | inspection | Source and README inspection, bounded limitations. |

## Implementation
Use `cli.cjs` as the sole public entry point. It delegates strict CSV parsing and record normalization to `src/ledger.cjs`, exact decimal conversion to `src/money.cjs`, and performs report aggregation through the same validated ledger boundary. Imports validate the complete existing ledger and complete CSV batch before a same-directory temporary-file rename. `test/focused.cjs` exercises the public CLI with real temporary files, including error paths not covered by the owner suite. This keeps the implementation dependency-free and provides one CLI-to-filesystem vertical seam.

## Trace
FP-1 and FP-2 support NS-1 under HC-1; source is GOAL.md and .ultra/specs/product.md.

## Completion
Completed on source commit `34aff0fe4fa8835b3b41e22bd174e9adc6b9a416`. Unchanged `node acceptance.cjs` exited 0 with 8/8 and `node test/focused.cjs` exited 0 with 9/9. Task Evidence v2 is `.ultra/evidence/expense-ledger/evidence.json` (SHA-256 `584c529021e30e00d6aa4d17a78118d3a29087549c5e47390cd8dd497428c165`). The original seeded failure remains in `probe/baseline.json`; the later focused-capture race is retained separately and did not execute the test.

## Task Review
Final external-manual Pi review is `.ultra/evidence/expense-ledger/external-review.json` (SHA-256 `07e7c89bb96e2b6684866bb77e859a5f911e40f68c437bfabc25ab58aa932825`), reviewer `Pi openai-codex/gpt-6-astra`, verdict `approve`, exact subject HEAD `34aff0fe4fa8835b3b41e22bd174e9adc6b9a416` and product digest `f41e4a4d4cf1e013e01b8d946784ca603737bdca7c06165171478818477372a4`. Repair iteration 1 reproduced and fixed the P1 non-string currency coercion and unsupported positive-sign restriction before this affected delta review. P2 `R1` remains: the focused malformed-currency assertion is preempted by invalid CSV and does not exercise that branch. It is non-blocking and was not auto-repaired. QA could not execute commands under read-only permissions. Earlier denied and receipt-incomplete attempts are retained as historical results.

## Resume Note
Task implementation and canonical v2 evidence are complete; the ledger row is completed. Continue with whole-Change Test, one sequential-shared-context aggregate Review, and authorized Deliver finalization. Do not reopen the task for retained P2 `R1` without owner selection.
