# Task expense-ledger: Implement and deliver the expense ledger

## Context
GOAL.md is the accepted scope. The native Primary chooses architecture and, when selected, disjoint Worker responsibilities. Preserve fixed inputs and provenance.

## Change Acceptance IDs
AC-01, AC-02, AC-03, AC-04.

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| T-01 | Fixed goal behavior passes unchanged acceptance on integrated source. | command | Current CLI output, exit status and raw evidence. |
| T-02 | Final source has independent read-only Pi disposition with no unresolved blockers. | external-observation | Actual native reviewer and exact reviewer-originated receipt. |
| T-03 | Dependency-free source, error paths and runnable documentation realize the goal. | inspection | Source and README inspection, bounded limitations. |

## Implementation
Use `cli.cjs` as the sole public entry point. It delegates strict CSV parsing and record normalization to `src/ledger.cjs`, exact decimal conversion to `src/money.cjs`, and performs report aggregation through the same validated ledger boundary. Imports validate the complete existing ledger and complete CSV batch before a same-directory temporary-file rename. `test/focused.cjs` exercises the public CLI with real temporary files, including error paths not covered by the owner suite. This keeps the implementation dependency-free and provides one CLI-to-filesystem vertical seam.

## Trace
FP-1 and FP-2 support NS-1 under HC-1; source is GOAL.md and .ultra/specs/product.md.

## Completion
Not completed.

## Task Review
Not run. The external-manual branch may use immutable GOAL.md and .ultra/decisions/experiment.md bindings; the actual reviewer must originate its receipt.

## Resume Note
Current task is in progress under the current explicit prompt. Begin implementation from the seeded baseline and preserve its observed failure.
