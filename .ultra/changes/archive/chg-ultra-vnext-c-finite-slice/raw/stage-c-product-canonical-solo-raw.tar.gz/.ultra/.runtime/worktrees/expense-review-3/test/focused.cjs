'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-focused-'));
const run = (...args) => spawnSync(process.execPath, ['cli.cjs', ...args], { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' });
try {
  const ledger = path.join(root, 'ledger.json');
  const csv = path.join(root, 'input.csv');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,0001-01-01,+1.00,USD,Misc,ok\n');
  assert.deepEqual(JSON.parse(run('import', csv, ledger).stdout), { added: 1, skipped: 0 });
  const before = fs.readFileSync(ledger);
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\ny,1900-02-29,1.00,USD,Misc,bad date\n');
  assert.notEqual(run('import', csv, ledger).status, 0);
  assert.deepEqual(fs.readFileSync(ledger), before);

  const malformed = path.join(root, 'malformed.json');
  fs.writeFileSync(malformed, JSON.stringify([{ id: 'z', date: '2026-01-01', amount_cents: 1, currency: ['USD'], category: 'X', note: '' }]));
  const malformedBefore = fs.readFileSync(malformed);
  assert.notEqual(run('import', csv, malformed).status, 0, 'non-string currency must fail');
  assert.deepEqual(fs.readFileSync(malformed), malformedBefore);

  const exactTotal = path.join(root, 'exact-total.json');
  fs.writeFileSync(exactTotal, JSON.stringify([
    { id: 'a', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'X', note: '' },
    { id: 'b', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'X', note: '' },
    { id: 'c', date: '2026-01-03', amount_cents: -1, currency: 'USD', category: 'X', note: '' }
  ]));
  assert.equal(JSON.parse(run('report', exactTotal, '2026-01').stdout)[0].total_cents, Number.MAX_SAFE_INTEGER);
  console.log(JSON.stringify({ passed: 9, total: 9 }));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
