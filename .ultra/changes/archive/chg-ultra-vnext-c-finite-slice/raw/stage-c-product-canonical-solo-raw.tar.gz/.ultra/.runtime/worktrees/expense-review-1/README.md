# Local expense ledger

Dependency-free Node CLI for importing bank CSV exports into a local JSON ledger and reporting monthly totals. Data stays on the local filesystem.

```sh
node cli.cjs import ./expenses.csv ./ledger.json
node cli.cjs report ./ledger.json 2026-09
```

The import command prints `{ "added", "skipped" }`; the report command prints totals grouped by currency and category. Input and ledger errors are written to stderr and exit nonzero without replacing an existing ledger.

Run checks with:

```sh
node acceptance.cjs
node test/focused.cjs
```
