'use strict';

function cents(value) {
  if (typeof value !== 'string' || !/^-?\d+\.\d{2}$/.test(value)) {
    throw new Error(`invalid amount: ${JSON.stringify(value)}`);
  }
  const negative = value[0] === '-';
  const unsigned = negative ? value.slice(1) : value;
  const [whole, fraction] = unsigned.split('.');
  const magnitude = BigInt(whole) * 100n + BigInt(fraction);
  const signed = negative ? -magnitude : magnitude;
  if (signed > BigInt(Number.MAX_SAFE_INTEGER) || signed < BigInt(Number.MIN_SAFE_INTEGER)) {
    throw new Error(`unsafe amount: ${value}`);
  }
  return Number(signed);
}

exports.cents = cents;
