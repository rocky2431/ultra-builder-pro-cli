'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-focused-'));
const run = (...args) => spawnSync(process.execPath, ['cli.cjs', ...args], { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' });
try {
  const ledger = path.join(root, 'ledger.json');
  const csv = path.join(root, 'input.csv');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,2000-02-29,+1.00,USD,Misc,bad sign\n');
  const bad = run('import', csv, ledger);
  assert.notEqual(bad.status, 0, 'a leading plus must be rejected');
  assert.equal(fs.existsSync(ledger), false, 'failed import must not create a ledger');

  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,0001-01-01,1.00,USD,Misc,ok\n');
  assert.deepEqual(JSON.parse(run('import', csv, ledger).stdout), { added: 1, skipped: 0 });
  const before = fs.readFileSync(ledger);
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\ny,1900-02-29,1.00,USD,Misc,bad date\n');
  assert.notEqual(run('import', csv, ledger).status, 0);
  assert.deepEqual(fs.readFileSync(ledger), before);

  const unsafeLedger = path.join(root, 'unsafe-total.json');
  fs.writeFileSync(unsafeLedger, JSON.stringify([
    { id: 'a', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'X', note: '' },
    { id: 'b', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'X', note: '' }
  ]));
  assert.notEqual(run('report', unsafeLedger, '2026-01').status, 0, 'unsafe aggregate must fail');
  console.log(JSON.stringify({ passed: 7, total: 7 }));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
