'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { cents } = require('./money.cjs');

const HEADER = ['id', 'date', 'amount', 'currency', 'category', 'note'];
const RECORD_KEYS = ['id', 'date', 'amount_cents', 'currency', 'category', 'note'];

function parseCsv(input) {
  if (typeof input !== 'string') throw new Error('CSV must be text');
  if (input.startsWith('\uFEFF')) input = input.slice(1);
  const rows = [];
  let row = [], field = '', quoted = false, closed = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (quoted) {
      if (ch === '"') {
        if (input[i + 1] === '"') { field += '"'; i++; }
        else { quoted = false; closed = true; }
      } else field += ch;
      continue;
    }
    if (closed && ch !== ',' && ch !== '\r' && ch !== '\n') throw new Error('malformed CSV: text after closing quote');
    if (ch === '"') {
      if (field !== '' || closed) throw new Error('malformed CSV: unexpected quote');
      quoted = true;
    } else if (ch === ',') {
      row.push(field); field = ''; closed = false;
    } else if (ch === '\n' || ch === '\r') {
      if (ch === '\r') {
        if (input[i + 1] !== '\n') throw new Error('malformed CSV: bare carriage return');
        i++;
      }
      row.push(field); rows.push(row); row = []; field = ''; closed = false;
    } else {
      field += ch;
    }
  }
  if (quoted) throw new Error('malformed CSV: unclosed quote');
  if (field !== '' || row.length > 0 || closed) { row.push(field); rows.push(row); }
  return rows;
}

function validDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1 || month < 1 || month > 12) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day >= 1 && day <= days[month - 1];
}

function normalizeCsvRow(row, line) {
  if (row.length !== 6) throw new Error(`CSV row ${line} must have exactly 6 columns`);
  const [id, date, amount, currency, category, note] = row;
  if (!id) throw new Error(`CSV row ${line}: id must be nonempty`);
  if (!validDate(date)) throw new Error(`CSV row ${line}: invalid date ${JSON.stringify(date)}`);
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error(`CSV row ${line}: invalid currency ${JSON.stringify(currency)}`);
  if (!category) throw new Error(`CSV row ${line}: category must be nonempty`);
  return { id, date, amount_cents: cents(amount), currency, category, note };
}

function parseImport(input) {
  const rows = parseCsv(input);
  if (rows.length === 0 || rows[0].length !== HEADER.length || !rows[0].every((v, i) => v === HEADER[i])) {
    throw new Error(`CSV header must be exactly ${HEADER.join(',')}`);
  }
  return rows.slice(1).map((row, i) => normalizeCsvRow(row, i + 2));
}

function validateRecord(record, index) {
  if (!record || typeof record !== 'object' || Array.isArray(record) || Object.keys(record).length !== RECORD_KEYS.length || !RECORD_KEYS.every(k => Object.hasOwn(record, k))) {
    throw new Error(`invalid ledger record at index ${index}`);
  }
  if (typeof record.id !== 'string' || !record.id || typeof record.category !== 'string' || !record.category || typeof record.note !== 'string' || !validDate(record.date) || typeof record.currency !== 'string' || !/^[A-Z]{3}$/.test(record.currency) || !Number.isSafeInteger(record.amount_cents)) {
    throw new Error(`invalid ledger fields at index ${index}`);
  }
  return { id: record.id, date: record.date, amount_cents: record.amount_cents, currency: record.currency, category: record.category, note: record.note };
}

function same(a, b) { return RECORD_KEYS.every(key => a[key] === b[key]); }

function readLedger(file, allowAbsent = false) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); }
  catch (error) {
    if (allowAbsent && error.code === 'ENOENT') return [];
    throw new Error(`cannot read ledger: ${error.message}`);
  }
  let value;
  try { value = JSON.parse(text); } catch (error) { throw new Error(`malformed ledger JSON: ${error.message}`); }
  if (!Array.isArray(value)) throw new Error('ledger must be a JSON array');
  const records = value.map(validateRecord);
  const ids = new Map();
  for (const record of records) {
    const prior = ids.get(record.id);
    if (prior && !same(prior, record)) throw new Error(`ledger contains conflicting id ${record.id}`);
    if (prior) throw new Error(`ledger contains duplicate id ${record.id}`);
    ids.set(record.id, record);
  }
  return records;
}

function persist(file, records) {
  const dir = path.dirname(path.resolve(file));
  const temp = path.join(dir, `.${path.basename(file)}.${process.pid}.${Date.now()}.${Math.random().toString(16).slice(2)}.tmp`);
  try {
    fs.writeFileSync(temp, JSON.stringify(records, null, 2) + '\n', { flag: 'wx' });
    fs.renameSync(temp, file);
  } catch (error) {
    try { fs.unlinkSync(temp); } catch (_) {}
    throw new Error(`cannot persist ledger: ${error.message}`);
  }
}

function importCsv(csvFile, ledgerFile) {
  let input;
  try { input = fs.readFileSync(csvFile, 'utf8'); } catch (error) { throw new Error(`cannot read CSV: ${error.message}`); }
  const incoming = parseImport(input);
  const existing = readLedger(ledgerFile, true);
  const byId = new Map(existing.map(record => [record.id, record]));
  const additions = [];
  let skipped = 0;
  for (const record of incoming) {
    const prior = byId.get(record.id);
    if (prior) {
      if (!same(prior, record)) throw new Error(`conflicting repeated id ${record.id}`);
      skipped++;
    } else {
      byId.set(record.id, record);
      additions.push(record);
    }
  }
  persist(ledgerFile, existing.concat(additions));
  return { added: additions.length, skipped };
}

function report(ledgerFile, month) {
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) throw new Error(`invalid report month: ${month}`);
  const totals = new Map();
  for (const record of readLedger(ledgerFile)) {
    if (!record.date.startsWith(month + '-')) continue;
    const key = `${record.currency}\0${record.category}`;
    const prior = totals.get(key) || { currency: record.currency, category: record.category, total: 0n, count: 0 };
    prior.total += BigInt(record.amount_cents); prior.count++; totals.set(key, prior);
  }
  return [...totals.values()].map(item => {
    if (item.total > BigInt(Number.MAX_SAFE_INTEGER) || item.total < BigInt(Number.MIN_SAFE_INTEGER)) throw new Error(`unsafe report total for ${item.currency}/${item.category}`);
    return { currency: item.currency, category: item.category, total_cents: Number(item.total), count: item.count };
  }).sort((a, b) => a.currency < b.currency ? -1 : a.currency > b.currency ? 1 : a.category < b.category ? -1 : a.category > b.category ? 1 : 0);
}

exports.importCsv = importCsv;
exports.report = report;
exports.parseCsv = parseCsv;
