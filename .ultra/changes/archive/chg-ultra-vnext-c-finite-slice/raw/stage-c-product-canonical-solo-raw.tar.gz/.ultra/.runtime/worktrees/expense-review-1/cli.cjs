#!/usr/bin/env node
'use strict';

const { importCsv, report } = require('./src/ledger.cjs');

function usage() {
  return 'Usage: node cli.cjs import <csv-file> <ledger-file>\n       node cli.cjs report <ledger-file> <YYYY-MM>';
}

try {
  const args = process.argv.slice(2);
  let result;
  if (args[0] === 'import' && args.length === 3) result = importCsv(args[1], args[2]);
  else if (args[0] === 'report' && args.length === 3) result = report(args[1], args[2]);
  else throw new Error(usage());
  process.stdout.write(JSON.stringify(result) + '\n');
} catch (error) {
  process.stderr.write(`Error: ${error.message}\n`);
  process.exitCode = 1;
}
