# Architecture

The public seams are the two Node CLI commands in GOAL.md and the JSON ledger. `cli.cjs` owns argument handling and error presentation; `src/ledger.cjs` owns strict CSV parsing, record and ledger validation, duplicate semantics, monthly grouping, and same-directory temporary-file rename; `src/money.cjs` converts signed two-decimal text to safe integer cents without floating point. The implementation uses only Node standard library modules. Import validation completes before persistence, and focused tests cross the CLI boundary using real temporary files.
