# Domain Context

- **CSV record**: one normalized six-column import row from the fixed header.
- **Ledger record**: `{id,date,amount_cents,currency,category,note}` with explicit field types and validated values.
- **Identical repeated ID**: the same id with equal normalized ledger-record content; skipped.
- **Conflicting repeated ID**: the same id with different normalized content; rejects the whole import.
- **Monthly total**: safe integer cents and count grouped by one currency/category pair for one `YYYY-MM` calendar month.
