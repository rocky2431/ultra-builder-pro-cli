# Architecture Specification

## Local process and file boundary

`cli.cjs` is the public process entry point and uses only Node built-ins plus `src/money.cjs`. Import parses and normalizes all CSV and validates the complete existing ledger before writing. Persistence creates a same-directory temporary file and renames it. Report validates ledger records and aggregates safe integer cents by currency/category. There is no network, database, service, package dependency, or release artifact.
