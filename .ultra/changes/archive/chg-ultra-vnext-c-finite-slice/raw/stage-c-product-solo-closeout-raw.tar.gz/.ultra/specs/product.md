# Product Specification

## Local expense ledger

The accepted behavior is fixed by `GOAL.md`: a dependency-free Node CLI imports the exact bank CSV shape into a validated local JSON-array ledger and reports calendar-month totals grouped without mixing currency. Invalid CSV, fields, dates, amounts, months, ledger shape, and conflicting IDs fail clearly. Failed imports preserve existing ledger bytes; successful persistence uses same-directory temporary-file rename. `acceptance.cjs` and the owner supplementary checker are executable acceptance sources.
