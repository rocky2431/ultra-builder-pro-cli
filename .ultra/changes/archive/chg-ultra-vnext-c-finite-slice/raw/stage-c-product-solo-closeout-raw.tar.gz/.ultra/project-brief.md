# Project Brief

> **Authority**: raw owner intake captured during canonical brownfield adoption after the initial product treatment. This does not backdate Ultra evidence.

## One-line

Build a dependency-free Node CLI for a small team importing bank CSV exports into a local JSON ledger and printing monthly totals.

## Initial Outline

- What it is: a local expense-ledger command-line tool.
- Broadly for whom or what: a small team using synthetic bank exports.
- Intended result: safe CSV import and currency-separated monthly totals.
- Broad boundary: local files only; no network, accounts, database, or UI.

## Explicit Inputs

- `GOAL.md` is the fixed accepted experiment intent and remains unchanged.
- `acceptance.cjs` is owner-supplied read-only acceptance.
- Preserve the seeded baseline, original treatment outputs, and later `probe/supplement.json` finding.
- Local sample only: no dependency, version bump, publication, or external product effect.

## Open Questions for Research

- None; the owner explicitly supplied the complete business boundary for this experiment.
