# Decision: canonical adoption of the expense-ledger goal

> **Status**: accepted
> **Decision identity**: `canonical-adoption`
> **Acceptance time**: `not-recorded`

## Owner Record

- Conversation scope: the explicit bounded canonical closeout experiment, after the original implementation treatment ended.
- Exact raw owner acceptance: “The fixed GOAL.md is the accepted experiment intent.”
- Agency boundary: the owner owns GOAL.md, the closeout boundary, repair ceiling, external reviewer selection, local-only version posture, and finalization authorization; the Primary owns canonical projection and implementation semantics within that frame.
- Time boundary: adoption occurs now during closeout; no prior task status or canonical evidence is backdated.
- Revision boundary: this decision accepts only the semantic projection of the unchanged GOAL.md into `expense-ledger-r1`; future revisions do not inherit acceptance.

## Accepted Artifact Binding

- North Star content SHA-256: `2c0cf7681a3bcf1cdc705f1d3956dabea2297e7d3253829376cd80ace218154f`
- North Star Git blob digest: `4899a5b3073e0c11b264ff8d30a899ed350d4a80`
- Accepted snapshot: `.ultra/research/canonical-adoption/expense-ledger-r1.accepted.md`

## Closeout authority

The owner explicitly authorizes canonical Init/Change/Plan/Review/Test/Deliver reconciliation and local Deliver finalization when evidence conditions are met. Pi is the owner-designated read-only external reviewer. The package posture is a local sample with no version bump or publication.
