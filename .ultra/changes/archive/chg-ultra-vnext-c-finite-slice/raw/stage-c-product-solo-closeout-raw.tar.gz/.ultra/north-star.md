# Project North Star

## Acceptance and Revision

- Schema: `north-star-v2`
- Status: `accepted`
- Revision: `expense-ledger-r1`
- Owner acceptance source: `.ultra/decisions/canonical-adoption.md#owner-record`
- Acceptance time: `not-recorded`
- Supersedes: `none`

## Problem Reality

- Reality: A small team needs deterministic local ingestion of synthetic bank CSV exports and monthly expense totals.
- Evidence: `GOAL.md` is the fixed owner-supplied experiment intent; `acceptance.cjs` and `probe/supplement.json` preserve executable observations.
- Unknowns: Concurrent writers and crash-durability beyond atomic rename are outside the accepted scope.

## First-Principle Propositions

### FP-1 — Preserve exact local financial meaning
- Proposition: Valid local records must retain exact cents and text while malformed or conflicting input must not alter an existing ledger.
- Evidence: `GOAL.md`; owner-supplied acceptance and supplement.
- Causal consequence: Parsing, validation, duplicate handling, and persistence must be deterministic and failure-atomic.
- Falsifier or revisit trigger: A supported input changes value or a rejected import changes existing ledger bytes.
- Status: `accepted`

## Value Causal Chain

| Chain | Principle | Capability | Observable behavior | Outcome |
|---|---|---|---|---|
| VC-1 | FP-1 | Strict local import and grouped report | Commands return exact JSON or clear failure without corrupting the ledger | NS-1 |

## North Star Outcomes

### NS-1 — Trustworthy local ledger workflow
- Outcome: The documented dependency-free CLI correctly imports accepted CSV and reports separated monthly totals.
- Observation method: Run unchanged `acceptance.cjs`, the owner supplement, and focused regression checks.
- Baseline: The seeded cents defect and absent CLI produced 1/8 owner acceptance checks passing.
- Target or expected change: All owner acceptance and supplement checks pass on the final reviewed revision.
- Horizon: This isolated local sample closeout.
- Anti-metric: A green counter does not override malformed-ledger preservation or independent review findings.

## Hard Constraints

### HC-1 — Local-only bounded effects
- Protected value or threat: Owner files, credentials, installed tools, and external systems.
- Constraint: No dependencies, network product behavior, publication, credential changes, or edits outside this sample; fixed owner fixtures remain unchanged.
- Authority or evidence: `GOAL.md` and the explicit canonical closeout instruction.
- Revisit condition: A future owner-authorized work package changes the product boundary.

## Explicit Exclusions

- Accounts, database, UI, network product behavior, publication, and concurrency control.

## Uncertainties and Revisit Triggers

- Revisit persistence if crash durability beyond same-directory temporary-file rename becomes required.
- Revisit coordination if multiple processes must import concurrently.

## Research Trace

- Project Brief: `.ultra/project-brief.md`
- Research runs: canonical brownfield adoption after initial implementation; no exploratory research was required by the owner.
- Sources and decisions: `GOAL.md`, `acceptance.cjs`, `probe/baseline.json`, `probe/supplement.json`, `.ultra/decisions/canonical-adoption.md`.
