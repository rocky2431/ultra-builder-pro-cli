# Task expense-ledger: Deliver and close the local ledger CLI

## Change Acceptance IDs
A-01, A-02, A-03, A-04

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| T-01 | Unchanged owner acceptance passes. | command | Exact stdout/stderr and exit status from `node acceptance.cjs`. |
| T-02 | Unchanged supplement and focused date-type regression pass without changing malformed ledger bytes. | command | Exact checker outputs and exit statuses. |
| T-03 | Final subject is approved by owner-designated read-only Pi with no P0/P1 findings. | external-observation | Reviewer-originated receipt with exact HEAD/worktree binding. |
| T-04 | README documents both commands and implementation has no dependencies or network. | inspection | Revision-bound source/document inspection. |

## Confirmed Seams
- Node process boundary at `cli.cjs` for import and report.
- Existing JSON ledger byte boundary on import failure.
- Stdout/stderr and process exit status.

## Layers Touched
- CLI parsing, validation, persistence, reporting, focused tests, and documentation.

## Target Files
- `cli.cjs`
- `src/money.cjs`
- `README.md`
- `test/date-type.cjs`

## Implementation
Adopt the already implemented dependency-free CLI, preserve original evidence, and add only `typeof value === 'string'` before date regex matching so malformed ledger arrays cannot pass coercively.

## Verification Commands
- `node acceptance.cjs`
- `node test/date-type.cjs`
- `node /Users/rocky243/Context Engineering/ultra-builder-pro-cli/work/trellis-eight-step-20260909/stage-c-product-supplement.cjs "$PWD"`

## Hard Constraints
- HC-1: keep owner fixtures immutable; use no dependency/network/publication; Primary alone writes source and canonical records.

## Trace
- FP-1: strict types and atomic failure preserve exact ledger meaning.
- NS-1: complete real CLI flow is executable at the process/file seam.
- HC-1: local-only constrained effects.

## Definition of Drift
Any source change after final independent review, changed acceptance bytes, failed command, receipt/evidence digest mismatch, or changed accepted North Star/intent invalidates closeout evidence.

## Change Log
- 2026-09-09: Canonically adopted after the original implementation treatment; no earlier Ultra completion or review is claimed.
- 2026-09-09: Reproduced owner supplement failure and used Solo repair iteration 1 to add explicit date string validation.

## Completion
The unchanged acceptance suite passed 8/8, the unchanged supplement passed 3/3, and the focused date-type regression passed after Solo repair iteration 1. Canonical completion remains conditional on the final exact-subject receipt and v2 evidence validation.

## Task Review
Owner-designated read-only Pi `openai-codex/gpt-6-astra`, native session `0199448d-43a3-7b60-8d8b-7a2f5c241a60`, approved the repaired source with one P2 exact-format finding (`ledger-review-001`). The final receipt must bind the post-adoption subject and preserve that finding. The original self-review remains historical and is not independent review evidence.

## Resume Note
Implementation and all command checks are green. Publish only a reviewer-originated receipt for the exact final task subject, carry P2 `ledger-review-001` as residual debt without unauthorized source repair, validate v2 evidence, then move the ledger row to `completed`.
