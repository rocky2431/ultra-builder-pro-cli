# Change expense-ledger: Adopt and close the local expense ledger

> **Status**: accepted
> **Profile**: standard
> **Profile rationale**: One small local CLI and ledger file boundary, with ordinary parsing and persistence correctness risk.
> **Risk flags**: local data integrity

## Outcome
A small team can import the specified CSV into a failure-safe local JSON ledger and print exact currency-separated monthly totals through the documented Node CLI.

## Acceptance
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| A-01 | The unchanged owner acceptance suite passes on the final implementation revision. | command | Raw `node acceptance.cjs` output and exit status bound to the final subject. |
| A-02 | The unchanged supplementary checker passes, including rejection and byte preservation for non-string ledger dates. | command | Raw operator checker output and exit status bound to the final subject. |
| A-03 | The final exact subject receives an approving read-only independent Pi review with no P0/P1 findings. | external-observation | Reviewer-originated external review receipt bound to current Git HEAD and worktree digest. |
| A-04 | CLI documentation contains runnable import and report examples and the product uses no dependencies or network. | inspection | Revision-bound inspection of `README.md`, `cli.cjs`, and repository manifests. |

## Non-goals
- Network, accounts, database, UI, concurrent writer locking, publication, version bump, or changes to owner fixtures and Ultra itself.

## Public Seams
- `node cli.cjs import <csv-file> <ledger-file>` JSON stdout, stderr, exit status, and ledger bytes.
- `node cli.cjs report <ledger-file> <YYYY-MM>` JSON stdout, stderr, and exit status.

## Reconciliation
### Promised and Missing
- Before the closeout repair, existing-ledger date validation permitted array-to-string regex coercion; the owner-authorized focused repair adds an explicit type check.

### Built and Unpromised
- None.

### Contradictory
- The earlier `DELIVERY.json` claimed readiness from 8/8 acceptance plus self-review; `probe/supplement.json` proves that evidence was insufficient. It remains historical and is superseded only by canonical closeout records.

## Research Disposition
- Disposition: none
- Question: none
- Selected lenses: none
- Existing evidence: `GOAL.md`, `acceptance.cjs`, `probe/baseline.json`, `probe/supplement.json`, implementation history, and the explicit closeout instruction fully define the bounded behavior.
- Required exit evidence: none beyond the acceptance, independent review, Test, and Deliver evidence in this Change.
- Rationale: No product or architecture choice is open; this is explicit post-treatment brownfield adoption and closeout.

## North Star Trace
- First principles: FP-1; strict validation and failure-atomic persistence preserve exact local financial meaning.
- Serves: NS-1; the CLI provides the accepted trustworthy local workflow.
- Touches: HC-1; all work remains dependency-free, local, and within fixed fixtures/effect boundaries.
- Evidence: `GOAL.md`, `acceptance.cjs`, and `probe/supplement.json` define and exercise the causal claims.
- North Star revision: expense-ledger-r1
- North Star digest: 4899a5b3073e0c11b264ff8d30a899ed350d4a80
- Contradictions or refinements: none; the owner explicitly accepted GOAL.md and authorized this repair and canonical closeout.

## Execution Grant

- Grant: `session-local`
- Allowed workflows: plan, dev, test, deliver-reconcile
- Agent topology: Primary is sole writer; owner-designated qualified Pi is read-only independent reviewer.
- Allowed local effects: canonical sample records, one focused Solo validation repair, local tests, read-only Pi QA, and local commits.
- Budgets and expiry: separate 20-minute closeout wall budget; one of Solo's previously unused repair iterations; one final exact-subject Pi QA; current foreground turn only.
- Mandatory reviews: final exact-subject independent task review and current aggregate Change review consumed by Test and Deliver.
- Stop conditions: P0/P1 after final delta/QA, evidence or validator mismatch, source-repair ceiling, or wall budget.
- Invalidation: product-source changes after independent review, stale evidence bindings, or end of this foreground continuation.
- Never granted: edits outside this sample, Ultra/tool/credential changes, publication, deployment, version bump, or additional sample source repair.
- Activation: the current explicit bounded canonical closeout instruction activates this grant and finalization mode.

## Planning Posture
SELECTIVE — adopt one existing end-to-end product task and repair only the evidenced date-type validation gap; owner confirmed this exact bounded closeout.

## Recovery
Use Git to revert the focused source repair or the canonical closeout commit; verify with unchanged acceptance and supplementary checks. Failed imports preserve ledger bytes.

## Unresolved Decisions
- none; owner acceptance remains separate from local delivery finalization.
