'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-date-type-'));
try {
  const ledger = path.join(root, 'ledger.json');
  const csv = path.join(root, 'new.csv');
  const malformed = '[{"id":"old","date":["2026-09-01"],"amount_cents":100,"currency":"USD","category":"Misc","note":"bad type"}]';
  fs.writeFileSync(ledger, malformed);
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nnew,2026-09-02,1.00,USD,Misc,new\n');
  const result = spawnSync(process.execPath, ['cli.cjs', 'import', csv, ledger], { cwd: path.resolve(__dirname, '..'), encoding: 'utf8' });
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /invalid date/);
  assert.equal(fs.readFileSync(ledger, 'utf8'), malformed);
  console.log(JSON.stringify({ check: 'malformed-existing-date-type-preserves-bytes', passed: true }));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
