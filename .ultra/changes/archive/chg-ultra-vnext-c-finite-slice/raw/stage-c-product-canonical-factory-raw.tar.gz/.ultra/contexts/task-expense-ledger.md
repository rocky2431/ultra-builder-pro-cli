# Task expense-ledger: Implement and deliver the expense ledger

## Context
GOAL.md is the accepted scope. The native Primary chooses architecture and, when selected, disjoint Worker responsibilities. Preserve fixed inputs and provenance.

## Change Acceptance IDs
AC-01, AC-02, AC-03, AC-04.

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| T-01 | Fixed goal behavior passes unchanged acceptance on integrated source. | command | Current CLI output, exit status and raw evidence. |
| T-02 | Final source has independent read-only Pi disposition with no unresolved blockers. | external-observation | Actual native reviewer and exact reviewer-originated receipt. |
| T-03 | Dependency-free source, error paths and runnable documentation realize the goal. | inspection | Source and README inspection, bounded limitations. |

## Implementation
Use the shared contract in `interface.md`. Luna owns only `src/csv/` and implements the state-machine CSV parser. Terra owns only `src/ledger/` and implements record validation plus monthly aggregation behind an injected exact-cents function. The Primary owns `src/money.cjs`, `cli.cjs`, atomic same-directory persistence, integration checks, documentation, canonical evidence and status. The unchanged `acceptance.cjs` is the main public seam; Primary-owned `focused-checks.cjs` covers existing-ledger semantic validation, unsafe aggregate totals, malformed quote forms, transactional rename behavior, and runnable README examples beyond that bounded suite.

## Trace
FP-1 and FP-2 support NS-1 under HC-1; source is GOAL.md and .ultra/specs/product.md.

## Completion
Implemented the complete CLI at reviewed source revision `5993205086b62a3f5ab83f56a1dbb5b72cc49495`. Unchanged acceptance passed 8/8 and focused checks passed 7/7; raw observations and the distinct seeded baseline, first integration, reviewer reproduction and completion snapshot are retained under `.ultra/evidence/expense-ledger/raw/`. Canonical Task Evidence v2 validates at `.ultra/evidence/expense-ledger/evidence.json`.

## Task Review
The first read-only Pi gpt-6-astra review (`reviewer-01`) returned `blocked`: it found P1 R1 (order-dependent intermediate total overflow) but could not originate the required timestamped receipt. The Primary reproduced that claimed JavaScript behavior with exit 1 before repair, then changed aggregation to exact `BigInt` accumulation plus final safe-range conversion and added the cancellation assertion (repair 1 of 2). The affected final read-only Pi gpt-6-astra review (`reviewer-delta-01`, native session `01a085ae-6ac6-724c-9990-f31d07fbabe4`) explicitly found R1 no longer applied and approved exact HEAD `5993205086b62a3f5ab83f56a1dbb5b72cc49495` / product digest `e45d1a9327c8298766aaae5569ec1a3c93fd1d3d5a4eb3025b838b9b2c226cb2` with no findings. Its exact reviewer-originated receipt is `.ultra/evidence/expense-ledger/external-review.json`; the full typed result is retained separately.

## Resume Note
Implementation and external-manual task review are complete. Task Evidence v2 is valid and the ledger is completed. Continue with the authorized six-area Test, one aggregate sequential-shared-context Review, then fresh Deliver finalization without changing source, task acceptance, specifications or README.
