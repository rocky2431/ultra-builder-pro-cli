'use strict';

function cents(value) {
  if (typeof value !== 'string' || !/^[+-]?\d+\.\d{2}$/.test(value)) {
    throw new Error('amount must be a signed decimal with exactly two decimal places');
  }
  const negative = value[0] === '-';
  const unsigned = value[0] === '-' || value[0] === '+' ? value.slice(1) : value;
  const [whole, fraction] = unsigned.split('.');
  const exact = BigInt(whole) * 100n + BigInt(fraction);
  const signed = negative ? -exact : exact;
  if (signed > BigInt(Number.MAX_SAFE_INTEGER) || signed < BigInt(Number.MIN_SAFE_INTEGER)) {
    throw new Error('amount in cents is outside the safe integer range');
  }
  return Number(signed);
}

module.exports = { cents };
