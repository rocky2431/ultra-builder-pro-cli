#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseCsv } = require('./src/csv/index.cjs');
const { normalizeRows, validateLedger, monthlyReport } = require('./src/ledger/index.cjs');
const { cents } = require('./src/money.cjs');

function readLedger(file, allowAbsent = false) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (error) {
    if (allowAbsent && error.code === 'ENOENT') return [];
    throw new Error(`cannot read ledger: ${error.message}`);
  }
  let value;
  try { value = JSON.parse(text); } catch (error) { throw new Error(`malformed ledger JSON: ${error.message}`); }
  return validateLedger(value);
}

function sameRecord(left, right) {
  return left.id === right.id && left.date === right.date && left.amount_cents === right.amount_cents &&
    left.currency === right.currency && left.category === right.category && left.note === right.note;
}

function persistAtomic(file, records) {
  const dir = path.dirname(path.resolve(file));
  const temporary = path.join(dir, `.${path.basename(file)}.${process.pid}.${crypto.randomBytes(8).toString('hex')}.tmp`);
  try {
    fs.writeFileSync(temporary, `${JSON.stringify(records, null, 2)}\n`, { flag: 'wx' });
    fs.renameSync(temporary, file);
  } catch (error) {
    try { fs.unlinkSync(temporary); } catch {}
    throw new Error(`cannot persist ledger: ${error.message}`);
  }
}

function importCsv(csvFile, ledgerFile) {
  let text;
  try { text = fs.readFileSync(csvFile, 'utf8'); } catch (error) { throw new Error(`cannot read CSV: ${error.message}`); }
  const incoming = normalizeRows(parseCsv(text), cents);
  const existing = readLedger(ledgerFile, true);
  const known = new Map(existing.map(record => [record.id, record]));
  const additions = [];
  let skipped = 0;
  for (const record of incoming) {
    const prior = known.get(record.id);
    if (prior) {
      if (!sameRecord(prior, record)) throw new Error(`conflicting repeated id: ${record.id}`);
      skipped += 1;
    } else {
      known.set(record.id, record);
      additions.push(record);
    }
  }
  persistAtomic(ledgerFile, existing.concat(additions));
  return { added: additions.length, skipped };
}

function main(args) {
  if (args[0] === 'import' && args.length === 3) return importCsv(args[1], args[2]);
  if (args[0] === 'report' && args.length === 3) return monthlyReport(readLedger(args[1]), args[2]);
  throw new Error('usage: node cli.cjs import <csv-file> <ledger-file> | node cli.cjs report <ledger-file> <YYYY-MM>');
}

try {
  const result = main(process.argv.slice(2));
  process.stdout.write(`${JSON.stringify(result)}\n`);
} catch (error) {
  process.stderr.write(`expense-ledger: ${error.message}\n`);
  process.exitCode = 1;
}
