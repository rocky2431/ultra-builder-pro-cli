'use strict';

const FIELDS = ['id', 'date', 'amount_cents', 'currency', 'category', 'note'];
const HEADER = ['id', 'date', 'amount', 'currency', 'category', 'note'];

function fail(message) {
  throw new Error(message);
}

function validDate(value) {
  const match = /^([0-9]{4})-([0-9]{2})-([0-9]{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1) return false;
  const days = [31, (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28,
    31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return day <= days[month - 1];
}

function validMonth(value) {
  return typeof value === 'string' && /^[0-9]{4}-(0[1-9]|1[0-2])$/.test(value);
}

function checkRecord(record, label) {
  if (record === null || typeof record !== 'object' || Array.isArray(record)) {
    fail(`${label} must be an object`);
  }
  const keys = Object.keys(record);
  if (keys.length !== FIELDS.length || !FIELDS.every((field) => Object.prototype.hasOwnProperty.call(record, field))) {
    fail(`${label} must have exactly id, date, amount_cents, currency, category, note`);
  }
  if (typeof record.id !== 'string' || record.id.length === 0) fail(`${label} id must be nonempty`);
  if (typeof record.date !== 'string' || !validDate(record.date)) fail(`${label} date must be a real YYYY-MM-DD date`);
  if (!Number.isSafeInteger(record.amount_cents)) fail(`${label} amount_cents must be a safe integer`);
  if (typeof record.currency !== 'string' || !/^[A-Z]{3}$/.test(record.currency)) fail(`${label} currency must be three uppercase ASCII letters`);
  if (typeof record.category !== 'string' || record.category.length === 0) fail(`${label} category must be nonempty`);
  if (typeof record.note !== 'string') fail(`${label} note must be a string`);
  return {
    id: record.id,
    date: record.date,
    amount_cents: record.amount_cents,
    currency: record.currency,
    category: record.category,
    note: record.note,
  };
}

function normalizeRows(rows, cents) {
  if (!Array.isArray(rows)) fail('CSV rows must be an array');
  if (typeof cents !== 'function') fail('cents must be a function');
  if (rows.length === 0) fail('CSV must include the required header');
  if (!Array.isArray(rows[0]) || rows[0].length !== HEADER.length || !HEADER.every((field, index) => rows[0][index] === field)) {
    fail('CSV header must be exactly id,date,amount,currency,category,note');
  }

  return rows.slice(1).map((row, index) => {
    const label = `CSV row ${index + 2}`;
    if (!Array.isArray(row) || row.length !== HEADER.length || !row.every((field) => typeof field === 'string')) {
      fail(`${label} must contain exactly six string fields`);
    }
    let amount;
    try {
      amount = cents(row[2]);
    } catch (error) {
      fail(`${label} amount is invalid: ${error && error.message ? error.message : 'invalid amount'}`);
    }
    return checkRecord({
      id: row[0], date: row[1], amount_cents: amount, currency: row[3], category: row[4], note: row[5],
    }, label);
  });
}

function validateLedger(value) {
  if (!Array.isArray(value)) fail('ledger must be a JSON array');
  const ids = new Set();
  return value.map((record, index) => {
    const normalized = checkRecord(record, `ledger record ${index + 1}`);
    if (ids.has(normalized.id)) fail(`ledger contains duplicate id: ${normalized.id}`);
    ids.add(normalized.id);
    return normalized;
  });
}

function monthlyReport(records, month) {
  if (!validMonth(month)) fail('month must be YYYY-MM');
  const totals = new Map();
  for (const record of validateLedger(records)) {
    if (!record.date.startsWith(`${month}-`)) continue;
    const key = `${record.currency}\u0000${record.category}`;
    const previous = totals.get(key) || { currency: record.currency, category: record.category, total_cents: 0, count: 0 };
    const total = previous.total_cents + record.amount_cents;
    if (!Number.isSafeInteger(total)) fail(`unsafe total for ${record.currency}/${record.category}`);
    previous.total_cents = total;
    previous.count += 1;
    totals.set(key, previous);
  }
  return [...totals.values()].sort((left, right) => {
    if (left.currency < right.currency) return -1;
    if (left.currency > right.currency) return 1;
    if (left.category < right.category) return -1;
    if (left.category > right.category) return 1;
    return 0;
  });
}

module.exports = { normalizeRows, validateLedger, monthlyReport };
