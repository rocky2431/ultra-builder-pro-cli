# Architecture

The public seams are the two Node CLI commands in GOAL.md and the JSON ledger. Use only the Node standard library. `cli.cjs` owns argument handling and transactional same-directory persistence; `src/csv/index.cjs` parses CSV text; `src/ledger/index.cjs` validates normalized records and computes reports; `src/money.cjs` converts exact decimal text to safe integer cents. The modules throw explanatory errors to the CLI boundary, and only the CLI prints or writes files.
