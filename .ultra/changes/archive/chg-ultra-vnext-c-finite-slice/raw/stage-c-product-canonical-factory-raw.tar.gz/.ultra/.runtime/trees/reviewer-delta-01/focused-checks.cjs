'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { parseCsv } = require('./src/csv/index.cjs');
const { validateLedger, monthlyReport } = require('./src/ledger/index.cjs');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'ledger-focused-'));
const invoke = (...args) => spawnSync(process.execPath, ['cli.cjs', ...args], { cwd: __dirname, encoding: 'utf8' });
try {
  assert.throws(() => parseCsv('a,"b"x\n'), /after closing quote/);
  assert.throws(() => validateLedger([
    { id: 'x', date: '2026-01-01', amount_cents: 1, currency: 'USD', category: 'C', note: '' },
    { id: 'x', date: '2026-01-01', amount_cents: 1, currency: 'USD', category: 'C', note: '' },
  ]), /duplicate id/);
  assert.throws(() => monthlyReport([
    { id: 'a', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'C', note: '' },
    { id: 'b', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'C', note: '' },
  ], '2026-01'), /unsafe total/);
  assert.equal(monthlyReport([
    { id: 'a', date: '2026-01-01', amount_cents: Number.MAX_SAFE_INTEGER, currency: 'USD', category: 'C', note: '' },
    { id: 'b', date: '2026-01-02', amount_cents: 1, currency: 'USD', category: 'C', note: '' },
    { id: 'c', date: '2026-01-03', amount_cents: -1, currency: 'USD', category: 'C', note: '' },
  ], '2026-01')[0].total_cents, Number.MAX_SAFE_INTEGER);

  const csv = path.join(root, 'expenses.csv');
  const ledger = path.join(root, 'ledger.json');
  fs.writeFileSync(csv, 'id,date,amount,currency,category,note\nx,2026-09-01,+1.00,USD,Food,example\n');
  let result = invoke('import', csv, ledger);
  assert.equal(result.status, 0, result.stderr);
  result = invoke('report', ledger, '2026-09');
  assert.equal(result.status, 0, result.stderr);
  assert.deepEqual(JSON.parse(result.stdout), [{ currency: 'USD', category: 'Food', total_cents: 100, count: 1 }]);
  assert.match(fs.readFileSync('README.md', 'utf8'), /node cli\.cjs import .*\nnode cli\.cjs report/);
  assert.deepEqual(fs.readdirSync(root).sort(), ['expenses.csv', 'ledger.json']);
  console.log(JSON.stringify({ passed: 7, total: 7, checks: ['malformed quote', 'duplicate ledger ids', 'unsafe final totals', 'exact cancellation totals', 'README import example', 'README report example', 'same-directory temp cleanup'] }, null, 2));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
