# Task expense-ledger: Implement and deliver the expense ledger

## Context
GOAL.md is the accepted scope. The native Primary chooses architecture and, when selected, disjoint Worker responsibilities. Preserve fixed inputs and provenance.

## Change Acceptance IDs
AC-01, AC-02, AC-03, AC-04.

## Acceptance Criteria
| ID | Criterion | Verification type | Required evidence |
|---|---|---|---|
| T-01 | Fixed goal behavior passes unchanged acceptance on integrated source. | command | Current CLI output, exit status and raw evidence. |
| T-02 | Final source has independent read-only Pi disposition with no unresolved blockers. | external-observation | Actual native reviewer and exact reviewer-originated receipt. |
| T-03 | Dependency-free source, error paths and runnable documentation realize the goal. | inspection | Source and README inspection, bounded limitations. |

## Implementation
Use the shared contract in `interface.md`. Luna owns only `src/csv/` and implements the state-machine CSV parser. Terra owns only `src/ledger/` and implements record validation plus monthly aggregation behind an injected exact-cents function. The Primary owns `src/money.cjs`, `cli.cjs`, atomic same-directory persistence, integration checks, documentation, canonical evidence and status. The unchanged `acceptance.cjs` is the main public seam; Primary-owned `focused-checks.cjs` covers existing-ledger semantic validation, unsafe aggregate totals, malformed quote forms, transactional rename behavior, and runnable README examples beyond that bounded suite.

## Trace
FP-1 and FP-2 support NS-1 under HC-1; source is GOAL.md and .ultra/specs/product.md.

## Completion
Not completed.

## Task Review
Not run. The external-manual branch may use immutable GOAL.md and .ultra/decisions/experiment.md bindings; the actual reviewer must originate its receipt.

## Resume Note
Current task is in progress under the current explicit prompt. Begin implementation from the seeded baseline and preserve its observed failure.
