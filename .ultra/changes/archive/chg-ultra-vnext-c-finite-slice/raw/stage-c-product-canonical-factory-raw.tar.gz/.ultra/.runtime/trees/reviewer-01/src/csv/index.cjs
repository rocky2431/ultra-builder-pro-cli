'use strict';

/**
 * Decode CSV text into rows without imposing the ledger's column schema.
 * Quoted fields may contain commas, line breaks, and doubled quotes.
 */
function parseCsv(text) {
  if (typeof text !== 'string') throw new TypeError('CSV input must be text');

  let input = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  if (input.length === 0) return [];

  const rows = [];
  let row = [];
  let field = '';
  let state = 'field-start';

  const finishRow = () => {
    row.push(field);
    rows.push(row);
    row = [];
    field = '';
    state = 'field-start';
  };

  for (let i = 0; i < input.length; i += 1) {
    const ch = input[i];

    if (state === 'quoted') {
      if (ch === '"') {
        state = 'after-quote';
      } else if (ch === '\n') {
        field += '\n';
      } else if (ch === '\r') {
        if (input[i + 1] !== '\n') throw new Error('Malformed CSV: bare carriage return');
        field += '\r\n';
        i += 1;
      } else {
        field += ch;
      }
      continue;
    }

    if (state === 'after-quote') {
      if (ch === '"') {
        field += '"';
        state = 'quoted';
      } else if (ch === ',') {
        row.push(field);
        field = '';
        state = 'field-start';
      } else if (ch === '\n') {
        finishRow();
      } else if (ch === '\r') {
        if (input[i + 1] !== '\n') throw new Error('Malformed CSV: bare carriage return');
        finishRow();
        i += 1;
      } else {
        throw new Error('Malformed CSV: characters after closing quote');
      }
      continue;
    }

    if (state === 'field-start') {
      if (ch === '"') {
        state = 'quoted';
      } else if (ch === ',') {
        row.push('');
      } else if (ch === '\n') {
        finishRow();
      } else if (ch === '\r') {
        if (input[i + 1] !== '\n') throw new Error('Malformed CSV: bare carriage return');
        finishRow();
        i += 1;
      } else {
        field += ch;
        state = 'unquoted';
      }
      continue;
    }

    // Unquoted fields permit every character except separators and quotes.
    if (ch === '"') {
      throw new Error('Malformed CSV: stray quote in unquoted field');
    } else if (ch === ',') {
      row.push(field);
      field = '';
      state = 'field-start';
    } else if (ch === '\n') {
      finishRow();
    } else if (ch === '\r') {
      if (input[i + 1] !== '\n') throw new Error('Malformed CSV: bare carriage return');
      finishRow();
      i += 1;
    } else {
      field += ch;
    }
  }

  if (state === 'quoted') throw new Error('Malformed CSV: unclosed quoted field');
  if (state === 'after-quote') {
    row.push(field);
    rows.push(row);
  } else if (state === 'unquoted' || row.length > 0 || field.length > 0) {
    finishRow();
  }

  return rows;
}

module.exports = { parseCsv };
