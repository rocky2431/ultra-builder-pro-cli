# Local expense ledger

Dependency-free Node CLI for importing bank CSV into a local JSON ledger and reporting monthly totals.

```sh
node cli.cjs import ./expenses.csv ./ledger.json
node cli.cjs report ./ledger.json 2026-09
```

The import command prints `{ "added": ..., "skipped": ... }`; report prints totals grouped by currency and category. See `GOAL.md` for the exact input and validation contract.
