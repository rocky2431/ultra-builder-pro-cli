# Expense ledger worker interface

## Shared data contract

A normalized record has exactly `{id,date,amount_cents,currency,category,note}`. Public CLI behavior and validation remain governed by `GOAL.md`; modules throw `Error` with explanatory messages and never print or persist directly.

## Worker decomposition

- **worker-left (Luna), owns `src/csv/` only:** implement `parseCsv(text)` in `src/csv/index.cjs`. It returns `string[][]` (records containing decoded field strings), supports an optional leading BOM, LF/CRLF, quoted commas/newlines and doubled quotes, and rejects malformed quoting or stray quotes. One final record separator creates no extra empty record; any other blank record remains a row for schema validation to reject. It does not validate the six-column business schema.
- **worker-right (Terra), owns `src/ledger/` only:** implement pure normalization/report helpers in `src/ledger/index.cjs`: `normalizeRows(rows, cents)` validates the exact header and fields and returns normalized records; `validateLedger(value)` validates every existing normalized record and rejects duplicate IDs (including conflicting duplicates); `monthlyReport(records, month)` validates the month, rejects unsafe group totals, and returns safe, sorted currency/category totals. The injected `cents` function is the shared money boundary.

## Primary-owned integration

The Primary alone owns `src/money.cjs`, `cli.cjs`, persistence, README/specification reconciliation, `focused-checks.cjs`, canonical records and Git integration. `cli.cjs` composes `parseCsv`, `normalizeRows`, `validateLedger`, `monthlyReport`, and `cents`; it validates a complete import and all duplicate conflicts before same-directory temporary-file rename. Workers must not edit root files, `.ultra/`, `GOAL.md`, or `acceptance.cjs`.
