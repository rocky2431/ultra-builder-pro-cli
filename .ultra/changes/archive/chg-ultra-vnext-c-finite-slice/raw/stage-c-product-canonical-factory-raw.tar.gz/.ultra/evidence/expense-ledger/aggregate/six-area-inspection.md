# Six-area inspection

- Anti-patterns: acceptance and focused checks contain effective assertions and invoke real subprocess/filesystem boundaries; no internal collaborator mocks or tautological placeholders.
- Coverage: unchanged acceptance covers import/report, quoted CSV, money, duplicates, conflicts, malformed fields, corrupt ledger and usage. Focused checks cover stray quotes, duplicate existing IDs, unsafe final totals, cancellation ordering, examples and temp cleanup.
- Wiring: `cents` is consumed by `cli.cjs`; `parseCsv` is consumed by `cli.cjs`; `normalizeRows`, `validateLedger`, and `monthlyReport` are consumed by `cli.cjs`. `cli.cjs` is the non-test executable consumer. No changed export is orphaned.
- Security: file paths are explicit CLI inputs; complete parse/validation precedes writes; temporary names use cryptographic randomness and `wx`; errors contain local paths but no secrets exist in this synthetic local-only tool.
- Omissions: no dependency audit was run because there is no package manifest or dependency and network/package access is prohibited. Power-loss directory durability, concurrent writers and strict malformed UTF-8 are outside the accepted boundary.
